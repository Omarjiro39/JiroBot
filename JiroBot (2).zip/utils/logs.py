"""إرسال Embeds السجلات إلى قناة اللوج المصنّفة لكل سيرفر.

كل تصنيف (roles / channels / voice) له عمود قناة خاص في guild_settings.
إن لم تُحدَّد قناة لتصنيف معيّن، يُستخدم العمود العام logs_channel_id كاحتياطي.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.logs")

CATEGORY_COLUMNS = {
    "roles": "roles_log_channel_id",
    "channels": "channels_log_channel_id",
    "voice": "voice_log_channel_id",
}


async def send_log_embed(bot: "JiroBot", guild: discord.Guild, embed: discord.Embed, category: str = "general") -> None:
    settings = await bot.db.get_guild_settings(guild.id)

    channel_id = None
    column = CATEGORY_COLUMNS.get(category)
    if column:
        channel_id = settings[column]
    if not channel_id:
        channel_id = settings["logs_channel_id"]
    if not channel_id:
        return

    channel = guild.get_channel(channel_id)
    if not isinstance(channel, discord.TextChannel):
        return

    permissions = channel.permissions_for(guild.me)
    if not (permissions.send_messages and permissions.embed_links):
        return

    try:
        await channel.send(embed=embed)
    except discord.HTTPException:
        log.warning("Could not deliver a log embed in guild %s", guild.id)
