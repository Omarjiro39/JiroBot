"""طبقة قاعدة البيانات (SQLite + aiosqlite)."""
from __future__ import annotations

import asyncio
import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator, Sequence

import aiosqlite

from utils.xp import level_from_xp

log = logging.getLogger("jirobot.database")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id     INTEGER PRIMARY KEY,
    username    TEXT    NOT NULL DEFAULT '',
    coins       INTEGER NOT NULL DEFAULT 0,
    last_daily  INTEGER NOT NULL DEFAULT 0,
    last_work   INTEGER NOT NULL DEFAULT 0,
    created_at  INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_users_coins ON users (coins DESC);

CREATE TABLE IF NOT EXISTS member_levels (
    guild_id    INTEGER NOT NULL,
    user_id     INTEGER NOT NULL,
    xp          INTEGER NOT NULL DEFAULT 0,
    level       INTEGER NOT NULL DEFAULT 0,
    last_xp_at  INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_member_levels_xp ON member_levels (guild_id, xp DESC);

CREATE TABLE IF NOT EXISTS warnings (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id      INTEGER NOT NULL,
    user_id       INTEGER NOT NULL,
    moderator_id  INTEGER NOT NULL,
    reason        TEXT    NOT NULL,
    created_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_warnings_member ON warnings (guild_id, user_id);

CREATE TABLE IF NOT EXISTS automod_words (
    guild_id  INTEGER NOT NULL,
    word      TEXT    NOT NULL,
    PRIMARY KEY (guild_id, word)
);

CREATE TABLE IF NOT EXISTS auto_responses (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id    INTEGER NOT NULL,
    trigger_text TEXT   NOT NULL,
    response    TEXT    NOT NULL,
    match_type  TEXT    NOT NULL DEFAULT 'contains',
    created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_auto_responses_guild ON auto_responses (guild_id);

CREATE TABLE IF NOT EXISTS reaction_roles (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id    INTEGER NOT NULL,
    channel_id  INTEGER NOT NULL,
    message_id  INTEGER NOT NULL,
    emoji       TEXT    NOT NULL,
    role_id     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_reaction_roles_guild ON reaction_roles (guild_id);

CREATE TABLE IF NOT EXISTS level_roles (
    guild_id  INTEGER NOT NULL,
    level     INTEGER NOT NULL,
    role_id   INTEGER NOT NULL,
    PRIMARY KEY (guild_id, level)
);

CREATE TABLE IF NOT EXISTS channel_reactions (
    guild_id    INTEGER NOT NULL,
    channel_id  INTEGER NOT NULL,
    emojis      TEXT    NOT NULL,
    PRIMARY KEY (guild_id, channel_id)
);

CREATE TABLE IF NOT EXISTS color_roles (
    guild_id  INTEGER NOT NULL,
    role_id   INTEGER NOT NULL,
    label     TEXT    NOT NULL,
    PRIMARY KEY (guild_id, role_id)
);

CREATE TABLE IF NOT EXISTS timers (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id          INTEGER NOT NULL,
    channel_id        INTEGER NOT NULL,
    message           TEXT    NOT NULL,
    interval_minutes  INTEGER NOT NULL,
    next_run          INTEGER NOT NULL,
    enabled           INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_timers_guild ON timers (guild_id);

CREATE TABLE IF NOT EXISTS custom_commands (
    guild_id  INTEGER NOT NULL,
    name      TEXT    NOT NULL,
    response  TEXT    NOT NULL,
    PRIMARY KEY (guild_id, name)
);

CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id INTEGER PRIMARY KEY
);

CREATE TABLE IF NOT EXISTS transactions (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL,
    direction     TEXT    NOT NULL,
    other_user_id INTEGER NOT NULL,
    other_name    TEXT    NOT NULL DEFAULT '',
    amount        INTEGER NOT NULL,
    balance_after INTEGER NOT NULL,
    created_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions (user_id, created_at DESC);
"""

GUILD_SETTINGS_COLUMNS: dict[str, str] = {
    "welcome_enabled": "INTEGER NOT NULL DEFAULT 0",
    "welcome_channel_id": "INTEGER",
    "welcome_message": "TEXT",
    "welcome_dm_enabled": "INTEGER NOT NULL DEFAULT 0",
    "welcome_dm_message": "TEXT",
    "autorole_enabled": "INTEGER NOT NULL DEFAULT 0",
    "autorole_role_id": "INTEGER",
    "leave_enabled": "INTEGER NOT NULL DEFAULT 0",
    "leave_channel_id": "INTEGER",
    "leave_message": "TEXT",
    "logs_channel_id": "INTEGER",
    "roles_log_channel_id": "INTEGER",
    "channels_log_channel_id": "INTEGER",
    "voice_log_channel_id": "INTEGER",
    "levels_enabled": "INTEGER NOT NULL DEFAULT 1",
    "levelup_messages": "INTEGER NOT NULL DEFAULT 1",
    "levelup_channel_id": "INTEGER",
    "xp_min": "INTEGER",
    "xp_max": "INTEGER",
    "xp_cooldown": "INTEGER",
    "automod_enabled": "INTEGER NOT NULL DEFAULT 0",
    "automod_links": "INTEGER NOT NULL DEFAULT 0",
    "automod_spam": "INTEGER NOT NULL DEFAULT 0",
    "automod_words": "INTEGER NOT NULL DEFAULT 0",
    "stay_voice_channel_id": "INTEGER",
    "custom_prefix": "TEXT",
}

REWARD_COLUMNS = {"daily": "last_daily", "work": "last_work"}


class Database:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._conn: aiosqlite.Connection | None = None
        self._write_lock = asyncio.Lock()

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database is not connected. Call connect() first.")
        return self._conn

    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = await aiosqlite.connect(self.path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA journal_mode = WAL")
        await self._conn.execute("PRAGMA foreign_keys = ON")
        await self._conn.executescript(SCHEMA)
        await self._migrate_columns("guild_settings", GUILD_SETTINGS_COLUMNS)
        await self._conn.commit()
        log.info("Database ready at %s", self.path)

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None
            log.info("Database connection closed")

    async def _migrate_columns(self, table: str, columns: dict[str, str]) -> None:
        async with self.conn.execute(f"PRAGMA table_info({table})") as cursor:
            existing = {row["name"] for row in await cursor.fetchall()}
        for name, definition in columns.items():
            if name not in existing:
                await self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")
                log.info("Added column %s.%s", table, name)

    async def execute(self, query: str, params: Sequence[Any] = ()) -> int:
        async with self._write_lock:
            cursor = await self.conn.execute(query, params)
            await self.conn.commit()
            rowcount = cursor.rowcount
            await cursor.close()
            return rowcount

    async def insert(self, query: str, params: Sequence[Any] = ()) -> int:
        """INSERT ويرجع رقم الصف الجديد."""
        async with self._write_lock:
            cursor = await self.conn.execute(query, params)
            await self.conn.commit()
            row_id = cursor.lastrowid
            await cursor.close()
            return row_id

    async def fetchone(self, query: str, params: Sequence[Any] = ()) -> aiosqlite.Row | None:
        async with self.conn.execute(query, params) as cursor:
            return await cursor.fetchone()

    async def fetchall(self, query: str, params: Sequence[Any] = ()) -> list[aiosqlite.Row]:
        async with self.conn.execute(query, params) as cursor:
            return list(await cursor.fetchall())

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[aiosqlite.Connection]:
        async with self._write_lock:
            conn = self.conn
            async with conn.execute("BEGIN IMMEDIATE"):
                pass
            try:
                yield conn
            except BaseException:
                await conn.rollback()
                raise
            await conn.commit()

    # ------------------------------------------------------------------
    # Guild settings
    # ------------------------------------------------------------------
    async def get_guild_settings(self, guild_id: int) -> aiosqlite.Row:
        row = await self.fetchone("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,))
        if row is None:
            await self.execute("INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)", (guild_id,))
            row = await self.fetchone("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,))
        assert row is not None
        return row

    async def set_guild_setting(self, guild_id: int, key: str, value: Any) -> None:
        if key not in GUILD_SETTINGS_COLUMNS:
            raise ValueError(f"Unknown guild setting: {key}")
        await self.execute("INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)", (guild_id,))
        await self.execute(f"UPDATE guild_settings SET {key} = ? WHERE guild_id = ?", (value, guild_id))

    async def get_all_guild_settings(self) -> list[aiosqlite.Row]:
        return await self.fetchall("SELECT * FROM guild_settings")

    # ------------------------------------------------------------------
    # Users (global)
    # ------------------------------------------------------------------
    async def ensure_user(self, user_id: int, username: str) -> None:
        await self.execute(
            """
            INSERT INTO users (user_id, username) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET username = excluded.username
            """,
            (user_id, username),
        )

    @staticmethod
    async def _upsert_user(conn: aiosqlite.Connection, user_id: int, username: str) -> None:
        await conn.execute(
            """
            INSERT INTO users (user_id, username) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET username = excluded.username
            """,
            (user_id, username),
        )

    # ------------------------------------------------------------------
    # Levels
    # ------------------------------------------------------------------
    async def add_xp(self, guild_id: int, user_id: int, amount: int, now: int) -> tuple[int, int, int]:
        await self.execute(
            """
            INSERT INTO member_levels (guild_id, user_id, xp, last_xp_at) VALUES (?, ?, ?, ?)
            ON CONFLICT(guild_id, user_id)
            DO UPDATE SET xp = xp + excluded.xp, last_xp_at = excluded.last_xp_at
            """,
            (guild_id, user_id, amount, now),
        )
        row = await self.fetchone(
            "SELECT xp, level FROM member_levels WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id),
        )
        assert row is not None
        old_level, xp = row["level"], row["xp"]
        new_level = level_from_xp(xp)
        if new_level != old_level:
            await self.execute(
                "UPDATE member_levels SET level = ? WHERE guild_id = ? AND user_id = ?",
                (new_level, guild_id, user_id),
            )
        return old_level, new_level, xp

    async def set_member_xp(self, guild_id: int, user_id: int, xp: int) -> int:
        level = level_from_xp(xp)
        await self.execute(
            """
            INSERT INTO member_levels (guild_id, user_id, xp, level) VALUES (?, ?, ?, ?)
            ON CONFLICT(guild_id, user_id) DO UPDATE SET xp = excluded.xp, level = excluded.level
            """,
            (guild_id, user_id, xp, level),
        )
        return level

    async def get_member_level(self, guild_id: int, user_id: int) -> aiosqlite.Row | None:
        return await self.fetchone(
            "SELECT xp, level FROM member_levels WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id),
        )

    async def get_level_rank(self, guild_id: int, user_id: int) -> int | None:
        row = await self.fetchone(
            """
            SELECT 1 + (SELECT COUNT(*) FROM member_levels WHERE guild_id = ? AND xp > ml.xp) AS pos
            FROM member_levels ml
            WHERE ml.guild_id = ? AND ml.user_id = ?
            """,
            (guild_id, guild_id, user_id),
        )
        return row["pos"] if row else None

    async def get_top_levels(self, guild_id: int, limit: int = 10) -> list[aiosqlite.Row]:
        return await self.fetchall(
            """
            SELECT ml.user_id, ml.xp, ml.level, u.username
            FROM member_levels ml
            LEFT JOIN users u ON u.user_id = ml.user_id
            WHERE ml.guild_id = ? AND ml.xp > 0
            ORDER BY ml.xp DESC, ml.user_id ASC
            LIMIT ?
            """,
            (guild_id, limit),
        )

    async def set_level_role(self, guild_id: int, level: int, role_id: int) -> None:
        await self.execute(
            """
            INSERT INTO level_roles (guild_id, level, role_id) VALUES (?, ?, ?)
            ON CONFLICT(guild_id, level) DO UPDATE SET role_id = excluded.role_id
            """,
            (guild_id, level, role_id),
        )

    async def remove_level_role(self, guild_id: int, level: int) -> int:
        return await self.execute("DELETE FROM level_roles WHERE guild_id = ? AND level = ?", (guild_id, level))

    async def get_level_roles(self, guild_id: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            "SELECT level, role_id FROM level_roles WHERE guild_id = ? ORDER BY level", (guild_id,)
        )

    # ------------------------------------------------------------------
    # Economy
    # ------------------------------------------------------------------
    async def get_coins(self, user_id: int) -> int:
        row = await self.fetchone("SELECT coins FROM users WHERE user_id = ?", (user_id,))
        return row["coins"] if row else 0

    async def get_coin_rank(self, user_id: int) -> int | None:
        row = await self.fetchone(
            """
            SELECT 1 + (SELECT COUNT(*) FROM users WHERE coins > u.coins) AS pos
            FROM users u WHERE u.user_id = ?
            """,
            (user_id,),
        )
        return row["pos"] if row else None

    async def get_top_coins(self, limit: int = 10) -> list[aiosqlite.Row]:
        return await self.fetchall(
            """
            SELECT user_id, username, coins FROM users
            WHERE coins > 0
            ORDER BY coins DESC, user_id ASC
            LIMIT ?
            """,
            (limit,),
        )

    async def claim_reward(
        self, user_id: int, username: str, kind: str, amount: int, cooldown: int, now: int
    ) -> tuple[bool, int]:
        column = REWARD_COLUMNS[kind]
        async with self.transaction() as conn:
            await self._upsert_user(conn, user_id, username)
            async with conn.execute(
                f"SELECT coins, {column} AS last_time FROM users WHERE user_id = ?", (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
            assert row is not None

            remaining = row["last_time"] + cooldown - now
            if remaining > 0:
                return False, remaining

            await conn.execute(
                f"UPDATE users SET coins = coins + ?, {column} = ? WHERE user_id = ?",
                (amount, now, user_id),
            )
            return True, row["coins"] + amount

    async def transfer_coins(
        self, sender_id: int, sender_name: str, receiver_id: int, receiver_name: str, amount: int
    ) -> tuple[bool, int]:
        if amount <= 0 or sender_id == receiver_id:
            raise ValueError("Invalid transfer")

        async with self.transaction() as conn:
            await self._upsert_user(conn, sender_id, sender_name)
            await self._upsert_user(conn, receiver_id, receiver_name)
            async with conn.execute("SELECT coins FROM users WHERE user_id = ?", (sender_id,)) as cursor:
                row = await cursor.fetchone()
            assert row is not None

            balance = row["coins"]
            if balance < amount:
                return False, balance

            await conn.execute("UPDATE users SET coins = coins - ? WHERE user_id = ?", (amount, sender_id))
            await conn.execute("UPDATE users SET coins = coins + ? WHERE user_id = ?", (amount, receiver_id))

            sender_new = balance - amount
            async with conn.execute("SELECT coins FROM users WHERE user_id = ?", (receiver_id,)) as rcur:
                rrow = await rcur.fetchone()
            receiver_new = (rrow["coins"] if rrow else 0)
            now = int(time.time())

            await conn.execute(
                "INSERT INTO transactions (user_id, direction, other_user_id, other_name, amount, balance_after, created_at) "
                "VALUES (?, 'out', ?, ?, ?, ?, ?)",
                (sender_id, receiver_id, receiver_name, amount, sender_new, now),
            )
            await conn.execute(
                "INSERT INTO transactions (user_id, direction, other_user_id, other_name, amount, balance_after, created_at) "
                "VALUES (?, 'in', ?, ?, ?, ?, ?)",
                (receiver_id, sender_id, sender_name, amount, receiver_new, now),
            )
            return True, sender_new

    async def get_user_transactions(self, user_id: int, limit: int = 50) -> list[aiosqlite.Row]:
        """سجل تحويلات العضو: كل صف يصف تحويلاً صادراً أو وارداً مع الطرف الآخر والمبلغ والتاريخ."""
        return await self.fetchall(
            """
            SELECT id, direction, other_user_id, other_name, amount, balance_after, created_at
            FROM transactions
            WHERE user_id = ?
            ORDER BY created_at DESC, id DESC
            LIMIT ?
            """,
            (user_id, limit),
        )

    async def owner_adjust_coins(self, user_id: int, username: str, amount: int) -> int:
        async with self.transaction() as conn:
            await self._upsert_user(conn, user_id, username)
            async with conn.execute("SELECT coins FROM users WHERE user_id = ?", (user_id,)) as cursor:
                row = await cursor.fetchone()
            assert row is not None

            new_balance = max(0, row["coins"] + amount)
            await conn.execute("UPDATE users SET coins = ? WHERE user_id = ?", (new_balance, user_id))
            return new_balance

    async def owner_set_coins(self, user_id: int, username: str, amount: int) -> int:
        async with self.transaction() as conn:
            await self._upsert_user(conn, user_id, username)
            await conn.execute("UPDATE users SET coins = ? WHERE user_id = ?", (amount, user_id))
            return amount

    async def settle_bet(self, user_id: int, username: str, bet: int, won: bool) -> tuple[bool, int]:
        if bet <= 0:
            raise ValueError("Invalid bet")

        async with self.transaction() as conn:
            await self._upsert_user(conn, user_id, username)
            async with conn.execute("SELECT coins FROM users WHERE user_id = ?", (user_id,)) as cursor:
                row = await cursor.fetchone()
            assert row is not None

            balance = row["coins"]
            if balance < bet:
                return False, balance

            new_balance = balance + bet if won else balance - bet
            await conn.execute("UPDATE users SET coins = ? WHERE user_id = ?", (new_balance, user_id))
            return True, new_balance

    # ------------------------------------------------------------------
    # Warnings
    # ------------------------------------------------------------------
    async def add_warning(self, guild_id: int, user_id: int, moderator_id: int, reason: str, now: int) -> int:
        return await self.insert(
            "INSERT INTO warnings (guild_id, user_id, moderator_id, reason, created_at) VALUES (?, ?, ?, ?, ?)",
            (guild_id, user_id, moderator_id, reason, now),
        )

    async def get_warnings(self, guild_id: int, user_id: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            """
            SELECT id, moderator_id, reason, created_at FROM warnings
            WHERE guild_id = ? AND user_id = ?
            ORDER BY created_at DESC
            """,
            (guild_id, user_id),
        )

    async def clear_warnings(self, guild_id: int, user_id: int) -> int:
        return await self.execute("DELETE FROM warnings WHERE guild_id = ? AND user_id = ?", (guild_id, user_id))

    # ------------------------------------------------------------------
    # AutoMod words
    # ------------------------------------------------------------------
    async def add_automod_word(self, guild_id: int, word: str) -> None:
        await self.execute("INSERT OR IGNORE INTO automod_words (guild_id, word) VALUES (?, ?)", (guild_id, word))

    async def remove_automod_word(self, guild_id: int, word: str) -> int:
        return await self.execute("DELETE FROM automod_words WHERE guild_id = ? AND word = ?", (guild_id, word))

    async def get_automod_words(self, guild_id: int) -> list[str]:
        rows = await self.fetchall("SELECT word FROM automod_words WHERE guild_id = ? ORDER BY word", (guild_id,))
        return [row["word"] for row in rows]

    # ------------------------------------------------------------------
    # Auto-respond
    # ------------------------------------------------------------------
    async def add_auto_response(self, guild_id: int, trigger: str, response: str, match_type: str, now: int) -> int:
        return await self.insert(
            "INSERT INTO auto_responses (guild_id, trigger_text, response, match_type, created_at) VALUES (?, ?, ?, ?, ?)",
            (guild_id, trigger, response, match_type, now),
        )

    async def get_auto_responses(self, guild_id: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            "SELECT id, trigger_text, response, match_type FROM auto_responses WHERE guild_id = ? ORDER BY id",
            (guild_id,),
        )

    async def remove_auto_response(self, guild_id: int, response_id: int) -> int:
        return await self.execute("DELETE FROM auto_responses WHERE guild_id = ? AND id = ?", (guild_id, response_id))

    # ------------------------------------------------------------------
    # Reaction roles
    # ------------------------------------------------------------------
    async def add_reaction_role(self, guild_id: int, channel_id: int, message_id: int, emoji: str, role_id: int) -> int:
        return await self.insert(
            "INSERT INTO reaction_roles (guild_id, channel_id, message_id, emoji, role_id) VALUES (?, ?, ?, ?, ?)",
            (guild_id, channel_id, message_id, emoji, role_id),
        )

    async def get_reaction_roles(self, guild_id: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            "SELECT id, channel_id, message_id, emoji, role_id FROM reaction_roles WHERE guild_id = ? ORDER BY message_id, id",
            (guild_id,),
        )

    async def remove_reaction_role_message(self, guild_id: int, message_id: int) -> int:
        return await self.execute(
            "DELETE FROM reaction_roles WHERE guild_id = ? AND message_id = ?", (guild_id, message_id)
        )

    # ------------------------------------------------------------------
    # Channel reactions
    # ------------------------------------------------------------------
    async def set_channel_reactions(self, guild_id: int, channel_id: int, emojis: str) -> None:
        await self.execute(
            """
            INSERT INTO channel_reactions (guild_id, channel_id, emojis) VALUES (?, ?, ?)
            ON CONFLICT(guild_id, channel_id) DO UPDATE SET emojis = excluded.emojis
            """,
            (guild_id, channel_id, emojis),
        )

    async def remove_channel_reactions(self, guild_id: int, channel_id: int) -> int:
        return await self.execute(
            "DELETE FROM channel_reactions WHERE guild_id = ? AND channel_id = ?", (guild_id, channel_id)
        )

    async def get_channel_reactions(self, guild_id: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            "SELECT channel_id, emojis FROM channel_reactions WHERE guild_id = ?", (guild_id,)
        )

    # ------------------------------------------------------------------
    # Color roles
    # ------------------------------------------------------------------
    async def add_color_role(self, guild_id: int, role_id: int, label: str) -> None:
        await self.execute(
            "INSERT OR REPLACE INTO color_roles (guild_id, role_id, label) VALUES (?, ?, ?)",
            (guild_id, role_id, label),
        )

    async def remove_color_role(self, guild_id: int, role_id: int) -> int:
        return await self.execute("DELETE FROM color_roles WHERE guild_id = ? AND role_id = ?", (guild_id, role_id))

    async def get_color_roles(self, guild_id: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            "SELECT role_id, label FROM color_roles WHERE guild_id = ? ORDER BY rowid", (guild_id,)
        )

    # ------------------------------------------------------------------
    # Timers
    # ------------------------------------------------------------------
    async def add_timer(self, guild_id: int, channel_id: int, message: str, interval_minutes: int, next_run: int) -> int:
        return await self.insert(
            "INSERT INTO timers (guild_id, channel_id, message, interval_minutes, next_run) VALUES (?, ?, ?, ?, ?)",
            (guild_id, channel_id, message, interval_minutes, next_run),
        )

    async def get_timers(self, guild_id: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            "SELECT id, channel_id, message, interval_minutes, next_run, enabled FROM timers WHERE guild_id = ? ORDER BY id",
            (guild_id,),
        )

    async def get_due_timers(self, now: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            "SELECT id, guild_id, channel_id, message, interval_minutes FROM timers WHERE enabled = 1 AND next_run <= ?",
            (now,),
        )

    async def set_timer_next_run(self, timer_id: int, next_run: int) -> int:
        return await self.execute("UPDATE timers SET next_run = ? WHERE id = ?", (next_run, timer_id))

    async def set_timer_enabled(self, guild_id: int, timer_id: int, enabled: bool, next_run: int) -> int:
        return await self.execute(
            "UPDATE timers SET enabled = ?, next_run = ? WHERE guild_id = ? AND id = ?",
            (int(enabled), next_run, guild_id, timer_id),
        )

    async def remove_timer(self, guild_id: int, timer_id: int) -> int:
        return await self.execute("DELETE FROM timers WHERE guild_id = ? AND id = ?", (guild_id, timer_id))

    # ------------------------------------------------------------------
    # Custom commands
    # ------------------------------------------------------------------
    async def set_custom_command(self, guild_id: int, name: str, response: str) -> None:
        await self.execute(
            """
            INSERT INTO custom_commands (guild_id, name, response) VALUES (?, ?, ?)
            ON CONFLICT(guild_id, name) DO UPDATE SET response = excluded.response
            """,
            (guild_id, name, response),
        )

    async def remove_custom_command(self, guild_id: int, name: str) -> int:
        return await self.execute("DELETE FROM custom_commands WHERE guild_id = ? AND name = ?", (guild_id, name))

    async def get_custom_commands(self, guild_id: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            "SELECT name, response FROM custom_commands WHERE guild_id = ? ORDER BY name", (guild_id,)
        )
