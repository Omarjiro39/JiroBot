document.addEventListener('DOMContentLoaded', function () {
    // فتح/إغلاق القسم عند الضغط على البطاقة (وليس على المفتاح نفسه)
    document.querySelectorAll('.feature-head').forEach(function (head) {
        head.addEventListener('click', function (e) {
            if (e.target.closest('.toggle')) return;
            head.closest('.feature-card').classList.toggle('open');
        });
    });

    // فتح تلقائي للأقسام المفعّلة أصلاً
    document.querySelectorAll('.feature-card').forEach(function (card) {
        var input = card.querySelector('.toggle-input');
        if (input && input.checked) card.classList.add('open');
    });

    // بحث السيرفرات
    var search = document.getElementById('serverSearch');
    if (search) {
        search.addEventListener('input', function (e) {
            var q = e.target.value.trim().toLowerCase();
            document.querySelectorAll('.server-card').forEach(function (card) {
                card.style.display = card.dataset.name.indexOf(q) === -1 ? 'none' : '';
            });
        });
    }

    // القائمة الجانبية على الجوال
    var toggle = document.getElementById('sidebarToggle');
    var sidebar = document.getElementById('sidebar');
    if (toggle && sidebar) {
        toggle.addEventListener('click', function () { sidebar.classList.toggle('open'); });
        document.addEventListener('click', function (e) {
            if (sidebar.classList.contains('open') && !sidebar.contains(e.target) && e.target !== toggle && !toggle.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        });
    }

    // صف إضافي لرتب رد الفعل
    var addBtn = document.getElementById('addPairRow');
    var template = document.getElementById('pairRowTemplate');
    var rows = document.getElementById('pairRows');
    if (addBtn && template && rows) {
        addBtn.addEventListener('click', function () {
            rows.appendChild(template.content.cloneNode(true));
        });
    }
    document.addEventListener('click', function (e) {
        var removeBtn = e.target.closest('.pair-remove');
        if (removeBtn) removeBtn.closest('.pair-row').remove();
    });

    // نسخ كود الإيموجي
    document.querySelectorAll('[data-copy]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            navigator.clipboard.writeText(btn.dataset.copy).then(function () {
                var original = btn.textContent;
                btn.textContent = 'تم النسخ';
                setTimeout(function () { btn.textContent = original; }, 1200);
            });
        });
    });

    // تأكيد قبل الحذف
    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            if (!confirm(form.dataset.confirm)) e.preventDefault();
        });
    });

    // عرض وقت المؤقت التالي بتوقيت الجهاز
    document.querySelectorAll('[data-ts]').forEach(function (el) {
        var date = new Date(parseInt(el.dataset.ts, 10) * 1000);
        el.textContent = date.toLocaleString();
    });
});
