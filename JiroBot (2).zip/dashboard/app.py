"""لوحة تحكم JiroBot: تسجيل دخول عبر Discord OAuth2 وإدارة كل ميزات السيرفر."""
from __future__ import annotations

import asyncio
import logging
import random
import re
import time
from functools import wraps
from typing import TYPE_CHECKING, Any

import discord
import requests
from flask import Flask, abort, flash, redirect, render_template, request, session, url_for
from markupsafe import Markup, escape

import config
from dashboard.icons import render_icon

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.dashboard")

API_BASE = "https://discord.com/api/v10"
MANAGE_GUILD = 0x20
CUSTOM_EMOJI_RE = re.compile(r"^<(a?):(\w+):(\d+)>$")

NAV_SECTIONS = [
    {
        "title": "الرئيسية",
        "links": [
            ("guild_welcome", "الترحيب والمغادرة", "gift"),
            ("guild_reactionroles", "رتب رد الفعل", "zap"),
            ("guild_levels", "نظام المستويات", "star"),
            ("guild_autorespond", "الرد التلقائي", "message-square"),
            ("guild_channelreactions", "تفاعلات القنوات", "hash"),
            ("guild_colorroles", "رتب الألوان", "droplet"),
            ("guild_timers", "المؤقتات", "clock"),
            ("guild_emojis", "الإيموجيات", "smile"),
            ("guild_customcommands", "أوامر مخصصة", "terminal"),
        ],
    },
    {
        "title": "الإدارة",
        "links": [
            ("guild_logs", "السجلات", "file-text"),
            ("guild_automod", "الحماية التلقائية", "shield"),
            ("guild_embed", "إرسال Embed", "send"),
            ("guild_commands", "الأوامر", "list"),
        ],
    },
]

COMMAND_CATALOG = [
    {
        "title": "الإدارة", "icon": "shield",
        "commands": [
            ("/kick", "طرد عضو من السيرفر"), ("/ban", "حظر مستخدم"), ("/unban", "فك حظر مستخدم بالآيدي"),
            ("/timeout", "إسكات عضو لمدة محددة"), ("/warn", "إعطاء تحذير لعضو"), ("/warnings", "عرض تحذيرات عضو"),
            ("/clearwarnings", "حذف تحذيرات عضو"), ("/clear", "حذف عدد من الرسائل"), ("/slowmode", "ضبط وضع البطيء"),
            ("/lock", "قفل قناة"), ("/unlock", "فتح قناة"), ("/nick", "تغيير لقب عضو"),
            ("/role add", "إعطاء رتبة لعضو"), ("/role remove", "إزالة رتبة من عضو"),
        ],
    },
    {
        "title": "الاقتصاد", "icon": "coins",
        "commands": [
            ("/balance", "عرض الرصيد"), ("/daily", "المكافأة اليومية"), ("/work", "اشتغل واكسب عملات"),
            ("/pay", "تحويل عملات لعضو"), ("/coinflip", "رهان وجه أو كتابة"), ("/economy leaderboard", "أغنى الأعضاء"),
        ],
    },
    {
        "title": "المستويات", "icon": "star",
        "commands": [
            ("/rank", "عرض المستوى"), ("/leaderboard", "قائمة المتصدرين"), ("/level enable", "تشغيل رسائل الترقية"),
            ("/level disable", "إيقاف رسائل الترقية"), ("/level channel", "قناة رسائل الترقية"),
            ("/level setxp", "ضبط XP عضو"), ("/level xprange", "مدى XP لكل رسالة"), ("/level system", "تشغيل/إيقاف النظام"),
        ],
    },
    {"title": "البروفايل", "icon": "user", "commands": [("/profile", "بطاقة الملف الشخصي (صورة)")]},
    {
        "title": "إعدادات السيرفر", "icon": "layout",
        "commands": [
            ("/welcome ...", "الترحيب، الترحيب الخاص، الرتبة التلقائية"), ("/leave ...", "رسائل المغادرة"),
            ("/logs ...", "قنوات السجلات المصنّفة"), ("/automod ...", "الحماية التلقائية"),
            ("/autorespond ...", "الردود التلقائية"),
        ],
    },
    {
        "title": "الأدوات", "icon": "terminal",
        "commands": [("/ping", "سرعة استجابة البوت"), ("/botinfo", "معلومات البوت"), ("/help", "قائمة الأوامر")],
    },
]


def emoji_html(value: Any) -> Markup:
    """يعرض الإيموجي المخصص كصورة، والعادي كنص."""
    text = str(value or "").strip()
    match = CUSTOM_EMOJI_RE.match(text)
    if match:
        animated, name, emoji_id = match.groups()
        ext = "gif" if animated else "png"
        return Markup(
            f'<img class="emoji" src="https://cdn.discordapp.com/emojis/{emoji_id}.{ext}?size=48" alt="{escape(name)}">'
        )
    return Markup(escape(text))


def to_int(value: Any, default: int | None = None) -> int | None:
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return default


def parse_color(value: Any, default: int = config.EMERALD) -> int:
    try:
        return int(str(value).lstrip("#"), 16) & 0xFFFFFF
    except ValueError:
        return default


def interval_text(minutes: int) -> str:
    if minutes % 1440 == 0:
        return f"{minutes // 1440} يوم"
    if minutes % 60 == 0:
        return f"{minutes // 60} ساعة"
    return f"{minutes} دقيقة"


def run_dashboard(bot: "JiroBot") -> None:
    app = Flask(__name__)
    app.secret_key = config.DASHBOARD_SECRET_KEY or "change-me-please"
    app.config["MAX_CONTENT_LENGTH"] = 1 * 1024 * 1024  # حد أقصى 1MB للرفع
    app.jinja_env.globals["icon"] = render_icon
    app.jinja_env.filters["emoji"] = emoji_html

    def run_coro(coro):
        future = asyncio.run_coroutine_threadsafe(coro, bot.loop)
        return future.result(timeout=20)

    def login_required(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "user" not in session:
                return redirect(url_for("login"))
            return view(*args, **kwargs)

        return wrapped

    @app.context_processor
    def inject_globals():
        data: dict[str, Any] = {
            "invite_url": config.INVITE_URL,
            "support_url": config.SUPPORT_URL,
            "nav_sections": NAV_SECTIONS,
        }
        guild_id = (request.view_args or {}).get("guild_id")
        if guild_id and str(guild_id).isdigit() and "user" in session:
            manageable = session.get("manageable_guilds", {})
            data["current_guild"] = bot.get_guild(int(guild_id))
            data["switcher"] = [
                {"id": gid, "name": info["name"]}
                for gid, info in manageable.items()
                if bot.get_guild(int(gid)) is not None
            ]
            try:
                data["user_coins"] = run_coro(bot.db.get_coins(int(session["user"]["id"])))
            except Exception:
                data["user_coins"] = 0
        return data

    # ------------------------------------------------------------------
    # مساعدات السيرفر
    # ------------------------------------------------------------------
    def load_guild(guild_id: str) -> discord.Guild | None:
        if guild_id not in session.get("manageable_guilds", {}):
            abort(403)
        guild = bot.get_guild(int(guild_id))
        if guild is None:
            flash("JiroBot غير موجود في هذا السيرفر بعد.", "error")
        return guild

    def text_channels(guild: discord.Guild) -> list[dict[str, Any]]:
        return [{"id": c.id, "name": c.name} for c in guild.text_channels]

    def assignable_roles(guild: discord.Guild) -> list[dict[str, Any]]:
        me = guild.me
        roles = [
            r for r in guild.roles
            if not r.is_default() and not r.managed and (me is None or r < me.top_role)
        ]
        roles.sort(key=lambda r: r.position, reverse=True)
        return [{"id": r.id, "name": r.name} for r in roles]

    def done(guild_id: str, endpoint: str):
        return redirect(url_for(endpoint, guild_id=guild_id))

    # ------------------------------------------------------------------
    # الصفحات العامة
    # ------------------------------------------------------------------
    @app.route("/")
    def index():
        return render_template("landing.html")

    @app.route("/commands")
    def commands():
        return render_template("commands.html", catalog=COMMAND_CATALOG, layout="base.html")

    @app.route("/dashboard")
    def dashboard_entry():
        if "user" in session:
            return redirect(url_for("guilds"))
        return redirect(url_for("login"))

    # ------------------------------------------------------------------
    # المصادقة (Discord OAuth2)
    # ------------------------------------------------------------------
    @app.route("/login")
    def login():
        params = (
            f"client_id={config.DASHBOARD_CLIENT_ID}"
            f"&redirect_uri={config.DASHBOARD_REDIRECT_URI}"
            "&response_type=code&scope=identify%20guilds"
        )
        return redirect(f"https://discord.com/oauth2/authorize?{params}")

    @app.route("/callback")
    def callback():
        code = request.args.get("code")
        if not code:
            flash("تم إلغاء تسجيل الدخول.", "error")
            return redirect(url_for("index"))

        token_data = {
            "client_id": config.DASHBOARD_CLIENT_ID,
            "client_secret": config.DASHBOARD_CLIENT_SECRET,
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": config.DASHBOARD_REDIRECT_URI,
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}

        try:
            token_resp = requests.post(f"{API_BASE}/oauth2/token", data=token_data, headers=headers, timeout=10)
            token_resp.raise_for_status()
            access_token = token_resp.json()["access_token"]

            auth_header = {"Authorization": f"Bearer {access_token}"}
            user_resp = requests.get(f"{API_BASE}/users/@me", headers=auth_header, timeout=10)
            user_resp.raise_for_status()
            discord_user = user_resp.json()

            guilds_resp = requests.get(f"{API_BASE}/users/@me/guilds", headers=auth_header, timeout=10)
            guilds_resp.raise_for_status()
            discord_guilds = guilds_resp.json()
        except requests.RequestException:
            log.exception("OAuth2 exchange failed")
            flash("تعذر تسجيل الدخول عبر Discord. حاول مرة أخرى.", "error")
            return redirect(url_for("index"))

        manageable: dict[str, dict[str, Any]] = {}
        for g in discord_guilds:
            permissions = int(g.get("permissions", 0))
            if g.get("owner") or (permissions & MANAGE_GUILD) == MANAGE_GUILD:
                manageable[g["id"]] = {"name": g["name"], "icon": g.get("icon")}

        session["user"] = {
            "id": discord_user["id"],
            "username": discord_user.get("global_name") or discord_user["username"],
            "avatar": discord_user.get("avatar"),
        }
        session["manageable_guilds"] = manageable
        return redirect(url_for("guilds"))

    @app.route("/logout")
    def logout():
        session.clear()
        return redirect(url_for("index"))

    # ------------------------------------------------------------------
    # البروفايل + المكافأة اليومية
    # ------------------------------------------------------------------
    @app.route("/profile", methods=["GET", "POST"])
    @login_required
    def profile():
        user = session["user"]
        user_id = int(user["id"])
        message, message_type = None, "success"

        if request.method == "POST":
            amount = random.randint(config.DAILY_MIN, config.DAILY_MAX)
            now = int(time.time())
            claimed, value = run_coro(
                bot.db.claim_reward(user_id, user["username"], "daily", amount, config.DAILY_COOLDOWN_SECONDS, now)
            )
            if claimed:
                message = f"حصلت على {amount:,} {config.CURRENCY_SYMBOL}! رصيدك الآن: {value:,} {config.CURRENCY_SYMBOL}"
            else:
                message = f"استلمت مكافأتك اليوم بالفعل. حاول بعد {value // 3600} ساعة و {(value % 3600) // 60} دقيقة."
                message_type = "error"

        coins = run_coro(bot.db.get_coins(user_id))
        coin_rank = run_coro(bot.db.get_coin_rank(user_id))
        row = run_coro(bot.db.fetchone("SELECT last_daily FROM users WHERE user_id = ?", (user_id,)))
        last_daily = row["last_daily"] if row else 0
        seconds_left = max(0, (last_daily + config.DAILY_COOLDOWN_SECONDS) - int(time.time()))

        return render_template(
            "profile.html", user=user, coins=coins, coin_rank=coin_rank, can_claim=seconds_left == 0,
            seconds_left=seconds_left, message=message, message_type=message_type, currency=config.CURRENCY_SYMBOL,
        )

    @app.route("/rewards")
    @login_required
    def rewards():
        return redirect(url_for("profile"))

    # ------------------------------------------------------------------
    # سجل تحويلات العضو (مثل ProBot: كم، لمين، ومتى)
    # ------------------------------------------------------------------
    @app.route("/transactions")
    @login_required
    def transactions():
        user = session["user"]
        user_id = int(user["id"])
        coins = run_coro(bot.db.get_coins(user_id))
        rows = run_coro(bot.db.get_user_transactions(user_id, limit=100))
        now = int(time.time())
        tx_list = []
        for r in rows:
            delta = now - r["created_at"]
            if delta < 60:
                when = "قبل ثوانٍ"
            elif delta < 3600:
                when = f"قبل {delta // 60} دقيقة"
            elif delta < 86400:
                when = f"قبل {delta // 3600} ساعة"
            else:
                days = delta // 86400
                when = f"قبل {days} يوم" if days < 7 else f"قبل {days // 7} أسبوع"
            tx_list.append({
                "direction": r["direction"],
                "other_name": r["other_name"] or "—",
                "amount": r["amount"],
                "balance_after": r["balance_after"],
                "when": when,
            })
        return render_template(
            "transactions.html", user=user, coins=coins,
            currency=config.CURRENCY_SYMBOL, tx_list=tx_list,
        )

    # ------------------------------------------------------------------
    # قائمة السيرفرات
    # ------------------------------------------------------------------
    @app.route("/guilds")
    @login_required
    def guilds():
        manageable = session.get("manageable_guilds", {})
        active, others = [], []
        for guild_id, info in manageable.items():
            entry = {"id": guild_id, "name": info["name"], "icon": info["icon"]}
            guild = bot.get_guild(int(guild_id))
            if guild is not None:
                entry["members"] = f"{(guild.member_count or 0):,}"
                active.append(entry)
            else:
                others.append(entry)

        active.sort(key=lambda s: s["name"].lower())
        others.sort(key=lambda s: s["name"].lower())
        return render_template("guilds.html", active=active, others=others, user=session["user"])

    @app.route("/guild/<guild_id>")
    @login_required
    def guild_home(guild_id: str):
        return redirect(url_for("guild_welcome", guild_id=guild_id))

    # ------------------------------------------------------------------
    # الترحيب والمغادرة
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/welcome", methods=["GET", "POST"])
    @login_required
    def guild_welcome(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id

        if request.method == "POST":
            form = request.form

            async def save():
                s = bot.db.set_guild_setting
                await s(gid, "welcome_enabled", int(bool(form.get("welcome_enabled"))))
                await s(gid, "welcome_channel_id", to_int(form.get("welcome_channel_id")))
                await s(gid, "welcome_message", form.get("welcome_message", "").strip() or None)
                await s(gid, "welcome_dm_enabled", int(bool(form.get("welcome_dm_enabled"))))
                await s(gid, "welcome_dm_message", form.get("welcome_dm_message", "").strip() or None)
                await s(gid, "autorole_enabled", int(bool(form.get("autorole_enabled"))))
                await s(gid, "autorole_role_id", to_int(form.get("autorole_role_id")))
                await s(gid, "leave_enabled", int(bool(form.get("leave_enabled"))))
                await s(gid, "leave_channel_id", to_int(form.get("leave_channel_id")))
                await s(gid, "leave_message", form.get("leave_message", "").strip() or None)

            run_coro(save())
            flash("تم حفظ الإعدادات بنجاح.", "success")
            return done(guild_id, "guild_welcome")

        settings = run_coro(bot.db.get_guild_settings(gid))
        return render_template(
            "welcome.html", guild=guild, settings=settings, channels=text_channels(guild), roles=assignable_roles(guild)
        )

    # ------------------------------------------------------------------
    # رتب رد الفعل
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/reactionroles", methods=["GET", "POST"])
    @login_required
    def guild_reactionroles(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id
        cog = bot.get_cog("ReactionRoles")

        if request.method == "POST":
            form = request.form
            action = form.get("action")
            if cog is None:
                flash("نظام رتب رد الفعل غير محمّل.", "error")
            elif action == "create":
                pairs = []
                for emoji, role in zip(form.getlist("emoji"), form.getlist("role_id")):
                    role_id = to_int(role)
                    if emoji.strip() and role_id:
                        pairs.append((emoji.strip(), role_id))
                ok, error = run_coro(
                    cog.create_panel(
                        guild, to_int(form.get("channel_id")), form.get("title", "").strip()[:200],
                        form.get("description", "").strip()[:1500], parse_color(form.get("color")), pairs[:20],
                    )
                )
                flash("تم إرسال اللوحة بنجاح." if ok else (error or "حدث خطأ."), "success" if ok else "error")
            elif action == "delete":
                message_id = to_int(form.get("message_id"))
                if message_id:
                    run_coro(cog.delete_panel(guild, message_id))
                    flash("تم حذف اللوحة.", "success")
            return done(guild_id, "guild_reactionroles")

        rows = run_coro(bot.db.get_reaction_roles(gid))
        panels: dict[int, dict[str, Any]] = {}
        for row in rows:
            panel = panels.setdefault(
                row["message_id"], {"message_id": row["message_id"], "channel_id": row["channel_id"], "pairs": []}
            )
            role = guild.get_role(row["role_id"])
            panel["pairs"].append({"emoji": row["emoji"], "role": role.name if role else "رتبة محذوفة"})
        for panel in panels.values():
            channel = guild.get_channel(panel["channel_id"])
            panel["channel"] = channel.name if channel else "قناة محذوفة"
            panel["url"] = f"https://discord.com/channels/{gid}/{panel['channel_id']}/{panel['message_id']}"

        return render_template(
            "reactionroles.html", guild=guild, panels=list(panels.values()),
            channels=text_channels(guild), roles=assignable_roles(guild),
        )

    # ------------------------------------------------------------------
    # نظام المستويات
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/levels", methods=["GET", "POST"])
    @login_required
    def guild_levels(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id
        levels_cog = bot.get_cog("Levels")

        if request.method == "POST":
            form = request.form
            action = form.get("action")

            if action == "save":
                xp_min, xp_max = to_int(form.get("xp_min")), to_int(form.get("xp_max"))
                cooldown = to_int(form.get("xp_cooldown"))
                valid = (xp_min is None) == (xp_max is None)
                if xp_min is not None and xp_max is not None and not (1 <= xp_min <= xp_max <= 1000):
                    valid = False
                if cooldown is not None and not (5 <= cooldown <= 3600):
                    valid = False

                if not valid:
                    flash("القيم غير صحيحة: الحد الأدنى ≤ الأعلى ≤ 1000، والانتظار بين 5 و3600 ثانية.", "error")
                else:
                    async def save():
                        s = bot.db.set_guild_setting
                        await s(gid, "levels_enabled", int(bool(form.get("levels_enabled"))))
                        await s(gid, "levelup_messages", int(bool(form.get("levelup_messages"))))
                        await s(gid, "levelup_channel_id", to_int(form.get("levelup_channel_id")))
                        await s(gid, "xp_min", xp_min)
                        await s(gid, "xp_max", xp_max)
                        await s(gid, "xp_cooldown", cooldown)

                    run_coro(save())
                    if levels_cog:
                        levels_cog.invalidate(gid)
                    flash("تم حفظ إعدادات المستويات.", "success")

            elif action == "add_role":
                level, role_id = to_int(form.get("level")), to_int(form.get("role_id"))
                role = guild.get_role(role_id) if role_id else None
                if level is None or not (1 <= level <= 500) or role is None:
                    flash("أدخل مستوى (1-500) واختر رتبة.", "error")
                elif role.managed or role.is_default() or (guild.me and role >= guild.me.top_role):
                    flash("لا يستطيع البوت منح هذه الرتبة. ارفع رتبة JiroBot فوقها.", "error")
                else:
                    run_coro(bot.db.set_level_role(gid, level, role.id))
                    flash("تمت إضافة مكافأة الرتبة.", "success")

            elif action == "delete_role":
                level = to_int(form.get("level"))
                if level is not None:
                    run_coro(bot.db.remove_level_role(gid, level))
                    flash("تم الحذف.", "success")
            return done(guild_id, "guild_levels")

        settings = run_coro(bot.db.get_guild_settings(gid))
        level_roles = []
        for row in run_coro(bot.db.get_level_roles(gid)):
            role = guild.get_role(row["role_id"])
            level_roles.append({"level": row["level"], "role": role.name if role else "رتبة محذوفة"})

        top = []
        for rank, row in enumerate(run_coro(bot.db.get_top_levels(gid, 10)), start=1):
            member = guild.get_member(row["user_id"])
            name = member.display_name if member else (row["username"] or str(row["user_id"]))
            top.append({"rank": rank, "name": name, "level": row["level"], "xp": f"{row['xp']:,}"})

        return render_template(
            "levels.html", guild=guild, settings=settings, channels=text_channels(guild), roles=assignable_roles(guild),
            level_roles=level_roles, top=top,
            defaults={"xp_min": config.XP_MIN, "xp_max": config.XP_MAX, "xp_cooldown": config.XP_COOLDOWN_SECONDS},
        )

    # ------------------------------------------------------------------
    # الرد التلقائي
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/autorespond", methods=["GET", "POST"])
    @login_required
    def guild_autorespond(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id

        if request.method == "POST":
            trigger = request.form.get("trigger", "").strip()[:200]
            response_text = request.form.get("response", "").strip()[:1900]
            match_type = "exact" if request.form.get("match_type") == "exact" else "contains"
            if not trigger or not response_text:
                flash("أدخل الكلمة والرد.", "error")
            else:
                run_coro(bot.db.add_auto_response(gid, trigger, response_text, match_type, int(time.time())))
                cog = bot.get_cog("AutoRespond")
                if cog:
                    cog.invalidate(gid)
                flash("تمت الإضافة.", "success")
            return done(guild_id, "guild_autorespond")

        responses = run_coro(bot.db.get_auto_responses(gid))
        return render_template("autorespond.html", guild=guild, responses=responses)

    @app.route("/guild/<guild_id>/autorespond/<int:response_id>/delete", methods=["POST"])
    @login_required
    def guild_autorespond_delete(guild_id: str, response_id: int):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        run_coro(bot.db.remove_auto_response(guild.id, response_id))
        cog = bot.get_cog("AutoRespond")
        if cog:
            cog.invalidate(guild.id)
        flash("تم الحذف.", "success")
        return done(guild_id, "guild_autorespond")

    # ------------------------------------------------------------------
    # تفاعلات القنوات
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/channelreactions", methods=["GET", "POST"])
    @login_required
    def guild_channelreactions(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id
        cog = bot.get_cog("ChannelReactions")

        if request.method == "POST":
            form = request.form
            action = form.get("action")
            channel_id = to_int(form.get("channel_id"))

            if action == "add":
                emojis = form.get("emojis", "").split()[:20]
                if not isinstance(guild.get_channel(channel_id) if channel_id else None, discord.TextChannel) or not emojis:
                    flash("اختر قناة نصية وأدخل إيموجي واحدًا على الأقل.", "error")
                else:
                    run_coro(bot.db.set_channel_reactions(gid, channel_id, " ".join(emojis)))
                    flash("تم الحفظ.", "success")
            elif action == "delete" and channel_id:
                run_coro(bot.db.remove_channel_reactions(gid, channel_id))
                flash("تم الحذف.", "success")

            if cog:
                cog.invalidate(gid)
            return done(guild_id, "guild_channelreactions")

        rules = []
        for row in run_coro(bot.db.get_channel_reactions(gid)):
            channel = guild.get_channel(row["channel_id"])
            rules.append(
                {"channel_id": row["channel_id"], "channel": channel.name if channel else "قناة محذوفة",
                 "emojis": row["emojis"].split()}
            )
        return render_template("channelreactions.html", guild=guild, rules=rules, channels=text_channels(guild))

    # ------------------------------------------------------------------
    # رتب الألوان
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/colorroles", methods=["GET", "POST"])
    @login_required
    def guild_colorroles(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id
        cog = bot.get_cog("ColorRoles")

        if request.method == "POST":
            form = request.form
            action = form.get("action")
            if cog is None:
                flash("نظام رتب الألوان غير محمّل.", "error")
            elif action == "create":
                name = form.get("name", "").strip()[:100]
                if not name:
                    flash("أدخل اسم اللون.", "error")
                else:
                    ok, error = run_coro(cog.create_color_role(guild, name, parse_color(form.get("color"))))
                    flash("تم إنشاء رتبة اللون." if ok else (error or "حدث خطأ."), "success" if ok else "error")
            elif action == "link":
                ok, error = run_coro(
                    cog.link_color_role(guild, to_int(form.get("role_id")), form.get("label", "").strip()[:100])
                )
                flash("تم ربط الرتبة." if ok else (error or "حدث خطأ."), "success" if ok else "error")
            elif action == "delete":
                role_id = to_int(form.get("role_id"))
                if role_id:
                    run_coro(cog.remove_color_role(guild, role_id, bool(form.get("delete_role"))))
                    flash("تم الحذف.", "success")
            elif action == "panel":
                ok, error = run_coro(
                    cog.send_panel(
                        guild, to_int(form.get("channel_id")), form.get("title", "").strip()[:200],
                        form.get("description", "").strip()[:1500],
                    )
                )
                flash("تم إرسال اللوحة." if ok else (error or "حدث خطأ."), "success" if ok else "error")
            return done(guild_id, "guild_colorroles")

        colors = []
        for row in run_coro(bot.db.get_color_roles(gid)):
            role = guild.get_role(row["role_id"])
            colors.append(
                {"role_id": row["role_id"], "label": row["label"], "role": role.name if role else "رتبة محذوفة",
                 "hex": f"#{role.color.value:06x}" if role and role.color.value else "#99aab5"}
            )
        return render_template(
            "colorroles.html", guild=guild, colors=colors, channels=text_channels(guild), roles=assignable_roles(guild)
        )

    # ------------------------------------------------------------------
    # المؤقتات
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/timers", methods=["GET", "POST"])
    @login_required
    def guild_timers(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id

        if request.method == "POST":
            form = request.form
            action = form.get("action")
            now = int(time.time())

            if action == "add":
                channel_id = to_int(form.get("channel_id"))
                message = form.get("message", "").strip()[:1900]
                value = to_int(form.get("interval"))
                unit = {"minutes": 1, "hours": 60, "days": 1440}.get(form.get("unit", "minutes"), 1)
                minutes = value * unit if value else 0
                existing = run_coro(bot.db.get_timers(gid))

                if not isinstance(guild.get_channel(channel_id) if channel_id else None, discord.TextChannel):
                    flash("اختر قناة نصية.", "error")
                elif not message:
                    flash("اكتب نص الرسالة.", "error")
                elif not (5 <= minutes <= 43200):
                    flash("الفترة يجب أن تكون بين 5 دقائق و30 يومًا.", "error")
                elif len(existing) >= 10:
                    flash("الحد الأقصى 10 مؤقتات لكل سيرفر.", "error")
                else:
                    first_run = now if form.get("send_now") else now + minutes * 60
                    run_coro(bot.db.add_timer(gid, channel_id, message, minutes, first_run))
                    flash("تمت إضافة المؤقت.", "success")

            elif action == "toggle":
                timer_id = to_int(form.get("timer_id"))
                enable = form.get("enable") == "1"
                row = next((t for t in run_coro(bot.db.get_timers(gid)) if t["id"] == timer_id), None)
                if row:
                    run_coro(bot.db.set_timer_enabled(gid, timer_id, enable, now + row["interval_minutes"] * 60))
                    flash("تم التحديث.", "success")

            elif action == "delete":
                timer_id = to_int(form.get("timer_id"))
                if timer_id:
                    run_coro(bot.db.remove_timer(gid, timer_id))
                    flash("تم الحذف.", "success")
            return done(guild_id, "guild_timers")

        timers = []
        for row in run_coro(bot.db.get_timers(gid)):
            channel = guild.get_channel(row["channel_id"])
            timers.append(
                {"id": row["id"], "channel": channel.name if channel else "قناة محذوفة", "message": row["message"],
                 "interval_text": interval_text(row["interval_minutes"]), "next_run": row["next_run"],
                 "enabled": bool(row["enabled"])}
            )
        return render_template("timers.html", guild=guild, timers=timers, channels=text_channels(guild))

    # ------------------------------------------------------------------
    # الإيموجيات
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/emojis", methods=["GET", "POST"])
    @login_required
    def guild_emojis(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))

        if request.method == "POST":
            action = request.form.get("action")

            if action == "create":
                name = re.sub(r"[^A-Za-z0-9_]", "", request.form.get("name", ""))
                upload = request.files.get("file")
                if not (2 <= len(name) <= 32):
                    flash("اسم الإيموجي: من 2 إلى 32 حرفًا إنجليزيًا أو أرقامًا أو _", "error")
                elif upload is None or not upload.filename:
                    flash("اختر صورة للرفع.", "error")
                else:
                    data = upload.read()
                    if len(data) > 256 * 1024:
                        flash("حجم الصورة يجب ألا يتجاوز 256KB.", "error")
                    elif not data.startswith((b"\x89PNG", b"\xff\xd8", b"GIF8")):
                        flash("الصيغة غير مدعومة. استخدم PNG أو JPG أو GIF.", "error")
                    else:
                        async def create() -> str | None:
                            try:
                                await guild.create_custom_emoji(name=name, image=data, reason="JiroBot dashboard")
                            except discord.HTTPException as exc:
                                return exc.text or "تعذر إنشاء الإيموجي."
                            return None

                        error = run_coro(create())
                        flash(error or "تمت إضافة الإيموجي.", "error" if error else "success")

            elif action == "delete":
                emoji_id = to_int(request.form.get("emoji_id"))

                async def delete() -> None:
                    emoji = guild.get_emoji(emoji_id) if emoji_id else None
                    if emoji is not None:
                        await emoji.delete(reason="JiroBot dashboard")

                try:
                    run_coro(delete())
                    flash("تم حذف الإيموجي.", "success")
                except discord.HTTPException:
                    flash("تعذر حذف الإيموجي.", "error")
            return done(guild_id, "guild_emojis")

        emojis = [
            {"id": e.id, "name": e.name, "url": str(e.url), "animated": e.animated,
             "code": f"<{'a' if e.animated else ''}:{e.name}:{e.id}>"}
            for e in guild.emojis
        ]
        return render_template("emojis.html", guild=guild, emojis=emojis, limit=guild.emoji_limit)

    # ------------------------------------------------------------------
    # أوامر مخصصة
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/customcommands", methods=["GET", "POST"])
    @login_required
    def guild_customcommands(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id
        cog = bot.get_cog("CustomCommands")

        if request.method == "POST":
            form = request.form
            action = form.get("action")

            if action == "prefix":
                prefix = form.get("prefix", "").strip()
                if not (1 <= len(prefix) <= 3) or any(ch.isspace() for ch in prefix):
                    flash("البادئة من 1 إلى 3 رموز بدون مسافات.", "error")
                else:
                    run_coro(bot.db.set_guild_setting(gid, "custom_prefix", prefix))
                    flash("تم حفظ البادئة.", "success")
            elif action == "add":
                name = re.sub(r"\s+", "", form.get("name", "")).lower()[:32]
                response = form.get("response", "").strip()[:1900]
                existing = run_coro(bot.db.get_custom_commands(gid))
                if not name or not response:
                    flash("أدخل اسم الأمر والرد.", "error")
                elif len(existing) >= 50 and name not in {r["name"] for r in existing}:
                    flash("الحد الأقصى 50 أمرًا لكل سيرفر.", "error")
                else:
                    run_coro(bot.db.set_custom_command(gid, name, response))
                    flash("تم حفظ الأمر.", "success")
            elif action == "delete":
                run_coro(bot.db.remove_custom_command(gid, form.get("name", "")))
                flash("تم الحذف.", "success")

            if cog:
                cog.invalidate(gid)
            return done(guild_id, "guild_customcommands")

        settings = run_coro(bot.db.get_guild_settings(gid))
        commands_list = run_coro(bot.db.get_custom_commands(gid))
        return render_template(
            "customcommands.html", guild=guild, prefix=settings["custom_prefix"] or "!", commands_list=commands_list
        )

    # ------------------------------------------------------------------
    # السجلات
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/logs", methods=["GET", "POST"])
    @login_required
    def guild_logs(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id

        if request.method == "POST":
            form = request.form

            async def save():
                for key in ("logs_channel_id", "roles_log_channel_id", "channels_log_channel_id", "voice_log_channel_id"):
                    await bot.db.set_guild_setting(gid, key, to_int(form.get(key)))

            run_coro(save())
            flash("تم حفظ إعدادات السجلات.", "success")
            return done(guild_id, "guild_logs")

        settings = run_coro(bot.db.get_guild_settings(gid))
        return render_template("logs.html", guild=guild, settings=settings, channels=text_channels(guild))

    # ------------------------------------------------------------------
    # الحماية التلقائية
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/automod", methods=["GET", "POST"])
    @login_required
    def guild_automod(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        gid = guild.id

        if request.method == "POST":
            form = request.form
            action = form.get("action")

            if action == "save":
                async def save():
                    s = bot.db.set_guild_setting
                    await s(gid, "automod_enabled", int(bool(form.get("automod_enabled"))))
                    await s(gid, "automod_links", int(bool(form.get("automod_links"))))
                    await s(gid, "automod_spam", int(bool(form.get("automod_spam"))))
                    await s(gid, "automod_words", int(bool(form.get("automod_words"))))

                run_coro(save())
                flash("تم حفظ إعدادات الحماية.", "success")
            elif action == "add_word":
                word = form.get("word", "").strip().lower()
                if not word or " " in word:
                    flash("أدخل كلمة واحدة بدون مسافات.", "error")
                else:
                    run_coro(bot.db.add_automod_word(gid, word))
                    flash("تمت إضافة الكلمة.", "success")
            elif action == "remove_word":
                run_coro(bot.db.remove_automod_word(gid, form.get("word", "").strip().lower()))
                flash("تمت إزالة الكلمة.", "success")

            cog = bot.get_cog("AutoMod")
            if cog:
                cog._invalidate_words(gid)  # type: ignore[attr-defined]
            return done(guild_id, "guild_automod")

        settings = run_coro(bot.db.get_guild_settings(gid))
        words = run_coro(bot.db.get_automod_words(gid))
        return render_template("automod.html", guild=guild, settings=settings, words=words)

    # ------------------------------------------------------------------
    # إرسال Embed
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/embed", methods=["GET", "POST"])
    @login_required
    def guild_embed(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))

        if request.method == "POST":
            form = request.form
            channel_id = to_int(form.get("channel_id"))
            title = form.get("title", "").strip()[:250]
            description = form.get("description", "").strip()[:3500]
            footer_text = form.get("footer_text", "").strip()[:200]
            image_url = form.get("image_url", "").strip()
            thumbnail_url = form.get("thumbnail_url", "").strip()
            color_value = parse_color(form.get("color"))

            if channel_id is None:
                flash("اختر قناة أولًا.", "error")
                return done(guild_id, "guild_embed")
            if not title and not description:
                flash("أدخل عنوانًا أو نصًا للـ Embed على الأقل.", "error")
                return done(guild_id, "guild_embed")

            async def send() -> tuple[bool, str | None]:
                channel = guild.get_channel(channel_id)
                if not isinstance(channel, discord.TextChannel):
                    return False, "القناة غير صالحة."
                permissions = channel.permissions_for(guild.me)
                if not (permissions.send_messages and permissions.embed_links):
                    return False, f"البوت لا يملك صلاحية الإرسال في #{channel.name}."

                embed = discord.Embed(
                    title=title or None, description=description or None, color=color_value,
                    timestamp=discord.utils.utcnow(),
                )
                embed.set_footer(text=footer_text or config.FOOTER_TEXT)
                if image_url:
                    embed.set_image(url=image_url)
                if thumbnail_url:
                    embed.set_thumbnail(url=thumbnail_url)
                try:
                    await channel.send(embed=embed)
                except discord.HTTPException:
                    return False, "تعذر الإرسال (تحقق من روابط الصور)."
                return True, None

            ok, error = run_coro(send())
            flash("تم إرسال الـ Embed بنجاح." if ok else (error or "حدث خطأ غير متوقع."), "success" if ok else "error")
            return done(guild_id, "guild_embed")

        return render_template("embed.html", guild=guild, channels=text_channels(guild))

    # ------------------------------------------------------------------
    # الأوامر داخل اللوحة
    # ------------------------------------------------------------------
    @app.route("/guild/<guild_id>/commands")
    @login_required
    def guild_commands(guild_id: str):
        guild = load_guild(guild_id)
        if guild is None:
            return redirect(url_for("guilds"))
        return render_template("commands.html", catalog=COMMAND_CATALOG, layout="guild_base.html", guild=guild)

    log.info("Dashboard starting on http://localhost:%s", config.DASHBOARD_PORT)
    app.run(host="0.0.0.0", port=config.DASHBOARD_PORT, use_reloader=False)
