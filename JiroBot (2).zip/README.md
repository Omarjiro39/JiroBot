<div align="center">

# 🤖 JiroBot | جيرو بوت

### مساعد Discord شامل — مستويات، اقتصاد، حماية، ترحيب، وسجلات، بلوحة تحكم ويب احترافية

<img src="dashboard/static/img/logo.png" alt="JiroBot" width="120">

[![Python](https://img.shields.io/badge/Python-3.11+-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![discord.py](https://img.shields.io/badge/discord.py-2.4+-5865F2?logo=discord&logoColor=white)](https://discordpy.readthedocs.io/)
[![Flask](https://img.shields.io/badge/Flask-3.0-000000?logo=flask)](https://flask.palletsprojects.com/)
[![License](https://img.shields.io/badge/License-MIT-green)](#الترخيص)

**بوت Discord عربي بالكامل مع لوحة تحكم ويب مدمجة — عملية واحدة تخدم الموقع واللوحة والبوت.**
A fully Arabic Discord bot with a built-in web dashboard — one process serves the website, the dashboard, and the bot.

</div>

---

## ✨ المميزات | Features

| القسم | الوصف |
|---|---|
| 📊 **المستويات** | XP من الرسائل، رتب تلقائية، لوحة متصدرين، رسائل ترقية |
| 💰 **الاقتصاد** | عملات Jiro Coins عالمية، مكافآت يومية، عمل، وتحويلات بين الأعضاء مع سجل كامل |
| 🛡️ **الإدارة والحماية** | ban/kick/mute/warn، حماية من الروابط والسبام والكلمات الممنوعة |
| 📝 **السجلات** | سجلات مصنّفة للرتب والقنوات والصوت والرسائل |
| 👋 **الترحيب** | ترحيب ومغادرة، رسائل مخصصة، رتبة تلقائية |
| 🎨 **رتب الألوان** | لوحات رتب بالتفاعل أو بقائمة منسدلة |
| ⏱️ **المؤقتات والأوامر المخصصة** | تذكيرات وأوامر مخصصة لكل سيرفر |
| 🌐 **لوحة تحكم ويب** | لوحة Flask احترافية بتسجيل دخول Discord OAuth2، تدير كل ما سبق من المتصفح |

> البوت موجود في **+22 سيرفر** ويشغّل **33 أمر slash** عالمي.

---

## 🏗️ البنية المعمارية | Architecture

تطبيق **واحد** (عملية Python واحدة) يخدم الثلاثة معاً:

```
┌─────────────────────────────────────────────────────────┐
│                    عملية Python واحدة                     │
│                                                         │
│   discord.py (Gateway)  ◀───────▶  Discord (22 سيرفر)   │
│                                                         │
│   Flask (HTTP :$PORT)                                   │
│     ├─ /           صفحة الهبوط (الموقع)                  │
│     ├─ /commands   قائمة الأوامر                         │
│     ├─ /login      تسجيل دخول Discord OAuth2             │
│     ├─ /callback   استقبال OAuth2                        │
│     ├─ /dashboard  لوحة التحكم                           │
│     ├─ /transactions  سجل التحويلات                      │
│     └─ /guild/<id>/...  إعدادات كل سيرفر                 │
│                                                         │
│   SQLite (database.db)  ◀── يقرأها البوت واللوحة معاً     │
└─────────────────────────────────────────────────────────┘
```

لذلك **لا حاجة لـ Netlify ولا لموقع منفصل** — صفحة الهبوط تُخدم من نفس تطبيق البوت على `/`.

---

## 🚀 النشر السريع | Quick Deploy

### الطريقة الموصى بها: Docker (تعمل على dockhosting.dev وأي استضافة تدعم Docker)

```bash
# 1. ابنِ الصورة
docker build -t jirobot .

# 2. شغّلها (بدّل متغيرات البيئة بقيمك)
docker run -d --name jirobot --restart unless-stopped \
  -p 5000:5000 \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/logs:/app/logs \
  -e DISCORD_TOKEN="توكن_البوت" \
  -e OWNER_ID="آيديك_الشخصي" \
  -e DISCORD_CLIENT_ID="1551563677864300604" \
  -e DISCORD_CLIENT_SECRET="سر_العميل" \
  -e DASHBOARD_SECRET_KEY="مفتاح_عشوائي_64_حرف" \
  -e DASHBOARD_REDIRECT_URI="https://رابطك_العام/callback" \
  -e LOG_LEVEL=INFO \
  jirobot
```

> توليد `DASHBOARD_SECRET_KEY`: `python -c "import secrets; print(secrets.token_hex(32))"`

### على dockhosting.dev

1. ارفع هذا المشروع إلى GitHub (أو اربطه مباشرة).
2. في dockhosting، أنشئ مشروعاً جديداً من المستودع — سيكتشف `Dockerfile` تلقائياً.
3. أضف متغيرات البيئة (الجدول بالأسفل) في إعدادات المشروع.
4. خذ الرابط العام الذي يعطيك إياه dockhosting (`https://مشروعك.dockhosting.cloud`) وضعه في `DASHBOARD_REDIRECT_URI` وفي Discord Developer Portal.
5. تأكد من ربط مجلد `/app/data` بتخزين دائم إن وفّرت الاستضافة ذلك (حتى لا تضيع قاعدة البيانات عند إعادة النشر).

> ⚠️ **ملاحظة صادقة:** صفحة dockhosting.dev تُعرض فيها أمثلة Node.js فقط. إن لم يدعم Python/Docker، استخدم **Fly.io** (ملف `fly.toml` جاهز في الحزمة — يدعم Python + Docker + volume دائم + تشغيل 24/7). كل الملفات هنا تعمل دون تعديل.

---

## ⚙️ متغيرات البيئة | Environment Variables

انسخ `.env.example` إلى `.env` واملأه، أو اضبطها في لوحة الاستضافة:

| المتغير | مطلوب | الوصف |
|---|:---:|---|
| `DISCORD_TOKEN` | ✅ | توكن البوت من Discord Developer Portal |
| `OWNER_ID` | ✅ | آيدي حسابك الشخصي (لأوامر المالك) |
| `DISCORD_CLIENT_ID` | ✅ | `1551563677864300604` |
| `DISCORD_CLIENT_SECRET` | ✅ | من Developer Portal → OAuth2 → General → Client Secret |
| `DASHBOARD_SECRET_KEY` | ✅ | مفتاح جلسة Flask (64 حرفاً عشوائياً) |
| `DASHBOARD_REDIRECT_URI` | ✅ | `https://رابطك_العام/callback` (يطابق Redirects في Developer Portal تماماً) |
| `LOG_LEVEL` | — | `INFO` افتراضياً |

> البورت يُحلّ تلقائياً: `SERVER_PORT` (Pterodactyl) ← `PORT` ← `DASHBOARD_PORT` ← `5000`.

---

## 🔧 إعداد Discord Developer Portal

1. ادخل [discord.com/developers/applications](https://discord.com/developers/applications) → تطبيق البوت.
2. **Bot:** فعّل **SERVER MEMBERS INTENT** و **MESSAGE CONTENT INTENT**، ثم احفظ.
3. **OAuth2 → General:** انسخ **Client Secret** → ضعه في `DISCORD_CLIENT_SECRET`.
4. **OAuth2 → Redirects:** أضف `https://رابطك_العام/callback` (يطابق `DASHBOARD_REDIRECT_URI` تماماً).
5. شغّل البوت، ثم افتح رابطك العام في المتصفح → اضغط «تسجيل الدخول».

---

## 📁 بنية المشروع | Project Structure

```
JiroBot/
├── bot.py                  # نقطة التشغيل (discord.py + Flask في خيط مستقل)
├── config.py               # الإعدادات المركزية (تقرأ env vars)
├── requirements.txt        # اعتماديات Python
├── runtime.txt             # إصدار Python
├── Dockerfile              # صورة Docker (النشر الموصى به)
├── Procfile                # بديل Heroku-style
├── app.json                # بديل Heroku/Docker PaaS
├── fly.toml                # بديل Fly.io
├── render.yaml             # بديل Render
├── koyeb.yaml              # بديل Koyeb
├── railway.json            # بديل Railway
├── .env.example            # قالب متغيرات البيئة
├── .dockerignore / .gitignore
├── cogs/                   # وحدات البوت (19 cog)
│   ├── automod.py  autorespond.py  botinfo.py  channelreactions.py
│   ├── colorroles.py  customcommands.py  economy.py  errors.py
│   ├── events_log.py  help.py  leaderboard.py  levels.py  logs.py
│   ├── moderation.py  owner.py  profile.py  reactionroles.py
│   ├── timers.py  voice_presence.py  welcome.py
├── utils/                  # أدوات مساعدة (database.py ...)
└── dashboard/              # لوحة التحكم Flask
    ├── app.py              # كل المسارات (routes)
    ├── templates/          # قوالب Jinja2 (landing, transactions, ...)
    └── static/             # css/ js/ img/ (logo.png)
```

---

## 🧪 التشغيل محلياً | Run Locally

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # املأ المتغيرات
python bot.py
```
ثم افتح `http://localhost:5000`.

---

## 📜 الأوامر الرئيسية | Key Commands

`/balance` · `/daily` · `/work` · `/pay @user` · `/rank` · `/leaderboard` ·
`/ban` · `/kick` · `/mute` · `/warn` · `/purge` · `/autorole` · `/welcome` ·
`/reactionroles` · `/levels` · `/automod` · `/embed` · `/timer` · `/profile`

(33 أمر slash إجمالاً — اكتب `/help` داخل Discord لرؤيتها كلها.)

---

## ❓ استكشاف الأخطاء | Troubleshooting

- **`Dashboard OAuth2 vars are missing`**: لم تُضبط `DISCORD_CLIENT_ID` و `DASHBOARD_SECRET_KEY`. أضفهما وأعد التشغيل.
- **`Invalid OAuth2 redirect_uri`**: رابط `DASHBOARD_REDIRECT_URI` لا يطابق Redirects في Developer Portal حرفاً بحرف. طابقهما تماماً.
- **`/callback` يعطي 404 على Netlify**: متوقع — `/callback` مسار خادم Flask يعيش على رابط البوت فقط، وليس على Netlify.
- **ضياع البيانات بعد إعادة النشر**: اربط `/app/data` بتخزين دائم (volume). SQLite يكتب إلى `data/database.db`.

---

## 📄 الترخيص | License

رخصة MIT — استخدمه وعدّله بحرية.

<div align="center">

**صُنع بعناية لمجتمع Discord العربي 🇸🇾**

</div>
