"""رتب رد الفعل: من يتفاعل بإيموجي على رسالة اللوحة يحصل على الرتبة."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

import config
from utils.helpers import normalize_emoji

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.reactionroles")


def _can_assign(guild: discord.Guild, role: discord.Role) -> bool:
    me = guild.me
    return bool(me and me.guild_permissions.manage_roles and not role.managed and not role.is_default() and role < me.top_role)


class ReactionRoles(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot
        # guild_id -> {message_id -> {emoji_مُوحَّد -> role_id}}
        self._cache: dict[int, dict[int, dict[str, int]]] = {}

    def invalidate(self, guild_id: int) -> None:
        self._cache.pop(guild_id, None)

    async def _get_map(self, guild_id: int) -> dict[int, dict[str, int]]:
        if guild_id not in self._cache:
            rows = await self.bot.db.get_reaction_roles(guild_id)
            mapping: dict[int, dict[str, int]] = {}
            for row in rows:
                mapping.setdefault(row["message_id"], {})[normalize_emoji(row["emoji"])] = row["role_id"]
            self._cache[guild_id] = mapping
        return self._cache[guild_id]

    # ------------------------------------------------------------------
    # يستدعيها الداشبورد
    # ------------------------------------------------------------------
    async def create_panel(
        self,
        guild: discord.Guild,
        channel_id: int | None,
        title: str,
        description: str,
        color_value: int,
        pairs: list[tuple[str, int]],
    ) -> tuple[bool, str | None]:
        channel = guild.get_channel(channel_id) if channel_id else None
        if not isinstance(channel, discord.TextChannel):
            return False, "اختر قناة نصية صحيحة."

        permissions = channel.permissions_for(guild.me)
        if not (permissions.send_messages and permissions.embed_links and permissions.add_reactions):
            return False, f"البوت يحتاج صلاحيات الإرسال وتضمين الروابط وإضافة التفاعلات في #{channel.name}."

        valid: list[tuple[str, discord.Role]] = []
        seen: set[str] = set()
        for emoji, role_id in pairs:
            role = guild.get_role(role_id)
            key = normalize_emoji(emoji)
            if not key or key in seen or role is None or not _can_assign(guild, role):
                continue
            seen.add(key)
            valid.append((emoji.strip(), role))

        if not valid:
            return False, "أضف إيموجي ورتبة واحدة على الأقل (والرتبة يجب أن تكون أدنى من رتبة البوت)."

        def build_embed(items: list[tuple[str, discord.Role]]) -> discord.Embed:
            lines = "\n".join(f"{emoji} — {role.mention}" for emoji, role in items)
            body = f"{description}\n\n{lines}" if description else lines
            embed = discord.Embed(title=title or None, description=body, color=color_value)
            embed.set_footer(text=config.FOOTER_TEXT)
            return embed

        try:
            message = await channel.send(embed=build_embed(valid))
        except discord.HTTPException:
            return False, "تعذر إرسال الرسالة."

        added: list[tuple[str, discord.Role]] = []
        for emoji, role in valid:
            try:
                await message.add_reaction(emoji)
            except discord.HTTPException:
                continue
            await self.bot.db.add_reaction_role(guild.id, channel.id, message.id, emoji, role.id)
            added.append((emoji, role))

        if not added:
            try:
                await message.delete()
            except discord.HTTPException:
                pass
            return False, "لم يُقبل أي إيموجي. استخدم إيموجي عاديًا أو إيموجي مخصصًا من هذا السيرفر بصيغة <:name:id>."

        if len(added) != len(valid):
            try:
                await message.edit(embed=build_embed(added))
            except discord.HTTPException:
                pass

        self.invalidate(guild.id)
        return True, None

    async def delete_panel(self, guild: discord.Guild, message_id: int) -> None:
        rows = await self.bot.db.get_reaction_roles(guild.id)
        channel_id = next((row["channel_id"] for row in rows if row["message_id"] == message_id), None)
        await self.bot.db.remove_reaction_role_message(guild.id, message_id)
        self.invalidate(guild.id)

        channel = guild.get_channel(channel_id) if channel_id else None
        if isinstance(channel, discord.TextChannel):
            try:
                message = await channel.fetch_message(message_id)
                await message.delete()
            except discord.HTTPException:
                pass

    # ------------------------------------------------------------------
    # التفاعلات
    # ------------------------------------------------------------------
    async def _handle(self, payload: discord.RawReactionActionEvent, add: bool) -> None:
        if payload.guild_id is None or payload.user_id == self.bot.user.id:  # type: ignore[union-attr]
            return

        try:
            mapping = (await self._get_map(payload.guild_id)).get(payload.message_id)
            if not mapping:
                return
            role_id = mapping.get(normalize_emoji(str(payload.emoji)))
            if not role_id:
                return

            guild = self.bot.get_guild(payload.guild_id)
            if guild is None:
                return
            member = guild.get_member(payload.user_id) or payload.member
            if member is None:
                try:
                    member = await guild.fetch_member(payload.user_id)
                except discord.HTTPException:
                    return
            if member.bot:
                return

            role = guild.get_role(role_id)
            if role is None or not _can_assign(guild, role):
                return

            if add:
                await member.add_roles(role, reason="Reaction role")
            else:
                await member.remove_roles(role, reason="Reaction role")
        except discord.HTTPException:
            log.warning("Reaction role update failed (guild=%s)", payload.guild_id)
        except Exception:
            log.exception("Reaction role handler crashed")

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent) -> None:
        await self._handle(payload, add=True)

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent) -> None:
        await self._handle(payload, add=False)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(ReactionRoles(bot))
