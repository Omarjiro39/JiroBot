"""نظام الرد التلقائي: عند كتابة كلمة/عبارة محددة، يرد البوت تلقائيًا."""
from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.embeds import error_embed, make_embed, success_embed

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.autorespond")


class AutoRespond(commands.Cog):
    autorespond_group = app_commands.Group(
        name="autorespond",
        description="إدارة الردود التلقائية",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot
        self._cache: dict[int, list[dict]] = {}

    async def _get_responses(self, guild_id: int) -> list[dict]:
        if guild_id not in self._cache:
            rows = await self.bot.db.get_auto_responses(guild_id)
            self._cache[guild_id] = [dict(row) for row in rows]
        return self._cache[guild_id]

    def invalidate(self, guild_id: int) -> None:
        self._cache.pop(guild_id, None)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.guild is None or message.author.bot:
            return

        try:
            responses = await self._get_responses(message.guild.id)
            if not responses:
                return

            content = message.content.lower().strip()
            for item in responses:
                trigger = item["trigger_text"].lower()
                match = (content == trigger) if item["match_type"] == "exact" else (trigger in content)
                if match:
                    await message.channel.send(item["response"])
                    return
        except Exception:
            log.exception("Auto-respond check failed for message %s", message.id)

    @autorespond_group.command(name="add", description="إضافة رد تلقائي جديد")
    @app_commands.describe(trigger="الكلمة أو العبارة التي تُفعّل الرد", response="نص الرد", match_type="نوع المطابقة")
    @app_commands.choices(
        match_type=[
            app_commands.Choice(name="تحتوي على العبارة", value="contains"),
            app_commands.Choice(name="مطابقة تامة", value="exact"),
        ]
    )
    @app_commands.checks.has_permissions(manage_guild=True)
    async def add(
        self,
        interaction: discord.Interaction,
        trigger: str,
        response: str,
        match_type: Optional[app_commands.Choice[str]] = None,
    ) -> None:
        assert interaction.guild_id is not None
        mode = match_type.value if match_type else "contains"
        await self.bot.db.add_auto_response(interaction.guild_id, trigger, response, mode, int(time.time()))
        self.invalidate(interaction.guild_id)
        await interaction.response.send_message(embed=success_embed(f"تمت إضافة رد تلقائي على: `{trigger}`"))

    @autorespond_group.command(name="remove", description="حذف رد تلقائي بواسطة رقمه")
    @app_commands.describe(response_id="رقم الرد (يظهر في /autorespond list)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def remove(self, interaction: discord.Interaction, response_id: int) -> None:
        assert interaction.guild_id is not None
        count = await self.bot.db.remove_auto_response(interaction.guild_id, response_id)
        self.invalidate(interaction.guild_id)
        if count == 0:
            await interaction.response.send_message(embed=error_embed("لم يتم العثور على رد بهذا الرقم."), ephemeral=True)
            return
        await interaction.response.send_message(embed=success_embed("تم حذف الرد التلقائي."))

    @autorespond_group.command(name="list", description="عرض كل الردود التلقائية")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def list_responses(self, interaction: discord.Interaction) -> None:
        assert interaction.guild_id is not None
        rows = await self.bot.db.get_auto_responses(interaction.guild_id)
        embed = make_embed("💬 الردود التلقائية")
        if not rows:
            embed.description = "لا توجد ردود تلقائية بعد."
        else:
            lines = [f"**#{r['id']}** `{r['trigger_text']}` ({r['match_type']}) → {r['response']}" for r in rows]
            embed.description = "\n".join(lines)
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(AutoRespond(bot))
