"""نظام AutoMod: منع السبام، الروابط، والكلمات الممنوعة، مع إعفاء المشرفين."""
from __future__ import annotations

import logging
import re
import time
from collections import defaultdict, deque
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils.embeds import error_embed, make_embed, success_embed
from utils.logs import send_log_embed

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.automod")

LINK_PATTERN = re.compile(r"(https?://\S+|www\.\S+)", re.IGNORECASE)
SPAM_MESSAGE_LIMIT = 5
SPAM_WINDOW_SECONDS = 6.0


class AutoMod(commands.Cog):
    automod_group = app_commands.Group(
        name="automod",
        description="إعدادات نظام AutoMod",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )
    words_group = app_commands.Group(
        name="words",
        description="إدارة قائمة الكلمات الممنوعة",
        parent=automod_group,
    )

    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot
        # (guild_id, user_id) -> أوقات آخر رسائل (لكشف السبام)، في الذاكرة فقط
        self._recent_messages: dict[tuple[int, int], deque[float]] = defaultdict(lambda: deque(maxlen=SPAM_MESSAGE_LIMIT))
        # cache للكلمات الممنوعة لكل سيرفر حتى لا نستعلم قاعدة البيانات في كل رسالة
        self._word_cache: dict[int, set[str]] = {}

    async def _get_words(self, guild_id: int) -> set[str]:
        if guild_id not in self._word_cache:
            words = await self.bot.db.get_automod_words(guild_id)
            self._word_cache[guild_id] = set(words)
        return self._word_cache[guild_id]

    def _invalidate_words(self, guild_id: int) -> None:
        self._word_cache.pop(guild_id, None)

    @staticmethod
    def _is_exempt(member: discord.Member) -> bool:
        return member.guild_permissions.manage_messages or member.guild_permissions.administrator

    async def _delete_and_warn(self, message: discord.Message, reason: str) -> None:
        try:
            await message.delete()
        except discord.HTTPException:
            pass

        try:
            await message.channel.send(
                f"{message.author.mention} ⚠️ تم حذف رسالتك: {reason}", delete_after=6
            )
        except discord.HTTPException:
            pass

        assert message.guild is not None
        embed = make_embed("🛡️ AutoMod", color=config.WARNING_AMBER)
        embed.add_field(name="العضو", value=f"{message.author.mention} (`{message.author.id}`)", inline=False)
        embed.add_field(name="القناة", value=message.channel.mention, inline=False)
        embed.add_field(name="السبب", value=reason, inline=False)
        await send_log_embed(self.bot, message.guild, embed)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.guild is None or message.author.bot:
            return
        if not isinstance(message.author, discord.Member) or self._is_exempt(message.author):
            return

        try:
            settings = await self.bot.db.get_guild_settings(message.guild.id)
            if not settings["automod_enabled"]:
                return

            # --- الروابط ---
            if settings["automod_links"] and LINK_PATTERN.search(message.content):
                await self._delete_and_warn(message, "الروابط ممنوعة في هذا السيرفر.")
                return

            # --- الكلمات الممنوعة ---
            if settings["automod_words"]:
                words = await self._get_words(message.guild.id)
                if words:
                    message_words = set(re.findall(r"[\w']+", message.content.lower()))
                    if message_words & words:
                        await self._delete_and_warn(message, "رسالتك تحتوي على كلمة ممنوعة.")
                        return

            # --- السبام ---
            if settings["automod_spam"]:
                key = (message.guild.id, message.author.id)
                now = time.monotonic()
                bucket = self._recent_messages[key]
                bucket.append(now)
                if len(bucket) == SPAM_MESSAGE_LIMIT and (now - bucket[0]) <= SPAM_WINDOW_SECONDS:
                    await self._delete_and_warn(message, "تم اكتشاف سبام (رسائل متكررة بسرعة).")
                    bucket.clear()
                    return
        except Exception:
            log.exception("AutoMod check failed for message %s", message.id)

    # ------------------------------------------------------------------
    # /automod enable | disable | links | spam
    # ------------------------------------------------------------------
    @automod_group.command(name="enable", description="تشغيل نظام AutoMod")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def automod_enable(self, interaction: discord.Interaction) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "automod_enabled", 1)
        await interaction.response.send_message(embed=success_embed("تم تشغيل نظام AutoMod."))

    @automod_group.command(name="disable", description="إيقاف نظام AutoMod بالكامل")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def automod_disable(self, interaction: discord.Interaction) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "automod_enabled", 0)
        await interaction.response.send_message(embed=success_embed("تم إيقاف نظام AutoMod."))

    @automod_group.command(name="links", description="تشغيل/إيقاف منع الروابط")
    @app_commands.describe(enabled="تشغيل (True) أو إيقاف (False)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def automod_links(self, interaction: discord.Interaction, enabled: bool) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "automod_links", int(enabled))
        text = "تم تفعيل منع الروابط." if enabled else "تم إيقاف منع الروابط."
        await interaction.response.send_message(embed=success_embed(text))

    @automod_group.command(name="spam", description="تشغيل/إيقاف كشف السبام")
    @app_commands.describe(enabled="تشغيل (True) أو إيقاف (False)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def automod_spam(self, interaction: discord.Interaction, enabled: bool) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "automod_spam", int(enabled))
        text = "تم تفعيل كشف السبام." if enabled else "تم إيقاف كشف السبام."
        await interaction.response.send_message(embed=success_embed(text))

    # ------------------------------------------------------------------
    # /automod words add | remove | list
    # ------------------------------------------------------------------
    @words_group.command(name="add", description="إضافة كلمة للقائمة الممنوعة")
    @app_commands.describe(word="الكلمة (بدون مسافات)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def words_add(self, interaction: discord.Interaction, word: str) -> None:
        assert interaction.guild_id is not None
        clean_word = word.strip().lower()
        if not clean_word or " " in clean_word:
            await interaction.response.send_message(embed=error_embed("أدخل كلمة واحدة بدون مسافات."), ephemeral=True)
            return

        await self.bot.db.add_automod_word(interaction.guild_id, clean_word)
        await self.bot.db.set_guild_setting(interaction.guild_id, "automod_words", 1)
        self._invalidate_words(interaction.guild_id)
        await interaction.response.send_message(embed=success_embed("تمت إضافة الكلمة إلى القائمة الممنوعة."))

    @words_group.command(name="remove", description="إزالة كلمة من القائمة الممنوعة")
    @app_commands.describe(word="الكلمة")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def words_remove(self, interaction: discord.Interaction, word: str) -> None:
        assert interaction.guild_id is not None
        clean_word = word.strip().lower()
        count = await self.bot.db.remove_automod_word(interaction.guild_id, clean_word)
        self._invalidate_words(interaction.guild_id)

        if count == 0:
            await interaction.response.send_message(embed=error_embed("هذه الكلمة غير موجودة في القائمة."), ephemeral=True)
            return
        await interaction.response.send_message(embed=success_embed("تمت إزالة الكلمة من القائمة الممنوعة."))

    @words_group.command(name="list", description="عرض قائمة الكلمات الممنوعة")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def words_list(self, interaction: discord.Interaction) -> None:
        assert interaction.guild_id is not None
        words = await self.bot.db.get_automod_words(interaction.guild_id)

        embed = make_embed("🚫 الكلمات الممنوعة")
        embed.description = ", ".join(f"`{w}`" for w in words) if words else "لا توجد كلمات ممنوعة حاليًا."
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(AutoMod(bot))
