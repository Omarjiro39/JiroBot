"""المؤقتات: رسائل تُرسل تلقائيًا كل فترة محددة."""
from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING

import discord
from discord.ext import commands, tasks

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.timers")


class Timers(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    async def cog_load(self) -> None:
        self.check_timers.start()

    async def cog_unload(self) -> None:
        self.check_timers.cancel()

    @tasks.loop(seconds=30)
    async def check_timers(self) -> None:
        now = int(time.time())
        try:
            rows = await self.bot.db.get_due_timers(now)
        except Exception:
            log.exception("Could not read due timers")
            return

        for row in rows:
            guild = self.bot.get_guild(row["guild_id"])
            channel = guild.get_channel(row["channel_id"]) if guild else None
            if isinstance(channel, discord.TextChannel) and channel.permissions_for(guild.me).send_messages:
                try:
                    await channel.send(row["message"])
                except discord.HTTPException:
                    log.warning("Timer %s failed to send", row["id"])
            # إذا كان البوت متوقفًا مدة طويلة يُرسل مرة واحدة فقط ثم يُجدول من الآن
            await self.bot.db.set_timer_next_run(row["id"], now + row["interval_minutes"] * 60)

    @check_timers.before_loop
    async def before_check_timers(self) -> None:
        await self.bot.wait_until_ready()


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Timers(bot))
