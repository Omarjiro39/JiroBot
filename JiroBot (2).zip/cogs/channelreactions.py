"""تفاعلات القنوات: يضيف البوت إيموجيات تلقائيًا على كل رسالة في قنوات محددة."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.channelreactions")


class ChannelReactions(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot
        self._cache: dict[int, dict[int, list[str]]] = {}

    def invalidate(self, guild_id: int) -> None:
        self._cache.pop(guild_id, None)

    async def _rules(self, guild_id: int) -> dict[int, list[str]]:
        if guild_id not in self._cache:
            rows = await self.bot.db.get_channel_reactions(guild_id)
            self._cache[guild_id] = {row["channel_id"]: row["emojis"].split() for row in rows}
        return self._cache[guild_id]

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.guild is None or message.author.id == self.bot.user.id:  # type: ignore[union-attr]
            return

        try:
            emojis = (await self._rules(message.guild.id)).get(message.channel.id)
            if not emojis:
                return
            if not message.channel.permissions_for(message.guild.me).add_reactions:  # type: ignore[union-attr]
                return
            for emoji in emojis:
                try:
                    await message.add_reaction(emoji)
                except discord.HTTPException:
                    continue
        except Exception:
            log.exception("Channel reactions failed for message %s", message.id)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(ChannelReactions(bot))
