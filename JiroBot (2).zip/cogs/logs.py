"""أوامر /logs لتحديد قنوات السجلات (العامة، الرتب، القنوات، الصوت)."""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.embeds import error_embed, success_embed

if TYPE_CHECKING:
    from bot import JiroBot


class Logs(commands.Cog):
    logs_group = app_commands.Group(
        name="logs",
        description="إعدادات قنوات السجلات",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    async def _set_channel(
        self, interaction: discord.Interaction, column: str, channel: Optional[discord.TextChannel], label: str
    ) -> None:
        assert interaction.guild is not None and interaction.guild_id is not None

        if channel is None:
            await self.bot.db.set_guild_setting(interaction.guild_id, column, None)
            await interaction.response.send_message(embed=success_embed(f"تم إيقاف {label} (سترجع للقناة العامة إن وُجدت)."))
            return

        permissions = channel.permissions_for(interaction.guild.me)
        if not (permissions.view_channel and permissions.send_messages and permissions.embed_links):
            await interaction.response.send_message(
                embed=error_embed(f"البوت لا يستطيع الإرسال في {channel.mention}."), ephemeral=True
            )
            return

        await self.bot.db.set_guild_setting(interaction.guild_id, column, channel.id)
        await interaction.response.send_message(embed=success_embed(f"سيتم إرسال {label} في {channel.mention}."))

    @logs_group.command(name="channel", description="تحديد قناة السجلات العامة (الاحتياطية لكل الأنواع)")
    @app_commands.describe(channel="القناة (اتركها فارغة للإيقاف)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def logs_channel(self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None) -> None:
        await self._set_channel(interaction, "logs_channel_id", channel, "السجلات العامة")

    @logs_group.command(name="roles", description="تحديد قناة سجل الرتب (إنشاء/حذف/تحديث رتب، وتغيير رتب الأعضاء)")
    @app_commands.describe(channel="القناة (اتركها فارغة لاستخدام القناة العامة)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def logs_roles(self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None) -> None:
        await self._set_channel(interaction, "roles_log_channel_id", channel, "سجل الرتب")

    @logs_group.command(name="channels", description="تحديد قناة سجل القنوات (إنشاء/حذف/تحديث القنوات)")
    @app_commands.describe(channel="القناة (اتركها فارغة لاستخدام القناة العامة)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def logs_channels(self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None) -> None:
        await self._set_channel(interaction, "channels_log_channel_id", channel, "سجل القنوات")

    @logs_group.command(name="voice", description="تحديد قناة سجل الصوت (دخول/خروج/انتقال بين رومات الفويس)")
    @app_commands.describe(channel="القناة (اتركها فارغة لاستخدام القناة العامة)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def logs_voice(self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None) -> None:
        await self._set_channel(interaction, "voice_log_channel_id", channel, "سجل الصوت")


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Logs(bot))
