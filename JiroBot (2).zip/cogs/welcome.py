"""رسائل الترحيب والمغادرة، الترحيب الخاص (DM)، والرتبة التلقائية."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils.embeds import error_embed, make_embed, success_embed

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.welcome")

DEFAULT_DM_MESSAGE = "أهلاً بك في **{server}**! نتمنى لك وقتًا ممتعًا معنا."


def _format_message(template: str, member: discord.Member) -> str:
    return (
        template.replace("{user}", member.mention)
        .replace("{username}", member.display_name)
        .replace("{server}", member.guild.name)
        .replace("{count}", str(member.guild.member_count or 0))
    )


def _can_assign(guild: discord.Guild, role: discord.Role) -> bool:
    me = guild.me
    return bool(
        me
        and me.guild_permissions.manage_roles
        and not role.managed
        and not role.is_default()
        and role < me.top_role
    )


class Welcome(commands.Cog):
    welcome_group = app_commands.Group(
        name="welcome", description="إعدادات رسائل الترحيب", guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )
    leave_group = app_commands.Group(
        name="leave", description="إعدادات رسائل المغادرة", guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------
    # الأحداث
    # ------------------------------------------------------------------
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        settings = await self.bot.db.get_guild_settings(member.guild.id)
        for step in (self._give_autorole, self._send_welcome, self._send_dm):
            try:
                await step(member, settings)
            except Exception:
                log.exception("Welcome step %s failed in guild %s", step.__name__, member.guild.id)

    async def _give_autorole(self, member: discord.Member, settings) -> None:
        if not settings["autorole_enabled"] or not settings["autorole_role_id"]:
            return
        role = member.guild.get_role(settings["autorole_role_id"])
        if role is None or not _can_assign(member.guild, role):
            return
        try:
            await member.add_roles(role, reason="JiroBot auto role")
        except discord.HTTPException:
            log.warning("Could not give auto role in guild %s", member.guild.id)

    async def _send_welcome(self, member: discord.Member, settings) -> None:
        if not settings["welcome_enabled"] or not settings["welcome_channel_id"]:
            return
        channel = member.guild.get_channel(settings["welcome_channel_id"])
        if not isinstance(channel, discord.TextChannel):
            return
        permissions = channel.permissions_for(member.guild.me)
        if not (permissions.send_messages and permissions.embed_links):
            return

        template = settings["welcome_message"] or config.DEFAULT_WELCOME_MESSAGE
        embed = make_embed("عضو جديد", _format_message(template, member))
        embed.set_thumbnail(url=member.display_avatar.url)
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            log.warning("Could not send welcome message in guild %s", member.guild.id)

    async def _send_dm(self, member: discord.Member, settings) -> None:
        if member.bot or not settings["welcome_dm_enabled"]:
            return
        template = settings["welcome_dm_message"] or DEFAULT_DM_MESSAGE
        embed = make_embed("أهلاً بك", _format_message(template, member))
        try:
            await member.send(embed=embed)
        except discord.HTTPException:
            pass  # الخاص مغلق عند العضو

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        settings = await self.bot.db.get_guild_settings(member.guild.id)
        if not settings["leave_enabled"] or not settings["leave_channel_id"]:
            return

        channel = member.guild.get_channel(settings["leave_channel_id"])
        if not isinstance(channel, discord.TextChannel):
            return

        permissions = channel.permissions_for(member.guild.me)
        if not (permissions.send_messages and permissions.embed_links):
            return

        template = settings["leave_message"] or config.DEFAULT_LEAVE_MESSAGE
        embed = make_embed("مغادرة عضو", _format_message(template, member), color=config.WARNING_AMBER)
        embed.set_thumbnail(url=member.display_avatar.url)
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            log.warning("Could not send leave message in guild %s", member.guild.id)

    # ------------------------------------------------------------------
    # /welcome ...
    # ------------------------------------------------------------------
    @welcome_group.command(name="enable", description="تشغيل رسائل الترحيب")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def welcome_enable(self, interaction: discord.Interaction) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "welcome_enabled", 1)
        await interaction.response.send_message(embed=success_embed("تم تشغيل رسائل الترحيب."))

    @welcome_group.command(name="disable", description="إيقاف رسائل الترحيب")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def welcome_disable(self, interaction: discord.Interaction) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "welcome_enabled", 0)
        await interaction.response.send_message(embed=success_embed("تم إيقاف رسائل الترحيب."))

    @welcome_group.command(name="channel", description="تحديد قناة الترحيب")
    @app_commands.describe(channel="القناة")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def welcome_channel(self, interaction: discord.Interaction, channel: discord.TextChannel) -> None:
        assert interaction.guild is not None
        permissions = channel.permissions_for(interaction.guild.me)
        if not (permissions.send_messages and permissions.embed_links):
            await interaction.response.send_message(
                embed=error_embed(f"البوت لا يستطيع الإرسال في {channel.mention}."), ephemeral=True
            )
            return
        await self.bot.db.set_guild_setting(interaction.guild_id, "welcome_channel_id", channel.id)
        await interaction.response.send_message(embed=success_embed(f"ستُرسل رسائل الترحيب في {channel.mention}."))

    @welcome_group.command(name="message", description="تخصيص نص رسالة الترحيب")
    @app_commands.describe(text="النص. المتغيرات المتاحة: {user} {username} {server} {count}")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def welcome_message(self, interaction: discord.Interaction, text: str) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "welcome_message", text)
        await interaction.response.send_message(embed=success_embed(f"تم تحديث رسالة الترحيب:\n\n{text}"))

    @welcome_group.command(name="dm", description="تشغيل/إيقاف الترحيب الخاص (DM)")
    @app_commands.describe(enabled="تشغيل (True) أو إيقاف (False)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def welcome_dm(self, interaction: discord.Interaction, enabled: bool) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "welcome_dm_enabled", int(enabled))
        text = "تم تشغيل الترحيب الخاص." if enabled else "تم إيقاف الترحيب الخاص."
        await interaction.response.send_message(embed=success_embed(text))

    @welcome_group.command(name="autorole", description="تحديد الرتبة التلقائية للأعضاء الجدد (فارغ للإيقاف)")
    @app_commands.describe(role="الرتبة (اتركها فارغة للإيقاف)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def welcome_autorole(self, interaction: discord.Interaction, role: Optional[discord.Role] = None) -> None:
        assert interaction.guild is not None
        if role is None:
            await self.bot.db.set_guild_setting(interaction.guild_id, "autorole_enabled", 0)
            await self.bot.db.set_guild_setting(interaction.guild_id, "autorole_role_id", None)
            await interaction.response.send_message(embed=success_embed("تم إيقاف الرتبة التلقائية."))
            return

        if not _can_assign(interaction.guild, role):
            await interaction.response.send_message(
                embed=error_embed("لا يستطيع البوت منح هذه الرتبة. ارفع رتبة JiroBot فوقها من إعدادات السيرفر."),
                ephemeral=True,
            )
            return

        await self.bot.db.set_guild_setting(interaction.guild_id, "autorole_enabled", 1)
        await self.bot.db.set_guild_setting(interaction.guild_id, "autorole_role_id", role.id)
        await interaction.response.send_message(embed=success_embed(f"سيحصل الأعضاء الجدد على {role.mention}."))

    # ------------------------------------------------------------------
    # /leave ...
    # ------------------------------------------------------------------
    @leave_group.command(name="enable", description="تشغيل رسائل المغادرة")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def leave_enable(self, interaction: discord.Interaction) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "leave_enabled", 1)
        await interaction.response.send_message(embed=success_embed("تم تشغيل رسائل المغادرة."))

    @leave_group.command(name="disable", description="إيقاف رسائل المغادرة")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def leave_disable(self, interaction: discord.Interaction) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "leave_enabled", 0)
        await interaction.response.send_message(embed=success_embed("تم إيقاف رسائل المغادرة."))

    @leave_group.command(name="channel", description="تحديد قناة المغادرة")
    @app_commands.describe(channel="القناة")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def leave_channel(self, interaction: discord.Interaction, channel: discord.TextChannel) -> None:
        assert interaction.guild is not None
        permissions = channel.permissions_for(interaction.guild.me)
        if not (permissions.send_messages and permissions.embed_links):
            await interaction.response.send_message(
                embed=error_embed(f"البوت لا يستطيع الإرسال في {channel.mention}."), ephemeral=True
            )
            return
        await self.bot.db.set_guild_setting(interaction.guild_id, "leave_channel_id", channel.id)
        await interaction.response.send_message(embed=success_embed(f"ستُرسل رسائل المغادرة في {channel.mention}."))

    @leave_group.command(name="message", description="تخصيص نص رسالة المغادرة")
    @app_commands.describe(text="النص. المتغيرات المتاحة: {user} {username} {server} {count}")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def leave_message(self, interaction: discord.Interaction, text: str) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "leave_message", text)
        await interaction.response.send_message(embed=success_embed(f"تم تحديث رسالة المغادرة:\n\n{text}"))


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Welcome(bot))
