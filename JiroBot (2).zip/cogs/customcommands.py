"""أوامر مخصصة: عند كتابة (البادئة + الاسم) يرد البوت بالنص المحفوظ."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.customcommands")


class CustomCommands(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot
        self._cache: dict[int, dict] = {}

    def invalidate(self, guild_id: int) -> None:
        self._cache.pop(guild_id, None)

    async def _load(self, guild_id: int) -> dict:
        if guild_id not in self._cache:
            settings = await self.bot.db.get_guild_settings(guild_id)
            rows = await self.bot.db.get_custom_commands(guild_id)
            self._cache[guild_id] = {
                "prefix": settings["custom_prefix"] or "!",
                "commands": {row["name"]: row["response"] for row in rows},
            }
        return self._cache[guild_id]

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.guild is None or message.author.bot:
            return

        try:
            data = await self._load(message.guild.id)
            if not data["commands"] or not message.content.startswith(data["prefix"]):
                return

            parts = message.content[len(data["prefix"]):].split(maxsplit=1)
            if not parts:
                return
            response = data["commands"].get(parts[0].lower())
            if response is None:
                return

            text = (
                response.replace("{user}", message.author.mention)
                .replace("{username}", message.author.display_name)
                .replace("{server}", message.guild.name)
            )
            await message.channel.send(text)
        except discord.HTTPException:
            log.warning("Could not send custom command reply in guild %s", message.guild.id)
        except Exception:
            log.exception("Custom command failed")


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(CustomCommands(bot))
