"""رتب الألوان: لوحة قائمة منسدلة يختار منها العضو لونه (لون واحد فقط)."""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

import config
from utils.embeds import error_embed, success_embed

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.colorroles")

CUSTOM_ID = "jiro:colors"
MAX_COLORS = 24  # + خيار "إزالة اللون" = 25 (حد Discord)


def _can_assign(guild: discord.Guild, role: discord.Role) -> bool:
    me = guild.me
    return bool(me and me.guild_permissions.manage_roles and not role.managed and not role.is_default() and role < me.top_role)


class ColorRoles(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------
    # يستدعيها الداشبورد
    # ------------------------------------------------------------------
    async def create_color_role(self, guild: discord.Guild, name: str, color_value: int) -> tuple[bool, str | None]:
        rows = await self.bot.db.get_color_roles(guild.id)
        if len(rows) >= MAX_COLORS:
            return False, f"وصلت للحد الأقصى ({MAX_COLORS} لونًا)."
        if guild.me is None or not guild.me.guild_permissions.manage_roles:
            return False, "البوت يحتاج صلاحية إدارة الرتب."

        try:
            role = await guild.create_role(name=name, colour=discord.Colour(color_value), reason="JiroBot color role")
        except discord.HTTPException:
            return False, "تعذر إنشاء الرتبة (ربما وصل السيرفر لحد الرتب)."

        await self.bot.db.add_color_role(guild.id, role.id, name)
        return True, None

    async def link_color_role(self, guild: discord.Guild, role_id: int | None, label: str) -> tuple[bool, str | None]:
        role = guild.get_role(role_id) if role_id else None
        if role is None:
            return False, "اختر رتبة صحيحة."
        if not _can_assign(guild, role):
            return False, "لا يستطيع البوت منح هذه الرتبة. ارفع رتبة JiroBot فوقها."

        rows = await self.bot.db.get_color_roles(guild.id)
        if len(rows) >= MAX_COLORS and role.id not in {row["role_id"] for row in rows}:
            return False, f"وصلت للحد الأقصى ({MAX_COLORS} لونًا)."

        await self.bot.db.add_color_role(guild.id, role.id, label or role.name)
        return True, None

    async def remove_color_role(self, guild: discord.Guild, role_id: int, delete_role: bool) -> None:
        await self.bot.db.remove_color_role(guild.id, role_id)
        if delete_role:
            role = guild.get_role(role_id)
            if role is not None and _can_assign(guild, role):
                try:
                    await role.delete(reason="JiroBot color role removed")
                except discord.HTTPException:
                    pass

    async def send_panel(
        self, guild: discord.Guild, channel_id: int | None, title: str, description: str
    ) -> tuple[bool, str | None]:
        channel = guild.get_channel(channel_id) if channel_id else None
        if not isinstance(channel, discord.TextChannel):
            return False, "اختر قناة نصية صحيحة."

        permissions = channel.permissions_for(guild.me)
        if not (permissions.send_messages and permissions.embed_links):
            return False, f"البوت لا يملك صلاحية الإرسال في #{channel.name}."

        rows = await self.bot.db.get_color_roles(guild.id)
        options = []
        for row in rows:
            role = guild.get_role(row["role_id"])
            if role is not None:
                options.append(discord.SelectOption(label=row["label"][:100], value=str(role.id)))
        if not options:
            return False, "أضف لونًا واحدًا على الأقل أولًا."
        options.append(discord.SelectOption(label="إزالة لوني", value="none"))

        select = discord.ui.Select(
            custom_id=CUSTOM_ID, placeholder="اختر لونك...", options=options, min_values=1, max_values=1
        )
        view = discord.ui.View(timeout=None)
        view.add_item(select)

        embed = discord.Embed(
            title=title or "رتب الألوان",
            description=description or "اختر لونك من القائمة أدناه.",
            color=config.EMERALD,
        )
        embed.set_footer(text=config.FOOTER_TEXT)
        try:
            await channel.send(embed=embed, view=view)
        except discord.HTTPException:
            return False, "تعذر إرسال اللوحة."
        return True, None

    # ------------------------------------------------------------------
    # اختيار العضو للون
    # ------------------------------------------------------------------
    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction) -> None:
        if interaction.type is not discord.InteractionType.component:
            return
        data = interaction.data or {}
        if data.get("custom_id") != CUSTOM_ID:
            return

        guild = interaction.guild
        member = interaction.user
        if guild is None or not isinstance(member, discord.Member):
            return

        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            rows = await self.bot.db.get_color_roles(guild.id)
            color_ids = {row["role_id"] for row in rows}
            choice = (data.get("values") or ["none"])[0]

            new_role = None
            if choice.isdigit() and int(choice) in color_ids:
                new_role = guild.get_role(int(choice))

            removals = [role for role in member.roles if role.id in color_ids and role != new_role]
            if removals:
                await member.remove_roles(*removals, reason="Color role change")
            if new_role is not None and new_role not in member.roles:
                await member.add_roles(new_role, reason="Color role change")
        except discord.HTTPException:
            await interaction.followup.send(
                embed=error_embed("تعذر تغيير اللون. تأكد أن رتبة JiroBot أعلى من رتب الألوان."), ephemeral=True
            )
            return
        except Exception:
            log.exception("Color role interaction failed")
            await interaction.followup.send(embed=error_embed("حدث خطأ غير متوقع."), ephemeral=True)
            return

        text = f"تم تغيير لونك إلى {new_role.mention}." if new_role else "تمت إزالة لونك."
        await interaction.followup.send(embed=success_embed(text), ephemeral=True)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(ColorRoles(bot))
