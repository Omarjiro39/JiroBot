"""أمر /help تفاعلي بقائمة منسدلة للأقسام."""
from __future__ import annotations

from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from utils.embeds import make_embed

if TYPE_CHECKING:
    from bot import JiroBot

CATEGORIES: dict[str, tuple[str, str]] = {
    "admin": (
        "🛡️ الإدارة",
        "`/kick` `/ban` `/unban` `/timeout` `/warn` `/warnings` `/clearwarnings`\n"
        "`/clear` `/slowmode` `/lock` `/unlock` `/nick` `/role add` `/role remove`",
    ),
    "economy": (
        "💰 الاقتصاد",
        "`/balance` `/daily` `/work` `/pay` `/coinflip` `/economy leaderboard`",
    ),
    "levels": (
        "⭐ المستويات",
        "`/rank` `/leaderboard`\n"
        "**للإدارة:** `/level enable` `/level disable` `/level channel` `/level setxp` `/level xprange` `/level system`",
    ),
    "profile": (
        "👤 البروفايل",
        "`/profile`",
    ),
    "settings": (
        "⚙️ إعدادات السيرفر",
        "`/welcome enable/disable/channel/message/dm/autorole`\n"
        "`/leave enable/disable/channel/message`\n"
        "`/logs channel/roles/channels/voice`\n"
        "`/automod enable/disable/links/spam`\n"
        "`/automod words add/remove/list`\n"
        "`/autorespond add/remove/list`\n"
        "كل الإعدادات متاحة أيضًا من لوحة التحكم على الموقع.",
    ),
    "tools": (
        "🔧 الأدوات",
        "`/ping` `/botinfo` `/help`",
    ),
}


class HelpSelect(discord.ui.Select):
    def __init__(self) -> None:
        options = [
            discord.SelectOption(label=title, value=key) for key, (title, _) in CATEGORIES.items()
        ]
        super().__init__(placeholder="اختر قسمًا لعرض أوامره...", options=options)

    async def callback(self, interaction: discord.Interaction) -> None:
        title, body = CATEGORIES[self.values[0]]
        embed = make_embed(title, body)
        await interaction.response.edit_message(embed=embed, view=self.view)


class HelpView(discord.ui.View):
    def __init__(self) -> None:
        super().__init__(timeout=120)
        self.add_item(HelpSelect())


class Help(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    @app_commands.command(name="help", description="عرض قائمة أوامر JiroBot")
    async def help_command(self, interaction: discord.Interaction) -> None:
        embed = make_embed(
            "📖 قائمة أوامر JiroBot",
            "اختر قسمًا من القائمة أدناه لعرض أوامره.\n\n"
            + "\n".join(title for title, _ in CATEGORIES.values()),
        )
        await interaction.response.send_message(embed=embed, view=HelpView())


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Help(bot))
