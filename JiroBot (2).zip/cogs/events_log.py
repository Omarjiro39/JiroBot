"""تسجيل أحداث السيرفر تلقائيًا، كل نوع بقناته المصنّفة (roles / channels / voice / عام)."""
from __future__ import annotations

from typing import TYPE_CHECKING

import discord
from discord.ext import commands

import config
from utils.embeds import make_embed
from utils.logs import send_log_embed

if TYPE_CHECKING:
    from bot import JiroBot

MAX_PREVIEW = 500


def _truncate(text: str) -> str:
    text = text or "*(بدون نص، ربما صورة أو ملف مرفق)*"
    return text if len(text) <= MAX_PREVIEW else text[:MAX_PREVIEW] + "…"


class EventsLog(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    # ---------------- أعضاء ----------------
    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        embed = make_embed("📥 انضمام عضو", color=config.EMERALD)
        embed.add_field(name="العضو", value=f"{member.mention} (`{member.id}`)", inline=False)
        embed.add_field(name="تاريخ إنشاء الحساب", value=f"<t:{int(member.created_at.timestamp())}:R>", inline=False)
        embed.set_thumbnail(url=member.display_avatar.url)
        await send_log_embed(self.bot, member.guild, embed)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member) -> None:
        embed = make_embed("📤 مغادرة عضو", color=config.WARNING_AMBER)
        embed.add_field(name="العضو", value=f"{member} (`{member.id}`)", inline=False)
        await send_log_embed(self.bot, member.guild, embed)

    # ---------------- رسائل ----------------
    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message) -> None:
        if message.guild is None or message.author.bot:
            return
        embed = make_embed("🗑️ حذف رسالة", color=config.ERROR_RED)
        embed.add_field(name="الكاتب", value=f"{message.author.mention} (`{message.author.id}`)", inline=False)
        embed.add_field(name="القناة", value=message.channel.mention, inline=False)
        embed.add_field(name="المحتوى", value=_truncate(message.content), inline=False)
        await send_log_embed(self.bot, message.guild, embed)

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message) -> None:
        if before.guild is None or before.author.bot or before.content == after.content:
            return
        embed = make_embed("✏️ تعديل رسالة", color=config.WARNING_AMBER)
        embed.add_field(name="الكاتب", value=f"{before.author.mention} (`{before.author.id}`)", inline=False)
        embed.add_field(name="القناة", value=f"{before.channel.mention} • [الرسالة]({after.jump_url})", inline=False)
        embed.add_field(name="قبل", value=_truncate(before.content), inline=False)
        embed.add_field(name="بعد", value=_truncate(after.content), inline=False)
        await send_log_embed(self.bot, before.guild, embed)

    # ---------------- قنوات ----------------
    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: discord.abc.GuildChannel) -> None:
        embed = make_embed("➕ إنشاء قناة", color=config.EMERALD)
        embed.add_field(name="القناة", value=getattr(channel, "mention", f"#{channel.name}"), inline=False)
        await send_log_embed(self.bot, channel.guild, embed, category="channels")

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: discord.abc.GuildChannel) -> None:
        embed = make_embed("➖ حذف قناة", color=config.ERROR_RED)
        embed.add_field(name="القناة", value=f"#{channel.name}", inline=False)
        await send_log_embed(self.bot, channel.guild, embed, category="channels")

    @commands.Cog.listener()
    async def on_guild_channel_update(self, before: discord.abc.GuildChannel, after: discord.abc.GuildChannel) -> None:
        changes = []
        if before.name != after.name:
            changes.append(f"**الاسم:** {before.name} ← {after.name}")
        if isinstance(before, discord.TextChannel) and isinstance(after, discord.TextChannel):
            if before.topic != after.topic:
                changes.append("**الوصف تغيّر**")
            if before.slowmode_delay != after.slowmode_delay:
                changes.append(f"**وضع البطيء:** {before.slowmode_delay}s ← {after.slowmode_delay}s")
        if not changes:
            return

        embed = make_embed("🔧 تحديث قناة", "\n".join(changes), color=config.EMERALD)
        embed.add_field(name="القناة", value=after.mention, inline=False)
        await send_log_embed(self.bot, after.guild, embed, category="channels")

    # ---------------- رتب ----------------
    @commands.Cog.listener()
    async def on_guild_role_create(self, role: discord.Role) -> None:
        embed = make_embed("➕ إنشاء رتبة", color=config.EMERALD)
        embed.add_field(name="الرتبة", value=role.mention, inline=False)
        await send_log_embed(self.bot, role.guild, embed, category="roles")

    @commands.Cog.listener()
    async def on_guild_role_delete(self, role: discord.Role) -> None:
        embed = make_embed("➖ حذف رتبة", color=config.ERROR_RED)
        embed.add_field(name="الرتبة", value=f"@{role.name}", inline=False)
        await send_log_embed(self.bot, role.guild, embed, category="roles")

    @commands.Cog.listener()
    async def on_guild_role_update(self, before: discord.Role, after: discord.Role) -> None:
        changes = []
        if before.name != after.name:
            changes.append(f"**الاسم:** {before.name} ← {after.name}")
        if before.color != after.color:
            changes.append("**اللون تغيّر**")
        if before.permissions != after.permissions:
            changes.append("**الصلاحيات تغيّرت**")
        if not changes:
            return

        embed = make_embed("🔧 تحديث رتبة", "\n".join(changes), color=config.WARNING_AMBER)
        embed.add_field(name="الرتبة", value=after.mention, inline=False)
        await send_log_embed(self.bot, after.guild, embed, category="roles")

    # ---------------- صوت ----------------
    @commands.Cog.listener()
    async def on_voice_state_update(
        self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState
    ) -> None:
        if member.bot or before.channel == after.channel:
            return

        embed = make_embed("🔊 نشاط صوتي", color=config.EMERALD)
        embed.add_field(name="العضو", value=f"{member.mention} (`{member.id}`)", inline=False)

        if before.channel is None and after.channel is not None:
            embed.description = f"دخل {after.channel.mention}"
        elif before.channel is not None and after.channel is None:
            embed.description = f"خرج من {before.channel.mention}"
        elif before.channel is not None and after.channel is not None:
            embed.description = f"انتقل من {before.channel.mention} إلى {after.channel.mention}"
        else:
            return

        await send_log_embed(self.bot, member.guild, embed, category="voice")


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(EventsLog(bot))
