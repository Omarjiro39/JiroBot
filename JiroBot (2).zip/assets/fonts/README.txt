Fonts used by the /profile card (utils/profile_card.py).

DejaVuSans.ttf / DejaVuSans-Bold.ttf
  - DejaVu Fonts (free license, derived from Bitstream Vera). Full Arabic support,
    including the Arabic Presentation Forms that arabic-reshaper needs.

Optional: you can add your own Arabic font here (for example Tajawal or Cairo) named
Custom-Regular.ttf and Custom-Bold.ttf. It will be used first, but only add a font that
has complete Arabic glyph coverage (some web fonts show empty boxes for some letters).
