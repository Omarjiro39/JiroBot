"""JiroBot | جيرو بوت — الإعدادات المركزية."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _get_int(name: str) -> int | None:
    raw = os.getenv(name, "").strip()
    return int(raw) if raw.isdigit() else None


# ---------------------------------------------------------------------------
# Secrets / environment (.env)
# ---------------------------------------------------------------------------
DISCORD_TOKEN: str = os.getenv("DISCORD_TOKEN", "").strip()
DEV_GUILD_ID: int | None = _get_int("DEV_GUILD_ID")
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").strip().upper()
OWNER_ID: int | None = _get_int("OWNER_ID")
# ---------------------------------------------------------------------------
# Branding
# ---------------------------------------------------------------------------
BOT_NAME = "JiroBot"
BOT_NAME_AR = "جيرو بوت"
VERSION = "0.1.0"
FOOTER_TEXT = "JiroBot • Your Discord Assistant"
PRESENCE_TEXT = "/help | JiroBot"

EMERALD = 0x10B981
DARK_GREEN = 0x047857
ERROR_RED = 0xEF4444
WARNING_AMBER = 0xF59E0B

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
DATA_DIR = BASE_DIR / "data"
DATABASE_PATH = DATA_DIR / "database.db"
LOG_DIR = BASE_DIR / "logs"
COGS_DIR = BASE_DIR / "cogs"

# ---------------------------------------------------------------------------
# Levels (defaults — each server can override XP values later)
# ---------------------------------------------------------------------------
XP_MIN = 10
XP_MAX = 20
XP_COOLDOWN_SECONDS = 60

# ---------------------------------------------------------------------------
# Economy (global, so reward amounts are NOT per-server on purpose)
# ---------------------------------------------------------------------------
CURRENCY_NAME = "Jiro Coins"
CURRENCY_SYMBOL = "JC"
STARTING_COINS = 0

DAILY_MIN = 500
DAILY_MAX = 1000
DAILY_COOLDOWN_SECONDS = 24 * 60 * 60

WORK_MIN = 100
WORK_MAX = 300
WORK_COOLDOWN_SECONDS = 60 * 60

# ---------------------------------------------------------------------------
# Default messages (placeholders: {user} {username} {server} {count})
# ---------------------------------------------------------------------------
DEFAULT_WELCOME_MESSAGE = "👋 أهلاً وسهلاً بك {user}!\n\nنورت {server} ❤️"
DEFAULT_LEAVE_MESSAGE = "👋 {username} غادر السيرفر. نتمنى له التوفيق!"