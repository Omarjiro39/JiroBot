"""إبقاء البوت داخل روم فويس محدد لكل سيرفر (24/7 Voice Presence).

لا توجد أوامر هنا. التحكم فقط عبر /voice في cogs/owner.py (خاص بالمالك).
هذا الملف مسؤول فقط عن: الاتصال التلقائي عند تشغيل البوت، وإعادة الاتصال عند الانقطاع.
"""
from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING

import discord
from discord.ext import commands

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.voice")
RECONNECT_DELAY_SECONDS = 5


class VoicePresence(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    async def connect_guild(self, guild: discord.Guild, channel_id: int) -> tuple[bool, str]:
        """يحاول الاتصال بروم فويس. يرجع (نجح؟، رسالة)."""
        channel = guild.get_channel(channel_id)
        if not isinstance(channel, discord.VoiceChannel):
            return False, "لم يتم العثور على روم فويس بهذا الآيدي في هذا السيرفر."

        permissions = channel.permissions_for(guild.me)
        if not (permissions.connect and permissions.view_channel):
            return False, f"البوت لا يملك صلاحية الدخول إلى {channel.name} في {guild.name}."

        existing = guild.voice_client
        if existing is not None and existing.channel and existing.channel.id == channel_id:
            return True, f"البوت متصل بالفعل في {channel.name}."

        try:
            if existing is not None:
                await existing.move_to(channel)
            else:
                await channel.connect(self_deaf=True)
            log.info("Connected to voice channel %s in guild %s", channel_id, guild.id)
            return True, f"تم الاتصال بـ {channel.name} في {guild.name}."
        except discord.ClientException:
            return True, f"البوت متصل بالفعل في {channel.name}."
        except discord.HTTPException as exc:
            log.warning("Could not connect to voice channel %s in guild %s: %s", channel_id, guild.id, exc)
            return False, "حدث خطأ أثناء محاولة الاتصال بالروم الصوتي."

    @commands.Cog.listener()
    async def on_ready(self) -> None:
        rows = await self.bot.db.get_all_guild_settings()
        for row in rows:
            channel_id = row["stay_voice_channel_id"]
            if not channel_id:
                continue
            guild = self.bot.get_guild(row["guild_id"])
            if guild is not None:
                await self.connect_guild(guild, channel_id)

    @commands.Cog.listener()
    async def on_voice_state_update(
        self, member: discord.Member, before: discord.VoiceState, after: discord.VoiceState
    ) -> None:
        # نهتم فقط بحالة انقطاع البوت نفسه عن الفويس (طرد، خطأ شبكة...)
        if member.id != self.bot.user.id:  # type: ignore[union-attr]
            return
        if before.channel is None or after.channel is not None:
            return  # لم يكن متصلًا أصلًا، أو انتقل لروم آخر بشكل طبيعي (لا نتدخل)

        guild = before.channel.guild
        settings = await self.bot.db.get_guild_settings(guild.id)
        channel_id = settings["stay_voice_channel_id"]
        if not channel_id:
            return

        await asyncio.sleep(RECONNECT_DELAY_SECONDS)
        await self.connect_guild(guild, channel_id)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(VoicePresence(bot))