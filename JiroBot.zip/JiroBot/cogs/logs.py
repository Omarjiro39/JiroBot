"""أمر /logs channel لتحديد قناة السجلات."""
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

from utils.embeds import error_embed, success_embed

if TYPE_CHECKING:
    from bot import JiroBot


class Logs(commands.Cog):
    logs_group = app_commands.Group(
        name="logs",
        description="إعدادات قناة السجلات",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    @logs_group.command(name="channel", description="تحديد قناة السجلات (اتركها فارغة للإيقاف)")
    @app_commands.describe(channel="القناة المراد إرسال السجلات إليها")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def logs_channel(
        self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None
    ) -> None:
        assert interaction.guild is not None

        if channel is None:
            await self.bot.db.set_guild_setting(interaction.guild_id, "logs_channel_id", None)
            await interaction.response.send_message(embed=success_embed("تم إيقاف نظام السجلات."))
            return

        permissions = channel.permissions_for(interaction.guild.me)
        if not (permissions.view_channel and permissions.send_messages and permissions.embed_links):
            await interaction.response.send_message(
                embed=error_embed(f"البوت لا يستطيع الإرسال في {channel.mention}. أعطه صلاحيات الإرسال وتضمين الروابط."),
                ephemeral=True,
            )
            return

        await self.bot.db.set_guild_setting(interaction.guild_id, "logs_channel_id", channel.id)
        await interaction.response.send_message(embed=success_embed(f"سيتم إرسال السجلات في {channel.mention}."))


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Logs(bot))