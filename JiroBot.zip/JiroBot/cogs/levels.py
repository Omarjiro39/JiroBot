"""نظام المستويات: XP من الرسائل، /rank، وأوامر الإدارة /level ..."""
from __future__ import annotations

import logging
import random
import time
from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils.embeds import error_embed, make_embed, success_embed
from utils.helpers import format_number
from utils.xp import MAX_XP, progress, progress_bar

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.levels")


class Levels(commands.Cog):
    level_group = app_commands.Group(
        name="level",
        description="إعدادات نظام المستويات",
        guild_only=True,
        default_permissions=discord.Permissions(manage_guild=True),
    )

    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot
        # (guild_id, user_id) -> وقت آخر XP (في الذاكرة فقط، يُصفَّر عند إعادة تشغيل البوت)
        self._last_xp: dict[tuple[int, int], float] = {}

    # ------------------------------------------------------------------
    # كسب XP من الرسائل
    # ------------------------------------------------------------------
    def _prune_cooldowns(self, now: float) -> None:
        if len(self._last_xp) > 20_000:
            self._last_xp = {
                key: last for key, last in self._last_xp.items() if now - last < config.XP_COOLDOWN_SECONDS
            }

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot or message.guild is None:
            return
        if message.type not in (discord.MessageType.default, discord.MessageType.reply):
            return

        key = (message.guild.id, message.author.id)
        now = time.monotonic()
        last = self._last_xp.get(key)
        if last is not None and now - last < config.XP_COOLDOWN_SECONDS:
            return
        # نسجل الوقت فورًا (قبل أي await) حتى لا تُحسب رسالتان متزامنتان مرتين
        self._last_xp[key] = now
        self._prune_cooldowns(now)

        try:
            settings = await self.bot.db.get_guild_settings(message.guild.id)
            if not settings["levels_enabled"]:
                return

            xp_min = settings["xp_min"] or config.XP_MIN
            xp_max = max(settings["xp_max"] or config.XP_MAX, xp_min)
            amount = random.randint(xp_min, xp_max)

            await self.bot.db.ensure_user(message.author.id, message.author.name)
            old_level, new_level, _ = await self.bot.db.add_xp(
                message.guild.id, message.author.id, amount, int(time.time())
            )
        except Exception:
            log.exception("Failed to give XP (guild=%s, user=%s)", message.guild.id, message.author.id)
            return

        if new_level > old_level and settings["levelup_messages"]:
            await self._announce_level_up(message, new_level, settings["levelup_channel_id"])

    async def _announce_level_up(self, message: discord.Message, level: int, channel_id: int | None) -> None:
        guild = message.guild
        assert guild is not None

        channel = guild.get_channel(channel_id) if channel_id else None
        channel = channel or message.channel
        if not isinstance(channel, discord.abc.Messageable):
            return

        permissions = channel.permissions_for(guild.me)  # type: ignore[union-attr]
        if not (permissions.send_messages and permissions.embed_links):
            return

        embed = make_embed("🎉 مبروك!", f"{message.author.mention} وصل إلى **Level {level}**!")
        embed.set_thumbnail(url=message.author.display_avatar.url)
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            log.warning("Could not send level-up message in guild %s", guild.id)

    # ------------------------------------------------------------------
    # /rank
    # ------------------------------------------------------------------
    @app_commands.command(name="rank", description="عرض مستواك أو مستوى عضو آخر")
    @app_commands.describe(member="العضو (اختياري)")
    @app_commands.guild_only()
    async def rank(self, interaction: discord.Interaction, member: Optional[discord.Member] = None) -> None:
        assert interaction.guild_id is not None
        target = member or interaction.user
        if target.bot:
            await interaction.response.send_message(embed=error_embed("البوتات لا تملك مستويات."), ephemeral=True)
            return

        row = await self.bot.db.get_member_level(interaction.guild_id, target.id)
        xp = row["xp"] if row else 0
        level, into_level, needed = progress(xp)
        position = await self.bot.db.get_level_rank(interaction.guild_id, target.id)

        embed = make_embed(f"⭐ مستوى {target.display_name}")
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="🏅 المستوى", value=str(level), inline=True)
        embed.add_field(name="🏆 الترتيب", value=f"#{position}" if position else "—", inline=True)
        embed.add_field(name="✨ إجمالي XP", value=format_number(xp), inline=True)
        embed.add_field(
            name="📈 التقدم للمستوى التالي",
            value=f"{progress_bar(into_level, needed)}\n`{format_number(into_level)} / {format_number(needed)} XP`",
            inline=False,
        )
        await interaction.response.send_message(embed=embed)

    # ------------------------------------------------------------------
    # أوامر الإدارة: /level ...
    # ------------------------------------------------------------------
    @level_group.command(name="enable", description="تشغيل رسائل الترقية (Level Up)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def level_enable(self, interaction: discord.Interaction) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "levelup_messages", 1)
        await interaction.response.send_message(embed=success_embed("تم تشغيل رسائل الترقية."))

    @level_group.command(name="disable", description="إيقاف رسائل الترقية (Level Up)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def level_disable(self, interaction: discord.Interaction) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "levelup_messages", 0)
        await interaction.response.send_message(embed=success_embed("تم إيقاف رسائل الترقية."))

    @level_group.command(name="channel", description="تحديد قناة رسائل الترقية (فارغ = نفس قناة الرسالة)")
    @app_commands.describe(channel="القناة (اتركها فارغة للرجوع للوضع الافتراضي)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def level_channel(
        self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None
    ) -> None:
        assert interaction.guild is not None
        if channel is None:
            await self.bot.db.set_guild_setting(interaction.guild_id, "levelup_channel_id", None)
            await interaction.response.send_message(
                embed=success_embed("سترسل رسائل الترقية في نفس القناة التي كتب فيها العضو.")
            )
            return

        permissions = channel.permissions_for(interaction.guild.me)
        if not (permissions.view_channel and permissions.send_messages and permissions.embed_links):
            await interaction.response.send_message(
                embed=error_embed(f"البوت لا يستطيع الإرسال في {channel.mention}. أعطه صلاحيات الإرسال وتضمين الروابط."),
                ephemeral=True,
            )
            return

        await self.bot.db.set_guild_setting(interaction.guild_id, "levelup_channel_id", channel.id)
        await interaction.response.send_message(
            embed=success_embed(f"ستُرسل رسائل الترقية في {channel.mention}.")
        )

    @level_group.command(name="setxp", description="ضبط XP عضو معين")
    @app_commands.describe(member="العضو", xp="قيمة XP الجديدة")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def level_setxp(self, interaction: discord.Interaction, member: discord.Member, xp: int) -> None:
        if member.bot:
            await interaction.response.send_message(embed=error_embed("البوتات لا تملك مستويات."), ephemeral=True)
            return
        if not 0 <= xp <= MAX_XP:
            await interaction.response.send_message(
                embed=error_embed(f"قيمة XP يجب أن تكون بين 0 و {format_number(MAX_XP)}."), ephemeral=True
            )
            return

        await self.bot.db.ensure_user(member.id, member.name)
        level = await self.bot.db.set_member_xp(interaction.guild_id, member.id, xp)
        await interaction.response.send_message(
            embed=success_embed(f"تم ضبط XP الخاص بـ {member.mention} على **{format_number(xp)}** (Level {level}).")
        )

    @level_group.command(name="xprange", description="تحديد مدى XP العشوائي لكل رسالة")
    @app_commands.describe(min_xp="الحد الأدنى", max_xp="الحد الأعلى")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def level_xprange(self, interaction: discord.Interaction, min_xp: int, max_xp: int) -> None:
        if not 1 <= min_xp <= max_xp <= 1000:
            await interaction.response.send_message(
                embed=error_embed("القيم غير صحيحة. الشرط: 1 ≤ الأدنى ≤ الأعلى ≤ 1000."), ephemeral=True
            )
            return

        await self.bot.db.set_guild_setting(interaction.guild_id, "xp_min", min_xp)
        await self.bot.db.set_guild_setting(interaction.guild_id, "xp_max", max_xp)
        await interaction.response.send_message(
            embed=success_embed(f"سيحصل الأعضاء الآن على XP عشوائي بين **{min_xp}** و **{max_xp}** لكل رسالة.")
        )

    @level_group.command(name="system", description="تشغيل أو إيقاف نظام المستويات بالكامل (كسب XP)")
    @app_commands.describe(enabled="تشغيل (True) أو إيقاف (False)")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def level_system(self, interaction: discord.Interaction, enabled: bool) -> None:
        await self.bot.db.set_guild_setting(interaction.guild_id, "levels_enabled", int(enabled))
        text = "تم تشغيل نظام المستويات." if enabled else "تم إيقاف نظام المستويات. لن يحصل أحد على XP."
        await interaction.response.send_message(embed=success_embed(text))


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Levels(bot))