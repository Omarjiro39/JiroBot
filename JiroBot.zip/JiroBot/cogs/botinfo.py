"""أوامر /ping و /botinfo."""
from __future__ import annotations

import math
import platform
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils.embeds import make_embed
from utils.helpers import format_duration, format_number

if TYPE_CHECKING:
    from bot import JiroBot


def latency_ms(bot: commands.Bot) -> int | None:
    """Websocket latency in ms, or None if it isn't available yet."""
    latency = bot.latency
    if math.isnan(latency) or math.isinf(latency):
        return None
    return round(latency * 1000)


class BotInfo(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    @app_commands.command(name="ping", description="عرض سرعة استجابة البوت")
    async def ping(self, interaction: discord.Interaction) -> None:
        ms = latency_ms(self.bot)
        value = f"{ms}ms" if ms is not None else "غير متاح"
        embed = make_embed("🏓 Pong!", f"**Latency:** `{value}`")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="botinfo", description="معلومات عن جيرو بوت")
    async def botinfo(self, interaction: discord.Interaction) -> None:
        bot = self.bot
        uptime = discord.utils.utcnow() - bot.started_at
        total_members = sum(guild.member_count or 0 for guild in bot.guilds)
        ms = latency_ms(bot)

        embed = make_embed(
            f"🤖 {config.BOT_NAME} | {config.BOT_NAME_AR}",
            "بوت ديسكورد عربي للإدارة والمستويات والاقتصاد والمزيد.",
        )
        embed.add_field(name="🏷️ الاسم", value=f"{config.BOT_NAME} | {config.BOT_NAME_AR}", inline=True)
        embed.add_field(name="🔖 الإصدار", value=f"v{config.VERSION}", inline=True)
        embed.add_field(name="🏓 Ping", value=f"{ms}ms" if ms is not None else "غير متاح", inline=True)
        embed.add_field(name="🌐 السيرفرات", value=format_number(len(bot.guilds)), inline=True)
        embed.add_field(name="👥 المستخدمون", value=format_number(total_members), inline=True)
        embed.add_field(name="⏱️ مدة التشغيل", value=format_duration(int(uptime.total_seconds())), inline=True)
        embed.add_field(name="🐍 Python", value=platform.python_version(), inline=True)
        embed.add_field(name="📦 discord.py", value=discord.__version__, inline=True)
        if bot.user is not None:
            embed.set_thumbnail(url=bot.user.display_avatar.url)

        await interaction.response.send_message(embed=embed)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(BotInfo(bot))