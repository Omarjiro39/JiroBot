"""أوامر مالك البوت (Owner) فقط. لا تظهر في أي سيرفر — DM فقط مع البوت.

الحماية على مستويين:
1. الأمر مسجّل ليظهر فقط في الرسائل الخاصة (DM)، فلا يظهر إطلاقًا داخل أي سيرفر.
2. فحص برمجي: أي شخص غير OWNER_ID يُرفض فورًا حتى لو كتب الأمر بطريقة ما.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils.embeds import error_embed, make_embed, success_embed
from utils.helpers import format_number

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.owner")


def is_owner_only():
    async def predicate(interaction: discord.Interaction) -> bool:
        if config.OWNER_ID is None or interaction.user.id != config.OWNER_ID:
            raise app_commands.CheckFailure("Owner-only command")
        return True

    return app_commands.check(predicate)


class Owner(commands.Cog):
    credit_group = app_commands.Group(
        name="credit",
        description="إدارة Jiro Coins لأي مستخدم (خاص بمالك البوت)",
    )
    voice_group = app_commands.Group(
        name="voice",
        description="التحكم بدخول البوت للرومات الصوتية (خاص بمالك البوت)",
    )

    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    async def cog_check(self, ctx: commands.Context) -> bool:  # احتياط لو أُضيفت أوامر نصية لاحقًا
        return ctx.author.id == config.OWNER_ID

    # ------------------------------------------------------------------
    # /credit give
    # ------------------------------------------------------------------
    @credit_group.command(name="give", description="[Owner] إضافة Jiro Coins لمستخدم")
    @app_commands.describe(user="المستخدم (بالـ ID أو المنشن)", amount="المبلغ المراد إضافته")
    @app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
    @is_owner_only()
    async def credit_give(self, interaction: discord.Interaction, user: discord.User, amount: int) -> None:
        if amount == 0:
            await interaction.response.send_message(embed=error_embed("المبلغ لا يمكن أن يكون صفرًا."), ephemeral=True)
            return

        new_balance = await self.bot.db.owner_adjust_coins(user.id, user.name, amount)
        verb = "إضافة" if amount > 0 else "خصم"
        embed = success_embed(
            f"تم {verb} **{format_number(abs(amount))} {config.CURRENCY_SYMBOL}** "
            f"{'إلى' if amount > 0 else 'من'} {user.mention} (`{user.id}`).\n\n"
            f"💰 رصيده الآن: **{format_number(new_balance)} {config.CURRENCY_SYMBOL}**"
        )
        await interaction.response.send_message(embed=embed)
        log.info("Owner adjusted coins for %s by %d -> %d", user.id, amount, new_balance)

    # ------------------------------------------------------------------
    # /credit set
    # ------------------------------------------------------------------
    @credit_group.command(name="set", description="[Owner] ضبط رصيد مستخدم على قيمة محددة")
    @app_commands.describe(user="المستخدم (بالـ ID أو المنشن)", amount="الرصيد الجديد بالضبط")
    @app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
    @is_owner_only()
    async def credit_set(self, interaction: discord.Interaction, user: discord.User, amount: int) -> None:
        if amount < 0:
            await interaction.response.send_message(embed=error_embed("الرصيد لا يمكن أن يكون سالبًا."), ephemeral=True)
            return

        new_balance = await self.bot.db.owner_set_coins(user.id, user.name, amount)
        embed = success_embed(
            f"تم ضبط رصيد {user.mention} (`{user.id}`) على **{format_number(new_balance)} {config.CURRENCY_SYMBOL}**."
        )
        await interaction.response.send_message(embed=embed)
        log.info("Owner set coins for %s -> %d", user.id, new_balance)

    # ------------------------------------------------------------------
    # /credit check
    # ------------------------------------------------------------------
    @credit_group.command(name="check", description="[Owner] عرض رصيد أي مستخدم")
    @app_commands.describe(user="المستخدم (بالـ ID أو المنشن)")
    @app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
    @is_owner_only()
    async def credit_check(self, interaction: discord.Interaction, user: discord.User) -> None:
        coins = await self.bot.db.get_coins(user.id)
        embed = make_embed(
            "💰 رصيد المستخدم",
            f"{user.mention} (`{user.id}`)\n**{format_number(coins)} {config.CURRENCY_SYMBOL}**",
        )
        await interaction.response.send_message(embed=embed)

    # ------------------------------------------------------------------
    # /voice join
    # ------------------------------------------------------------------
    @voice_group.command(name="join", description="[Owner] دخول روم فويس والبقاء فيه دائمًا")
    @app_commands.describe(channel_id="آيدي الروم الصوتي")
    @app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
    @is_owner_only()
    async def voice_join(self, interaction: discord.Interaction, channel_id: str) -> None:
        if not channel_id.isdigit():
            await interaction.response.send_message(embed=error_embed("آيدي غير صحيح."), ephemeral=True)
            return

        channel = self.bot.get_channel(int(channel_id))
        if not isinstance(channel, discord.VoiceChannel):
            await interaction.response.send_message(
                embed=error_embed("لم يتم العثور على روم فويس بهذا الآيدي. تأكد أن البوت داخل ذلك السيرفر."),
                ephemeral=True,
            )
            return

        voice_cog = self.bot.get_cog("VoicePresence")
        await self.bot.db.set_guild_setting(channel.guild.id, "stay_voice_channel_id", channel.id)
        ok, message = await voice_cog.connect_guild(channel.guild, channel.id)  # type: ignore[union-attr]

        embed = success_embed(message) if ok else error_embed(message)
        await interaction.response.send_message(embed=embed)
        log.info("Owner requested voice join: guild=%s channel=%s ok=%s", channel.guild.id, channel.id, ok)

    # ------------------------------------------------------------------
    # /voice leave
    # ------------------------------------------------------------------
    @voice_group.command(name="leave", description="[Owner] الخروج من روم فويس في سيرفر معيّن")
    @app_commands.describe(guild_id="آيدي السيرفر")
    @app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
    @is_owner_only()
    async def voice_leave(self, interaction: discord.Interaction, guild_id: str) -> None:
        if not guild_id.isdigit():
            await interaction.response.send_message(embed=error_embed("آيدي غير صحيح."), ephemeral=True)
            return

        guild = self.bot.get_guild(int(guild_id))
        if guild is None:
            await interaction.response.send_message(embed=error_embed("البوت ليس في هذا السيرفر."), ephemeral=True)
            return

        await self.bot.db.set_guild_setting(guild.id, "stay_voice_channel_id", None)
        if guild.voice_client is not None:
            await guild.voice_client.disconnect(force=True)

        await interaction.response.send_message(embed=success_embed(f"تم الخروج من الفويس في {guild.name}."))
        log.info("Owner requested voice leave: guild=%s", guild.id)

    # ------------------------------------------------------------------
    # /voice status
    # ------------------------------------------------------------------
    @voice_group.command(name="status", description="[Owner] عرض كل الرومات الصوتية المتصل بها البوت حاليًا")
    @app_commands.allowed_contexts(guilds=False, dms=True, private_channels=False)
    @is_owner_only()
    async def voice_status(self, interaction: discord.Interaction) -> None:
        lines = []
        for guild in self.bot.guilds:
            vc = guild.voice_client
            if vc is not None and vc.channel is not None:
                lines.append(f"🟢 **{guild.name}** (`{guild.id}`) → {vc.channel.name} (`{vc.channel.id}`)")

        embed = make_embed("🔊 حالة الاتصال الصوتي")
        embed.description = "\n".join(lines) if lines else "البوت غير متصل بأي روم صوتي حاليًا."
        await interaction.response.send_message(embed=embed)

    # ------------------------------------------------------------------
    # رسالة عربية بدل رسالة "no permission" العامة، إذا حاول أحد آخر (نظريًا فقط)
    # ------------------------------------------------------------------
    async def cog_app_command_error(
        self, interaction: discord.Interaction, error: app_commands.AppCommandError
    ) -> None:
        if isinstance(error, app_commands.CheckFailure):
            if not interaction.response.is_done():
                await interaction.response.send_message(
                    embed=error_embed("هذا الأمر مخصص لمالك البوت فقط."), ephemeral=True
                )
            return
        raise error  # اترك أي خطأ آخر لمعالج الأخطاء العام في cogs/errors.py


async def setup(bot: JiroBot) -> None:
    if config.OWNER_ID is None:
        log.warning("OWNER_ID is not set in .env — skipping the owner-only /credit and /voice commands.")
        return
    await bot.add_cog(Owner(bot))