"""أوامر الإدارة: kick, ban, unban, timeout, warn, clear, slowmode, lock/unlock, nick, role."""
from __future__ import annotations

import logging
import time
from datetime import timedelta
from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils.embeds import error_embed, make_embed, success_embed
from utils.logs import send_log_embed

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.moderation")
DEFAULT_REASON = "لم يُذكر سبب"


def _log_embed(title: str, target: discord.abc.User, moderator: discord.abc.User, reason: str, color: int) -> discord.Embed:
    embed = make_embed(title, color=color)
    embed.add_field(name="العضو", value=f"{target.mention} (`{target.id}`)", inline=False)
    embed.add_field(name="المسؤول", value=f"{moderator.mention} (`{moderator.id}`)", inline=False)
    embed.add_field(name="السبب", value=reason, inline=False)
    return embed


def _hierarchy_error(interaction: discord.Interaction, target: discord.Member) -> str | None:
    guild = interaction.guild
    assert guild is not None and guild.me is not None
    author = interaction.user
    assert isinstance(author, discord.Member)

    if target.id == guild.owner_id:
        return "لا يمكن تنفيذ هذا الإجراء على مالك السيرفر."
    if target.id == author.id:
        return "لا يمكنك تنفيذ هذا الإجراء على نفسك."
    if interaction.client.user is not None and target.id == interaction.client.user.id:
        return "لا يمكنك تنفيذ هذا الإجراء على البوت."
    if target.top_role >= guild.me.top_role:
        return "رتبة الهدف أعلى من رتبة JiroBot أو تساويها. ارفع رتبة JiroBot من إعدادات السيرفر."
    if author.id != guild.owner_id and target.top_role >= author.top_role:
        return "لا يمكنك تنفيذ هذا الإجراء على عضو رتبته أعلى من رتبتك أو تساويها."
    return None


class Moderation(commands.Cog):
    role_group = app_commands.Group(
        name="role",
        description="إدارة رتب الأعضاء",
        guild_only=True,
        default_permissions=discord.Permissions(manage_roles=True),
    )

    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------
    # /kick
    # ------------------------------------------------------------------
    @app_commands.command(name="kick", description="طرد عضو من السيرفر")
    @app_commands.describe(member="العضو", reason="السبب")
    @app_commands.guild_only()
    @app_commands.default_permissions(kick_members=True)
    @app_commands.checks.has_permissions(kick_members=True)
    @app_commands.checks.bot_has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = DEFAULT_REASON) -> None:
        error = _hierarchy_error(interaction, member)
        if error:
            await interaction.response.send_message(embed=error_embed(error), ephemeral=True)
            return

        try:
            await member.kick(reason=f"{interaction.user} : {reason}")
        except discord.Forbidden:
            await interaction.response.send_message(embed=error_embed("لا أملك صلاحية طرد هذا العضو."), ephemeral=True)
            return

        await interaction.response.send_message(embed=success_embed(f"تم طرد {member.mention}.\nالسبب: {reason}"))
        assert interaction.guild is not None
        await send_log_embed(
            self.bot, interaction.guild, _log_embed("👢 طرد عضو", member, interaction.user, reason, config.WARNING_AMBER)
        )

    # ------------------------------------------------------------------
    # /ban
    # ------------------------------------------------------------------
    @app_commands.command(name="ban", description="حظر مستخدم من السيرفر")
    @app_commands.describe(user="المستخدم", reason="السبب", delete_message_days="حذف رسائله لعدد أيام (0-7)")
    @app_commands.guild_only()
    @app_commands.default_permissions(ban_members=True)
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.checks.bot_has_permissions(ban_members=True)
    async def ban(
        self,
        interaction: discord.Interaction,
        user: discord.User,
        reason: str = DEFAULT_REASON,
        delete_message_days: app_commands.Range[int, 0, 7] = 0,
    ) -> None:
        assert interaction.guild is not None
        member = interaction.guild.get_member(user.id)
        if member is not None:
            error = _hierarchy_error(interaction, member)
            if error:
                await interaction.response.send_message(embed=error_embed(error), ephemeral=True)
                return
        elif user.id == interaction.user.id:
            await interaction.response.send_message(embed=error_embed("لا يمكنك حظر نفسك."), ephemeral=True)
            return

        try:
            await interaction.guild.ban(
                user, reason=f"{interaction.user} : {reason}", delete_message_seconds=delete_message_days * 86_400
            )
        except discord.Forbidden:
            await interaction.response.send_message(embed=error_embed("لا أملك صلاحية حظر هذا المستخدم."), ephemeral=True)
            return

        await interaction.response.send_message(embed=success_embed(f"تم حظر {user.mention}.\nالسبب: {reason}"))
        await send_log_embed(
            self.bot, interaction.guild, _log_embed("🔨 حظر مستخدم", user, interaction.user, reason, config.ERROR_RED)
        )

    # ------------------------------------------------------------------
    # /unban
    # ------------------------------------------------------------------
    @app_commands.command(name="unban", description="فك حظر مستخدم بواسطة آيدي")
    @app_commands.describe(user_id="آيدي المستخدم", reason="السبب")
    @app_commands.guild_only()
    @app_commands.default_permissions(ban_members=True)
    @app_commands.checks.has_permissions(ban_members=True)
    @app_commands.checks.bot_has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: str = DEFAULT_REASON) -> None:
        assert interaction.guild is not None
        if not user_id.isdigit():
            await interaction.response.send_message(embed=error_embed("آيدي غير صحيح."), ephemeral=True)
            return

        try:
            await interaction.guild.unban(discord.Object(id=int(user_id)), reason=f"{interaction.user} : {reason}")
        except discord.NotFound:
            await interaction.response.send_message(embed=error_embed("هذا المستخدم غير محظور."), ephemeral=True)
            return
        except discord.Forbidden:
            await interaction.response.send_message(embed=error_embed("لا أملك صلاحية فك الحظر."), ephemeral=True)
            return

        await interaction.response.send_message(embed=success_embed(f"تم فك الحظر عن `{user_id}`.\nالسبب: {reason}"))
        embed = make_embed("🔓 فك حظر", color=config.EMERALD)
        embed.add_field(name="المستخدم", value=f"<@{user_id}> (`{user_id}`)", inline=False)
        embed.add_field(name="المسؤول", value=interaction.user.mention, inline=False)
        embed.add_field(name="السبب", value=reason, inline=False)
        await send_log_embed(self.bot, interaction.guild, embed)

    # ------------------------------------------------------------------
    # /timeout
    # ------------------------------------------------------------------
    @app_commands.command(name="timeout", description="إسكات عضو لمدة محددة (0 لإلغاء الإسكات)")
    @app_commands.describe(member="العضو", minutes="المدة بالدقائق (0 للإلغاء)", reason="السبب")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.checks.bot_has_permissions(moderate_members=True)
    async def timeout(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        minutes: app_commands.Range[int, 0, 40320],
        reason: str = DEFAULT_REASON,
    ) -> None:
        error = _hierarchy_error(interaction, member)
        if error:
            await interaction.response.send_message(embed=error_embed(error), ephemeral=True)
            return

        until = discord.utils.utcnow() + timedelta(minutes=minutes) if minutes > 0 else None
        try:
            await member.timeout(until, reason=f"{interaction.user} : {reason}")
        except discord.Forbidden:
            await interaction.response.send_message(embed=error_embed("لا أملك صلاحية إسكات هذا العضو."), ephemeral=True)
            return

        if minutes > 0:
            await interaction.response.send_message(
                embed=success_embed(f"تم إسكات {member.mention} لمدة **{minutes}** دقيقة.\nالسبب: {reason}")
            )
            title = "🔇 إسكات عضو"
        else:
            await interaction.response.send_message(embed=success_embed(f"تم إلغاء إسكات {member.mention}."))
            title = "🔊 إلغاء إسكات"

        assert interaction.guild is not None
        await send_log_embed(self.bot, interaction.guild, _log_embed(title, member, interaction.user, reason, config.WARNING_AMBER))

    # ------------------------------------------------------------------
    # /warn
    # ------------------------------------------------------------------
    @app_commands.command(name="warn", description="إعطاء تحذير لعضو")
    @app_commands.describe(member="العضو", reason="السبب")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str) -> None:
        error = _hierarchy_error(interaction, member)
        if error:
            await interaction.response.send_message(embed=error_embed(error), ephemeral=True)
            return

        assert interaction.guild_id is not None and interaction.guild is not None
        warning_id = await self.bot.db.add_warning(
            interaction.guild_id, member.id, interaction.user.id, reason, int(time.time())
        )
        await interaction.response.send_message(
            embed=success_embed(f"تم تحذير {member.mention}. (تحذير رقم #{warning_id})\nالسبب: {reason}")
        )

        try:
            dm_embed = make_embed(
                "⚠️ تلقيت تحذيرًا", f"في سيرفر **{interaction.guild.name}**\nالسبب: {reason}", color=config.WARNING_AMBER
            )
            await member.send(embed=dm_embed)
        except discord.HTTPException:
            pass

        await send_log_embed(
            self.bot, interaction.guild, _log_embed("⚠️ تحذير عضو", member, interaction.user, reason, config.WARNING_AMBER)
        )

    # ------------------------------------------------------------------
    # /warnings
    # ------------------------------------------------------------------
    @app_commands.command(name="warnings", description="عرض تحذيرات عضو")
    @app_commands.describe(member="العضو")
    @app_commands.guild_only()
    @app_commands.default_permissions(moderate_members=True)
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warnings_cmd(self, interaction: discord.Interaction, member: discord.Member) -> None:
        assert interaction.guild_id is not None
        rows = await self.bot.db.get_warnings(interaction.guild_id, member.id)

        embed = make_embed(f"⚠️ تحذيرات {member.display_name}")
        if not rows:
            embed.description = "لا توجد تحذيرات لهذا العضو. ✅"
        else:
            lines = [
                f"**#{row['id']}** — {row['reason']}\nبواسطة <@{row['moderator_id']}> • <t:{row['created_at']}:R>"
                for row in rows
            ]
            embed.description = "\n\n".join(lines)
        await interaction.response.send_message(embed=embed)

    # ------------------------------------------------------------------
    # /clearwarnings
    # ------------------------------------------------------------------
    @app_commands.command(name="clearwarnings", description="حذف كل تحذيرات عضو")
    @app_commands.describe(member="العضو")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def clearwarnings(self, interaction: discord.Interaction, member: discord.Member) -> None:
        assert interaction.guild_id is not None
        count = await self.bot.db.clear_warnings(interaction.guild_id, member.id)
        await interaction.response.send_message(embed=success_embed(f"تم حذف **{count}** تحذير عن {member.mention}."))

    # ------------------------------------------------------------------
    # /clear
    # ------------------------------------------------------------------
    @app_commands.command(name="clear", description="حذف عدد من الرسائل في القناة")
    @app_commands.describe(amount="عدد الرسائل (1-100)")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.checks.has_permissions(manage_messages=True)
    @app_commands.checks.bot_has_permissions(manage_messages=True)
    async def clear(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]) -> None:
        channel = interaction.channel
        if not isinstance(channel, discord.TextChannel):
            await interaction.response.send_message(embed=error_embed("هذا الأمر يعمل في القنوات النصية فقط."), ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True)
        deleted = await channel.purge(limit=amount)
        await interaction.followup.send(embed=success_embed(f"تم حذف **{len(deleted)}** رسالة."), ephemeral=True)

        assert interaction.guild is not None
        embed = make_embed("🧹 حذف رسائل", color=config.EMERALD)
        embed.add_field(name="القناة", value=channel.mention, inline=False)
        embed.add_field(name="العدد", value=str(len(deleted)), inline=False)
        embed.add_field(name="بواسطة", value=interaction.user.mention, inline=False)
        await send_log_embed(self.bot, interaction.guild, embed)

    # ------------------------------------------------------------------
    # /slowmode
    # ------------------------------------------------------------------
    @app_commands.command(name="slowmode", description="ضبط وضع البطيء لقناة")
    @app_commands.describe(seconds="عدد الثواني (0 للإيقاف)", channel="القناة (اختياري)")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.checks.bot_has_permissions(manage_channels=True)
    async def slowmode(
        self,
        interaction: discord.Interaction,
        seconds: app_commands.Range[int, 0, 21600],
        channel: Optional[discord.TextChannel] = None,
    ) -> None:
        target = channel or interaction.channel
        if not isinstance(target, discord.TextChannel):
            await interaction.response.send_message(embed=error_embed("اختر قناة نصية صحيحة."), ephemeral=True)
            return

        await target.edit(slowmode_delay=seconds)
        text = f"تم إيقاف وضع البطيء في {target.mention}." if seconds == 0 else f"تم ضبط وضع البطيء في {target.mention} على **{seconds}** ثانية."
        await interaction.response.send_message(embed=success_embed(text))

    # ------------------------------------------------------------------
    # /lock
    # ------------------------------------------------------------------
    @app_commands.command(name="lock", description="قفل قناة (منع @everyone من الكتابة)")
    @app_commands.describe(channel="القناة (اختياري)", reason="السبب")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.checks.bot_has_permissions(manage_channels=True, manage_roles=True)
    async def lock(
        self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None, reason: str = DEFAULT_REASON
    ) -> None:
        assert interaction.guild is not None
        target = channel or interaction.channel
        if not isinstance(target, discord.TextChannel):
            await interaction.response.send_message(embed=error_embed("اختر قناة نصية صحيحة."), ephemeral=True)
            return

        everyone = interaction.guild.default_role
        overwrite = target.overwrites_for(everyone)
        overwrite.send_messages = False
        await target.set_permissions(everyone, overwrite=overwrite, reason=f"{interaction.user} : {reason}")

        await interaction.response.send_message(embed=success_embed(f"🔒 تم قفل {target.mention}.\nالسبب: {reason}"))
        embed = make_embed("🔒 قفل قناة", color=config.WARNING_AMBER)
        embed.add_field(name="القناة", value=target.mention, inline=False)
        embed.add_field(name="بواسطة", value=interaction.user.mention, inline=False)
        embed.add_field(name="السبب", value=reason, inline=False)
        await send_log_embed(self.bot, interaction.guild, embed)

    # ------------------------------------------------------------------
    # /unlock
    # ------------------------------------------------------------------
    @app_commands.command(name="unlock", description="فتح قناة مقفلة")
    @app_commands.describe(channel="القناة (اختياري)")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.checks.has_permissions(manage_channels=True)
    @app_commands.checks.bot_has_permissions(manage_channels=True, manage_roles=True)
    async def unlock(self, interaction: discord.Interaction, channel: Optional[discord.TextChannel] = None) -> None:
        assert interaction.guild is not None
        target = channel or interaction.channel
        if not isinstance(target, discord.TextChannel):
            await interaction.response.send_message(embed=error_embed("اختر قناة نصية صحيحة."), ephemeral=True)
            return

        everyone = interaction.guild.default_role
        overwrite = target.overwrites_for(everyone)
        overwrite.send_messages = None
        await target.set_permissions(everyone, overwrite=overwrite)

        await interaction.response.send_message(embed=success_embed(f"🔓 تم فتح {target.mention}."))
        embed = make_embed("🔓 فتح قناة", color=config.EMERALD)
        embed.add_field(name="القناة", value=target.mention, inline=False)
        embed.add_field(name="بواسطة", value=interaction.user.mention, inline=False)
        await send_log_embed(self.bot, interaction.guild, embed)

    # ------------------------------------------------------------------
    # /nick
    # ------------------------------------------------------------------
    @app_commands.command(name="nick", description="تغيير لقب عضو")
    @app_commands.describe(member="العضو", nickname="اللقب الجديد (اتركه فارغًا لإعادة الضبط)")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_nicknames=True)
    @app_commands.checks.has_permissions(manage_nicknames=True)
    @app_commands.checks.bot_has_permissions(manage_nicknames=True)
    async def nick(self, interaction: discord.Interaction, member: discord.Member, nickname: Optional[str] = None) -> None:
        error = _hierarchy_error(interaction, member)
        if error:
            await interaction.response.send_message(embed=error_embed(error), ephemeral=True)
            return

        try:
            await member.edit(nick=nickname)
        except discord.Forbidden:
            await interaction.response.send_message(embed=error_embed("لا أملك صلاحية تغيير لقب هذا العضو."), ephemeral=True)
            return

        text = f"تم تغيير لقب {member.mention} إلى **{nickname}**." if nickname else f"تمت إعادة ضبط لقب {member.mention}."
        await interaction.response.send_message(embed=success_embed(text))

    # ------------------------------------------------------------------
    # /role add | remove
    # ------------------------------------------------------------------
    def _role_error(self, interaction: discord.Interaction, role: discord.Role) -> str | None:
        guild = interaction.guild
        assert guild is not None and guild.me is not None
        author = interaction.user
        assert isinstance(author, discord.Member)

        if role.is_default() or role.managed:
            return "لا يمكن التحكم بهذه الرتبة."
        if role >= guild.me.top_role:
            return "هذه الرتبة أعلى من رتبة JiroBot أو تساويها. ارفع رتبة JiroBot من إعدادات السيرفر."
        if author.id != guild.owner_id and role >= author.top_role:
            return "لا يمكنك التحكم برتبة أعلى من رتبتك أو تساويها."
        return None

    @role_group.command(name="add", description="إعطاء رتبة لعضو")
    @app_commands.describe(member="العضو", role="الرتبة")
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.checks.bot_has_permissions(manage_roles=True)
    async def role_add(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role) -> None:
        error = self._role_error(interaction, role)
        if error:
            await interaction.response.send_message(embed=error_embed(error), ephemeral=True)
            return
        if role in member.roles:
            await interaction.response.send_message(
                embed=error_embed(f"{member.mention} يملك رتبة {role.mention} بالفعل."), ephemeral=True
            )
            return

        await member.add_roles(role, reason=f"By {interaction.user}")
        await interaction.response.send_message(embed=success_embed(f"تم إعطاء رتبة {role.mention} لـ {member.mention}."))

        assert interaction.guild is not None
        embed = make_embed("🏷️ تحديث رتبة", color=config.EMERALD)
        embed.add_field(name="العضو", value=member.mention, inline=False)
        embed.add_field(name="الإجراء", value=f"إضافة {role.mention}", inline=False)
        embed.add_field(name="بواسطة", value=interaction.user.mention, inline=False)
        await send_log_embed(self.bot, interaction.guild, embed)

    @role_group.command(name="remove", description="إزالة رتبة من عضو")
    @app_commands.describe(member="العضو", role="الرتبة")
    @app_commands.checks.has_permissions(manage_roles=True)
    @app_commands.checks.bot_has_permissions(manage_roles=True)
    async def role_remove(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role) -> None:
        error = self._role_error(interaction, role)
        if error:
            await interaction.response.send_message(embed=error_embed(error), ephemeral=True)
            return
        if role not in member.roles:
            await interaction.response.send_message(embed=error_embed(f"{member.mention} لا يملك رتبة {role.mention}."), ephemeral=True)
            return

        await member.remove_roles(role, reason=f"By {interaction.user}")
        await interaction.response.send_message(embed=success_embed(f"تم إزالة رتبة {role.mention} من {member.mention}."))

        assert interaction.guild is not None
        embed = make_embed("🏷️ تحديث رتبة", color=config.WARNING_AMBER)
        embed.add_field(name="العضو", value=member.mention, inline=False)
        embed.add_field(name="الإجراء", value=f"إزالة {role.mention}", inline=False)
        embed.add_field(name="بواسطة", value=interaction.user.mention, inline=False)
        await send_log_embed(self.bot, interaction.guild, embed)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Moderation(bot))