"""نظام الاقتصاد: Jiro Coins (عالمية لكل مستخدم وليست مرتبطة بسيرفر)."""
from __future__ import annotations

import random
import time
from typing import TYPE_CHECKING, Optional

import discord
from discord import app_commands
from discord.ext import commands

import config
from utils.embeds import error_embed, make_embed, warning_embed
from utils.helpers import format_number
from utils.leaderboard import coins_leaderboard_embed

if TYPE_CHECKING:
    from bot import JiroBot

_rng = random.SystemRandom()

WORK_JOBS = [
    "اشتغلت مبرمجًا لدى شركة ناشئة",
    "وصّلت طلبات المطاعم في الحي",
    "ساعدت في إصلاح بعض الأجهزة",
    "صممت شعارًا لأحد العملاء",
    "رتّبت المخزن في المتجر",
    "قدّمت دروسًا خصوصية",
    "شاركت في حملة تنظيف الحديقة",
    "بعت بعض المنتجات في السوق",
]

SIDE_NAMES = {"heads": "🪙 وجه", "tails": "📜 كتابة"}


def money(amount: int) -> str:
    return f"{format_number(amount)} {config.CURRENCY_SYMBOL}"


class Economy(commands.Cog):
    economy_group = app_commands.Group(name="economy", description="أوامر الاقتصاد", guild_only=True)

    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    # ------------------------------------------------------------------
    # /balance
    # ------------------------------------------------------------------
    @app_commands.command(name="balance", description="عرض رصيدك من Jiro Coins")
    @app_commands.describe(member="عضو آخر (اختياري)")
    @app_commands.guild_only()
    async def balance(self, interaction: discord.Interaction, member: Optional[discord.Member] = None) -> None:
        target = member or interaction.user
        if target.bot:
            await interaction.response.send_message(embed=error_embed("البوتات لا تملك رصيدًا."), ephemeral=True)
            return

        coins = await self.bot.db.get_coins(target.id)
        embed = make_embed(f"💰 {config.CURRENCY_NAME}", f"**{money(coins)}**")
        embed.set_author(name=target.display_name, icon_url=target.display_avatar.url)
        await interaction.response.send_message(embed=embed)

    # ------------------------------------------------------------------
    # /daily
    # ------------------------------------------------------------------
    @app_commands.command(name="daily", description="استلم مكافأتك اليومية (مرة كل 24 ساعة)")
    @app_commands.guild_only()
    async def daily(self, interaction: discord.Interaction) -> None:
        user = interaction.user
        amount = _rng.randint(config.DAILY_MIN, config.DAILY_MAX)
        now = int(time.time())

        claimed, value = await self.bot.db.claim_reward(
            user.id, user.name, "daily", amount, config.DAILY_COOLDOWN_SECONDS, now
        )
        if not claimed:
            await interaction.response.send_message(
                embed=warning_embed(f"استلمت مكافأتك اليومية بالفعل.\nيمكنك استلامها مرة أخرى <t:{now + value}:R>."),
                ephemeral=True,
            )
            return

        embed = make_embed(
            "🎁 المكافأة اليومية",
            f"حصلت على **{money(amount)}**!\n\n💰 رصيدك الآن: **{money(value)}**",
        )
        await interaction.response.send_message(embed=embed)

    # ------------------------------------------------------------------
    # /work
    # ------------------------------------------------------------------
    @app_commands.command(name="work", description="اشتغل واكسب Jiro Coins")
    @app_commands.guild_only()
    async def work(self, interaction: discord.Interaction) -> None:
        user = interaction.user
        amount = _rng.randint(config.WORK_MIN, config.WORK_MAX)
        now = int(time.time())

        claimed, value = await self.bot.db.claim_reward(
            user.id, user.name, "work", amount, config.WORK_COOLDOWN_SECONDS, now
        )
        if not claimed:
            await interaction.response.send_message(
                embed=warning_embed(f"أنت متعب الآن 😴\nيمكنك العمل مرة أخرى <t:{now + value}:R>."),
                ephemeral=True,
            )
            return

        job = _rng.choice(WORK_JOBS)
        embed = make_embed(
            "💼 العمل",
            f"{job} وحصلت على **{money(amount)}**.\n\n💰 رصيدك الآن: **{money(value)}**",
        )
        await interaction.response.send_message(embed=embed)

    # ------------------------------------------------------------------
    # /pay
    # ------------------------------------------------------------------
    @app_commands.command(name="pay", description="تحويل Jiro Coins إلى عضو آخر")
    @app_commands.describe(member="العضو المستلم", amount="المبلغ")
    @app_commands.guild_only()
    @app_commands.checks.cooldown(1, 3.0)
    async def pay(self, interaction: discord.Interaction, member: discord.Member, amount: int) -> None:
        sender = interaction.user

        if member.id == sender.id:
            await interaction.response.send_message(
                embed=error_embed("لا يمكنك تحويل العملات لنفسك."), ephemeral=True
            )
            return
        if member.bot:
            await interaction.response.send_message(embed=error_embed("لا يمكنك تحويل العملات لبوت."), ephemeral=True)
            return
        if amount <= 0:
            await interaction.response.send_message(
                embed=error_embed("المبلغ يجب أن يكون أكبر من صفر."), ephemeral=True
            )
            return

        success, balance = await self.bot.db.transfer_coins(sender.id, sender.name, member.id, member.name, amount)
        if not success:
            await interaction.response.send_message(
                embed=error_embed(f"رصيدك غير كافٍ.\nرصيدك الحالي: **{money(balance)}**"), ephemeral=True
            )
            return

        embed = make_embed(
            "💸 تم التحويل",
            f"تم تحويل **{money(amount)}** إلى {member.mention}.\n\n💰 رصيدك الآن: **{money(balance)}**",
        )
        await interaction.response.send_message(embed=embed)

    # ------------------------------------------------------------------
    # /coinflip
    # ------------------------------------------------------------------
    @app_commands.command(name="coinflip", description="راهن بعملاتك على وجه أو كتابة")
    @app_commands.describe(amount="مبلغ الرهان", side="اختيارك")
    @app_commands.choices(
        side=[
            app_commands.Choice(name="🪙 وجه", value="heads"),
            app_commands.Choice(name="📜 كتابة", value="tails"),
        ]
    )
    @app_commands.guild_only()
    @app_commands.checks.cooldown(1, 3.0)
    async def coinflip(self, interaction: discord.Interaction, amount: int, side: app_commands.Choice[str]) -> None:
        user = interaction.user
        if amount <= 0:
            await interaction.response.send_message(
                embed=error_embed("مبلغ الرهان يجب أن يكون أكبر من صفر."), ephemeral=True
            )
            return

        result = _rng.choice(["heads", "tails"])
        won = result == side.value

        success, balance = await self.bot.db.settle_bet(user.id, user.name, amount, won)
        if not success:
            await interaction.response.send_message(
                embed=error_embed(f"رصيدك غير كافٍ.\nرصيدك الحالي: **{money(balance)}**"), ephemeral=True
            )
            return

        if won:
            embed = make_embed(
                "🪙 Coinflip — فزت! 🎉",
                f"اخترت {SIDE_NAMES[side.value]} وجاءت {SIDE_NAMES[result]}.\n"
                f"ربحت **{money(amount)}**!\n\n💰 رصيدك الآن: **{money(balance)}**",
            )
        else:
            embed = make_embed(
                "🪙 Coinflip — خسرت 😔",
                f"اخترت {SIDE_NAMES[side.value]} وجاءت {SIDE_NAMES[result]}.\n"
                f"خسرت **{money(amount)}**.\n\n💰 رصيدك الآن: **{money(balance)}**",
                color=config.ERROR_RED,
            )
        await interaction.response.send_message(embed=embed)

    # ------------------------------------------------------------------
    # /economy leaderboard
    # ------------------------------------------------------------------
    @economy_group.command(name="leaderboard", description="أغنى الأعضاء (Jiro Coins)")
    async def economy_leaderboard(self, interaction: discord.Interaction) -> None:
        assert interaction.guild is not None
        embed = await coins_leaderboard_embed(self.bot.db, interaction.guild)
        await interaction.response.send_message(embed=embed)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Economy(bot))