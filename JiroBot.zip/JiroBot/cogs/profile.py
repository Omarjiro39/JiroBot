"""أمر /profile — بطاقة الملف الشخصي كصورة PNG."""
from __future__ import annotations

import asyncio
import io
import logging
from typing import TYPE_CHECKING, Optional

import aiohttp
import discord
from discord import app_commands
from discord.ext import commands

from utils.embeds import error_embed
from utils.profile_card import ProfileData, generate_profile_card
from utils.xp import progress

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.profile")

AVATAR_TIMEOUT = aiohttp.ClientTimeout(total=6)


class Profile(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    async def _fetch_avatar_bytes(self, member: discord.Member) -> bytes | None:
        """يحاول تحميل الأفاتار الحقيقي، ثم الافتراضي، وإلا يرجع None (والصورة ترسم بديلًا تلقائيًا)."""
        urls = [member.display_avatar.replace(size=256, format="png").url]
        default_url = member.default_avatar.url
        if default_url not in urls:
            urls.append(default_url)

        for url in urls:
            try:
                async with self.bot.session.get(url, timeout=AVATAR_TIMEOUT) as response:
                    if response.status == 200:
                        return await response.read()
            except (aiohttp.ClientError, asyncio.TimeoutError):
                continue
        log.warning("Could not download any avatar for user %s", member.id)
        return None

    @app_commands.command(name="profile", description="عرض بطاقة الملف الشخصي")
    @app_commands.describe(member="عضو آخر (اختياري)")
    @app_commands.guild_only()
    async def profile(self, interaction: discord.Interaction, member: Optional[discord.Member] = None) -> None:
        assert interaction.guild_id is not None
        target = member or interaction.user

        if target.bot:
            await interaction.response.send_message(embed=error_embed("البوتات لا تملك ملفًا شخصيًا."), ephemeral=True)
            return

        await interaction.response.defer()

        db = self.bot.db
        level_row = await db.get_member_level(interaction.guild_id, target.id)
        xp = level_row["xp"] if level_row else 0
        level, into_level, needed = progress(xp)

        coins = await db.get_coins(target.id)
        level_rank = await db.get_level_rank(interaction.guild_id, target.id)
        coin_rank = await db.get_coin_rank(target.id)
        avatar_bytes = await self._fetch_avatar_bytes(target)

        data = ProfileData(
            username=target.display_name,
            user_id=target.id,
            level=level,
            xp_into_level=into_level,
            xp_needed=needed,
            total_xp=xp,
            coins=coins,
            level_rank=level_rank,
            coin_rank=coin_rank,
            avatar_bytes=avatar_bytes,
        )

        try:
            image_bytes = await asyncio.to_thread(generate_profile_card, data)
        except Exception:
            log.exception("Failed to generate profile card for user %s", target.id)
            await interaction.followup.send(embed=error_embed("تعذر إنشاء بطاقة الملف الشخصي. حاول مرة أخرى."))
            return

        file = discord.File(io.BytesIO(image_bytes), filename="jirobot_profile.png")
        await interaction.followup.send(file=file)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Profile(bot))