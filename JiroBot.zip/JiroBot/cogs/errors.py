"""معالج الأخطاء المركزي للـ Slash Commands.

الخطأ لا يوقف البوت: المستخدم يرى رسالة عربية، والمطور يرى التفاصيل في الـ Console.
"""
from __future__ import annotations

import logging
import math
import sqlite3
from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from utils.embeds import error_embed
from utils.helpers import format_duration

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.errors")

PERMISSION_NAMES_AR: dict[str, str] = {
    "administrator": "مدير (Administrator)",
    "manage_guild": "إدارة السيرفر",
    "manage_channels": "إدارة القنوات",
    "manage_messages": "إدارة الرسائل",
    "manage_roles": "إدارة الرتب",
    "manage_nicknames": "إدارة الألقاب",
    "kick_members": "طرد الأعضاء",
    "ban_members": "حظر الأعضاء",
    "moderate_members": "إدارة الأعضاء (Timeout)",
    "view_audit_log": "عرض سجل التدقيق",
    "view_channel": "عرض القناة",
    "send_messages": "إرسال الرسائل",
    "embed_links": "تضمين الروابط",
    "attach_files": "إرفاق الملفات",
    "read_message_history": "قراءة سجل الرسائل",
}


def _permissions_line(permissions: list[str]) -> str:
    names = "، ".join(PERMISSION_NAMES_AR.get(name, name) for name in permissions)
    return f"\n\n**الصلاحيات المطلوبة:** {names}" if names else ""


class ErrorHandler(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot
        self._original_on_error = bot.tree.on_error

    async def cog_load(self) -> None:
        self.bot.tree.on_error = self.on_app_command_error  # type: ignore[method-assign]

    async def cog_unload(self) -> None:
        self.bot.tree.on_error = self._original_on_error  # type: ignore[method-assign]

    async def on_app_command_error(
        self,
        interaction: discord.Interaction,
        error: app_commands.AppCommandError,
    ) -> None:
        original = error.original if isinstance(error, app_commands.CommandInvokeError) else error
        message, should_log = self._describe(error, original)

        if should_log:
            command_name = interaction.command.qualified_name if interaction.command else "unknown"
            log.error(
                "Error in /%s (user=%s, guild=%s): %r",
                command_name,
                interaction.user.id,
                interaction.guild_id,
                original,
                exc_info=(type(original), original, original.__traceback__),
            )

        await self._send(interaction, message)

    @staticmethod
    def _describe(error: Exception, original: Exception) -> tuple[str, bool]:
        """Return (arabic_message, should_log_traceback)."""
        # --- أخطاء متوقعة من المستخدم (لا نسجلها كأخطاء) ---
        if isinstance(error, app_commands.MissingPermissions):
            return "ليس لديك صلاحية لاستخدام هذا الأمر." + _permissions_line(error.missing_permissions), False

        if isinstance(error, app_commands.BotMissingPermissions):
            return (
                "البوت لا يملك الصلاحيات اللازمة لتنفيذ هذا الأمر." + _permissions_line(error.missing_permissions),
                False,
            )

        if isinstance(error, app_commands.CommandOnCooldown):
            seconds = max(1, math.ceil(error.retry_after))
            return f"الأمر في فترة انتظار. حاول مرة أخرى بعد {format_duration(seconds)}.", False

        if isinstance(error, app_commands.NoPrivateMessage):
            return "هذا الأمر يعمل داخل السيرفرات فقط.", False

        if isinstance(error, (app_commands.MissingRole, app_commands.MissingAnyRole)):
            return "ليس لديك الرتبة المطلوبة لاستخدام هذا الأمر.", False

        if isinstance(error, app_commands.CheckFailure):
            return "ليس لديك صلاحية لاستخدام هذا الأمر.", False

        if isinstance(error, app_commands.TransformerError):
            return "القيمة المدخلة غير صحيحة. تأكد من المدخلات وحاول مرة أخرى.", False

        if isinstance(error, (app_commands.CommandNotFound, app_commands.CommandSignatureMismatch)):
            return "هذا الأمر قديم أو غير متزامن. أعد تحميل Discord بالضغط على Ctrl+R وحاول مرة أخرى.", False

        # --- أخطاء Discord / قاعدة البيانات (نسجلها للمطور) ---
        if isinstance(original, discord.Forbidden):
            return (
                "لا أملك صلاحية لتنفيذ هذا الإجراء. "
                "تأكد أن رتبة البوت أعلى من رتبة الهدف وأن لديه الصلاحيات المطلوبة.",
                True,
            )

        if isinstance(original, discord.NotFound):
            return "لم يتم العثور على العنصر المطلوب (مستخدم أو قناة أو رسالة غير موجودة).", True

        if isinstance(original, discord.HTTPException):
            return "حدث خطأ أثناء التواصل مع Discord. حاول مرة أخرى بعد قليل.", True

        if isinstance(original, sqlite3.Error):
            return "حدث خطأ في قاعدة البيانات. حاول مرة أخرى لاحقًا.", True

        # --- أي شيء آخر ---
        return "حدث خطأ غير متوقع.", True

    @staticmethod
    async def _send(interaction: discord.Interaction, message: str) -> None:
        embed = error_embed(message)
        try:
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
        except discord.HTTPException:
            log.warning("Could not deliver the error message to the user (interaction expired?)")


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(ErrorHandler(bot))