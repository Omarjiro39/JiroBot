"""الأمر /leaderboard (المستويات أو العملات)."""
from __future__ import annotations

from typing import TYPE_CHECKING

import discord
from discord import app_commands
from discord.ext import commands

from utils.leaderboard import coins_leaderboard_embed, level_leaderboard_embed

if TYPE_CHECKING:
    from bot import JiroBot


class Leaderboard(commands.Cog):
    def __init__(self, bot: JiroBot) -> None:
        self.bot = bot

    @app_commands.command(name="leaderboard", description="عرض قائمة المتصدرين")
    @app_commands.rename(kind="type")
    @app_commands.describe(kind="نوع الترتيب")
    @app_commands.choices(
        kind=[
            app_commands.Choice(name="⭐ المستويات (Level)", value="level"),
            app_commands.Choice(name="💰 العملات (Coins)", value="coins"),
        ]
    )
    @app_commands.guild_only()
    async def leaderboard(self, interaction: discord.Interaction, kind: app_commands.Choice[str]) -> None:
        assert interaction.guild is not None
        if kind.value == "level":
            embed = await level_leaderboard_embed(self.bot.db, interaction.guild)
        else:
            embed = await coins_leaderboard_embed(self.bot.db, interaction.guild)
        await interaction.response.send_message(embed=embed)


async def setup(bot: JiroBot) -> None:
    await bot.add_cog(Leaderboard(bot))