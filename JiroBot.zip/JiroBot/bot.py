"""JiroBot | جيرو بوت — نقطة التشغيل الرئيسية.

التشغيل:  python bot.py
"""
from __future__ import annotations

import asyncio
import logging
import sys
from logging.handlers import RotatingFileHandler

import aiohttp
import discord
from discord.ext import commands

import config
from utils.database import Database

log = logging.getLogger("jirobot")


def setup_logging() -> None:
    """Console + rotating file logging. The token is never logged."""
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")

    config.LOG_DIR.mkdir(parents=True, exist_ok=True)
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        "%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)

    file_handler = RotatingFileHandler(
        config.LOG_DIR / "jirobot.log",
        maxBytes=2_000_000,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)

    root = logging.getLogger()
    root.setLevel(config.LOG_LEVEL)
    root.addHandler(console_handler)
    root.addHandler(file_handler)

    logging.getLogger("discord.http").setLevel(logging.WARNING)


class JiroBot(commands.Bot):
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.members = True          # Server Members Intent (Developer Portal)
        intents.message_content = True  # Message Content Intent (Developer Portal)

        super().__init__(
            command_prefix=commands.when_mentioned,  # الأوامر الأساسية Slash فقط
            intents=intents,
            help_command=None,
            activity=discord.Activity(type=discord.ActivityType.watching, name=config.PRESENCE_TEXT),
            allowed_mentions=discord.AllowedMentions(everyone=False, roles=False, users=True, replied_user=False),
        )
        self.db = Database(config.DATABASE_PATH)
        self.session: aiohttp.ClientSession | None = None
        self.started_at = discord.utils.utcnow()

    async def setup_hook(self) -> None:
        self.session = aiohttp.ClientSession()
        await self.db.connect()
        await self.load_cogs()
        await self.sync_commands()

    async def load_cogs(self) -> None:
        """Load every .py file inside /cogs automatically. A broken cog won't stop the bot."""
        for path in sorted(config.COGS_DIR.glob("*.py")):
            if path.name.startswith("_"):
                continue
            extension = f"cogs.{path.stem}"
            try:
                await self.load_extension(extension)
                log.info("Loaded cog: %s", extension)
            except Exception:
                log.exception("Failed to load cog: %s", extension)

    async def sync_commands(self) -> None:
        """Register slash commands with Discord."""
        try:
            if config.DEV_GUILD_ID:
                guild = discord.Object(id=config.DEV_GUILD_ID)
                self.tree.copy_global_to(guild=guild)
                synced = await self.tree.sync(guild=guild)
                log.info("Synced %d commands to dev guild %s (instant)", len(synced), config.DEV_GUILD_ID)
            else:
                synced = await self.tree.sync()
                log.info("Synced %d global commands (can take a while to appear)", len(synced))
        except discord.HTTPException as exc:
            log.error(
                "Command sync failed (%s). Check DEV_GUILD_ID, and that the bot was invited "
                "with the 'applications.commands' scope.",
                exc,
            )

    async def on_ready(self) -> None:
        assert self.user is not None
        log.info("Online as %s (ID: %s) | Servers: %d", self.user, self.user.id, len(self.guilds))

    async def close(self) -> None:
        if self.session is not None:
            await self.session.close()
        await self.db.close()
        await super().close()


async def main() -> None:
    setup_logging()

    if not config.DISCORD_TOKEN or config.DISCORD_TOKEN == "YOUR_TOKEN_HERE":
        log.error("DISCORD_TOKEN is missing. Copy .env.example to .env and put your bot token in it.")
        return

    async with JiroBot() as bot:
        try:
            await bot.start(config.DISCORD_TOKEN)
        except discord.LoginFailure:
            log.error("Invalid token. Reset the token in the Developer Portal and update your .env file.")
        except discord.PrivilegedIntentsRequired:
            log.error(
                "Privileged intents are not enabled. Developer Portal -> Bot -> enable "
                "'Server Members Intent' and 'Message Content Intent', then save and restart."
            )


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        log.info("JiroBot stopped (Ctrl+C).")