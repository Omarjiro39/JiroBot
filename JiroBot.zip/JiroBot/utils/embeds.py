"""Embeds بهوية JiroBot الموحدة (Dark Green / Emerald)."""
from __future__ import annotations

import discord

import config


def make_embed(
    title: str | None = None,
    description: str | None = None,
    *,
    color: int = config.EMERALD,
) -> discord.Embed:
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=discord.utils.utcnow(),
    )
    embed.set_footer(text=config.FOOTER_TEXT)
    return embed


def success_embed(message: str) -> discord.Embed:
    return make_embed(description=f"✅ {message}", color=config.EMERALD)


def error_embed(message: str) -> discord.Embed:
    return make_embed(description=f"❌ {message}", color=config.ERROR_RED)


def warning_embed(message: str) -> discord.Embed:
    return make_embed(description=f"⚠️ {message}", color=config.WARNING_AMBER)


def info_embed(title: str, description: str) -> discord.Embed:
    return make_embed(title=title, description=description, color=config.EMERALD)