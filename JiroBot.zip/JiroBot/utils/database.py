"""طبقة قاعدة البيانات (SQLite + aiosqlite).

- تُنشأ الجداول تلقائيًا عند أول تشغيل.
- أي عمود جديد تضيفه في GUILD_SETTINGS_COLUMNS يُضاف تلقائيًا للقاعدة القديمة.
- coins موجودة في جدول users المرتبط بـ user_id فقط (Global).
- XP / Level في جدول member_levels لكل سيرفر.

قاعدة مهمة: كل عمليات الكتابة تمر عبر قفل واحد (_write_lock).
داخل `async with db.transaction() as conn:` استخدم conn مباشرة، ولا تستدعِ db.execute
(وإلا يحدث تعليق لأن القفل مشغول).
"""
from __future__ import annotations

import asyncio
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator, Sequence

import aiosqlite

from utils.xp import level_from_xp

log = logging.getLogger("jirobot.database")

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id     INTEGER PRIMARY KEY,
    username    TEXT    NOT NULL DEFAULT '',
    coins       INTEGER NOT NULL DEFAULT 0,
    last_daily  INTEGER NOT NULL DEFAULT 0,
    last_work   INTEGER NOT NULL DEFAULT 0,
    created_at  INTEGER NOT NULL DEFAULT (strftime('%s', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_users_coins ON users (coins DESC);

CREATE TABLE IF NOT EXISTS member_levels (
    guild_id    INTEGER NOT NULL,
    user_id     INTEGER NOT NULL,
    xp          INTEGER NOT NULL DEFAULT 0,
    level       INTEGER NOT NULL DEFAULT 0,
    last_xp_at  INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (guild_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_member_levels_xp ON member_levels (guild_id, xp DESC);

CREATE TABLE IF NOT EXISTS warnings (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id      INTEGER NOT NULL,
    user_id       INTEGER NOT NULL,
    moderator_id  INTEGER NOT NULL,
    reason        TEXT    NOT NULL,
    created_at    INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_warnings_member ON warnings (guild_id, user_id);

CREATE TABLE IF NOT EXISTS automod_words (
    guild_id  INTEGER NOT NULL,
    word      TEXT    NOT NULL,
    PRIMARY KEY (guild_id, word)
);

CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id INTEGER PRIMARY KEY
);
"""

# اسم العمود -> تعريفه. NULL في xp_* / *_message يعني "استخدم القيمة الافتراضية من config.py".
GUILD_SETTINGS_COLUMNS: dict[str, str] = {
    # Welcome
    "welcome_enabled": "INTEGER NOT NULL DEFAULT 0",
    "welcome_channel_id": "INTEGER",
    "welcome_message": "TEXT",
    # Leave
    "leave_enabled": "INTEGER NOT NULL DEFAULT 0",
    "leave_channel_id": "INTEGER",
    "leave_message": "TEXT",
    # Logs
    "logs_channel_id": "INTEGER",
    # Levels
    "levels_enabled": "INTEGER NOT NULL DEFAULT 1",
    "levelup_messages": "INTEGER NOT NULL DEFAULT 1",
    "levelup_channel_id": "INTEGER",
    "xp_min": "INTEGER",
    "xp_max": "INTEGER",
    "xp_cooldown": "INTEGER",
    # AutoMod
    "automod_enabled": "INTEGER NOT NULL DEFAULT 0",
    "automod_links": "INTEGER NOT NULL DEFAULT 0",
    "automod_spam": "INTEGER NOT NULL DEFAULT 0",
    "automod_words": "INTEGER NOT NULL DEFAULT 0",
    # Voice presence (يظل داخل روم فويس محدد)
    "stay_voice_channel_id": "INTEGER",
}

# اسم نوع المكافأة -> عمود آخر استلام في جدول users
REWARD_COLUMNS = {"daily": "last_daily", "work": "last_work"}


class Database:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self._conn: aiosqlite.Connection | None = None
        self._write_lock = asyncio.Lock()

    @property
    def conn(self) -> aiosqlite.Connection:
        if self._conn is None:
            raise RuntimeError("Database is not connected. Call connect() first.")
        return self._conn

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def connect(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = await aiosqlite.connect(self.path)
        self._conn.row_factory = aiosqlite.Row
        await self._conn.execute("PRAGMA journal_mode = WAL")
        await self._conn.execute("PRAGMA foreign_keys = ON")
        await self._conn.executescript(SCHEMA)
        await self._migrate_columns("guild_settings", GUILD_SETTINGS_COLUMNS)
        await self._conn.commit()
        log.info("Database ready at %s", self.path)

    async def close(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None
            log.info("Database connection closed")

    async def _migrate_columns(self, table: str, columns: dict[str, str]) -> None:
        async with self.conn.execute(f"PRAGMA table_info({table})") as cursor:
            existing = {row["name"] for row in await cursor.fetchall()}
        for name, definition in columns.items():
            if name not in existing:
                await self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {definition}")
                log.info("Added column %s.%s", table, name)

    # ------------------------------------------------------------------
    # Generic helpers
    # ------------------------------------------------------------------
    async def execute(self, query: str, params: Sequence[Any] = ()) -> int:
        """Run INSERT/UPDATE/DELETE and commit. Returns affected row count."""
        async with self._write_lock:
            cursor = await self.conn.execute(query, params)
            await self.conn.commit()
            rowcount = cursor.rowcount
            await cursor.close()
            return rowcount

    async def fetchone(self, query: str, params: Sequence[Any] = ()) -> aiosqlite.Row | None:
        async with self.conn.execute(query, params) as cursor:
            return await cursor.fetchone()

    async def fetchall(self, query: str, params: Sequence[Any] = ()) -> list[aiosqlite.Row]:
        async with self.conn.execute(query, params) as cursor:
            return list(await cursor.fetchall())

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator[aiosqlite.Connection]:
        """عملية ذرّية: إما تنجح كلها أو تُلغى كلها (مهمة للاقتصاد)."""
        async with self._write_lock:
            conn = self.conn
            async with conn.execute("BEGIN IMMEDIATE"):
                pass
            try:
                yield conn
            except BaseException:
                await conn.rollback()
                raise
            await conn.commit()

    # ------------------------------------------------------------------
    # Guild settings
    # ------------------------------------------------------------------
    async def get_guild_settings(self, guild_id: int) -> aiosqlite.Row:
        row = await self.fetchone("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,))
        if row is None:
            await self.execute("INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)", (guild_id,))
            row = await self.fetchone("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,))
        assert row is not None
        return row

    async def set_guild_setting(self, guild_id: int, key: str, value: Any) -> None:
        if key not in GUILD_SETTINGS_COLUMNS:
            raise ValueError(f"Unknown guild setting: {key}")
        await self.execute("INSERT OR IGNORE INTO guild_settings (guild_id) VALUES (?)", (guild_id,))
        # `key` is validated against the whitelist above, so this f-string is safe.
        await self.execute(f"UPDATE guild_settings SET {key} = ? WHERE guild_id = ?", (value, guild_id))

    async def get_all_guild_settings(self) -> list[aiosqlite.Row]:
        return await self.fetchall("SELECT * FROM guild_settings")

    # ------------------------------------------------------------------
    # Users (global)
    # ------------------------------------------------------------------
    async def ensure_user(self, user_id: int, username: str) -> None:
        """Create the global user row if missing and keep the username fresh."""
        await self.execute(
            """
            INSERT INTO users (user_id, username) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET username = excluded.username
            """,
            (user_id, username),
        )

    @staticmethod
    async def _upsert_user(conn: aiosqlite.Connection, user_id: int, username: str) -> None:
        """نفس ensure_user لكن داخل transaction مفتوحة."""
        await conn.execute(
            """
            INSERT INTO users (user_id, username) VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET username = excluded.username
            """,
            (user_id, username),
        )

    # ------------------------------------------------------------------
    # Levels (per server)
    # ------------------------------------------------------------------
    async def add_xp(self, guild_id: int, user_id: int, amount: int, now: int) -> tuple[int, int, int]:
        """Add XP. Returns (old_level, new_level, total_xp)."""
        await self.execute(
            """
            INSERT INTO member_levels (guild_id, user_id, xp, last_xp_at) VALUES (?, ?, ?, ?)
            ON CONFLICT(guild_id, user_id)
            DO UPDATE SET xp = xp + excluded.xp, last_xp_at = excluded.last_xp_at
            """,
            (guild_id, user_id, amount, now),
        )
        row = await self.fetchone(
            "SELECT xp, level FROM member_levels WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id),
        )
        assert row is not None
        old_level, xp = row["level"], row["xp"]
        new_level = level_from_xp(xp)
        if new_level != old_level:
            await self.execute(
                "UPDATE member_levels SET level = ? WHERE guild_id = ? AND user_id = ?",
                (new_level, guild_id, user_id),
            )
        return old_level, new_level, xp

    async def set_member_xp(self, guild_id: int, user_id: int, xp: int) -> int:
        """Set XP directly. Returns the resulting level."""
        level = level_from_xp(xp)
        await self.execute(
            """
            INSERT INTO member_levels (guild_id, user_id, xp, level) VALUES (?, ?, ?, ?)
            ON CONFLICT(guild_id, user_id) DO UPDATE SET xp = excluded.xp, level = excluded.level
            """,
            (guild_id, user_id, xp, level),
        )
        return level

    async def get_member_level(self, guild_id: int, user_id: int) -> aiosqlite.Row | None:
        return await self.fetchone(
            "SELECT xp, level FROM member_levels WHERE guild_id = ? AND user_id = ?",
            (guild_id, user_id),
        )

    async def get_level_rank(self, guild_id: int, user_id: int) -> int | None:
        row = await self.fetchone(
            """
            SELECT 1 + (SELECT COUNT(*) FROM member_levels WHERE guild_id = ? AND xp > ml.xp) AS pos
            FROM member_levels ml
            WHERE ml.guild_id = ? AND ml.user_id = ?
            """,
            (guild_id, guild_id, user_id),
        )
        return row["pos"] if row else None

    async def get_top_levels(self, guild_id: int, limit: int = 10) -> list[aiosqlite.Row]:
        return await self.fetchall(
            """
            SELECT ml.user_id, ml.xp, ml.level, u.username
            FROM member_levels ml
            LEFT JOIN users u ON u.user_id = ml.user_id
            WHERE ml.guild_id = ? AND ml.xp > 0
            ORDER BY ml.xp DESC, ml.user_id ASC
            LIMIT ?
            """,
            (guild_id, limit),
        )

    # ------------------------------------------------------------------
    # Economy (global)
    # ------------------------------------------------------------------
    async def get_coins(self, user_id: int) -> int:
        row = await self.fetchone("SELECT coins FROM users WHERE user_id = ?", (user_id,))
        return row["coins"] if row else 0

    async def get_coin_rank(self, user_id: int) -> int | None:
        row = await self.fetchone(
            """
            SELECT 1 + (SELECT COUNT(*) FROM users WHERE coins > u.coins) AS pos
            FROM users u WHERE u.user_id = ?
            """,
            (user_id,),
        )
        return row["pos"] if row else None

    async def get_top_coins(self, limit: int = 10) -> list[aiosqlite.Row]:
        return await self.fetchall(
            """
            SELECT user_id, username, coins FROM users
            WHERE coins > 0
            ORDER BY coins DESC, user_id ASC
            LIMIT ?
            """,
            (limit,),
        )

    async def claim_reward(
        self, user_id: int, username: str, kind: str, amount: int, cooldown: int, now: int
    ) -> tuple[bool, int]:
        """مكافأة daily / work مع Cooldown.

        يرجع (True, الرصيد_الجديد) عند النجاح، أو (False, الثواني_المتبقية) أثناء الانتظار.
        """
        column = REWARD_COLUMNS[kind]
        async with self.transaction() as conn:
            await self._upsert_user(conn, user_id, username)
            async with conn.execute(
                f"SELECT coins, {column} AS last_time FROM users WHERE user_id = ?", (user_id,)
            ) as cursor:
                row = await cursor.fetchone()
            assert row is not None

            remaining = row["last_time"] + cooldown - now
            if remaining > 0:
                return False, remaining

            await conn.execute(
                f"UPDATE users SET coins = coins + ?, {column} = ? WHERE user_id = ?",
                (amount, now, user_id),
            )
            return True, row["coins"] + amount

    async def transfer_coins(
        self, sender_id: int, sender_name: str, receiver_id: int, receiver_name: str, amount: int
    ) -> tuple[bool, int]:
        """تحويل عملات. يرجع (نجح؟، رصيد المرسل بعد العملية أو الحالي إذا فشل)."""
        if amount <= 0 or sender_id == receiver_id:
            raise ValueError("Invalid transfer")

        async with self.transaction() as conn:
            await self._upsert_user(conn, sender_id, sender_name)
            await self._upsert_user(conn, receiver_id, receiver_name)
            async with conn.execute("SELECT coins FROM users WHERE user_id = ?", (sender_id,)) as cursor:
                row = await cursor.fetchone()
            assert row is not None

            balance = row["coins"]
            if balance < amount:
                return False, balance

            await conn.execute("UPDATE users SET coins = coins - ? WHERE user_id = ?", (amount, sender_id))
            await conn.execute("UPDATE users SET coins = coins + ? WHERE user_id = ?", (amount, receiver_id))
            return True, balance - amount

    async def owner_adjust_coins(self, user_id: int, username: str, amount: int) -> int:
        """يضيف (أو يخصم إذا كان amount سالبًا) عملات لمستخدم، بدون حد أدنى للتحقق.
        مخصص فقط لأمر /credit الخاص بالـ Owner. يرجع الرصيد الجديد (لا يقل عن 0)."""
        async with self.transaction() as conn:
            await self._upsert_user(conn, user_id, username)
            async with conn.execute("SELECT coins FROM users WHERE user_id = ?", (user_id,)) as cursor:
                row = await cursor.fetchone()
            assert row is not None

            new_balance = max(0, row["coins"] + amount)
            await conn.execute("UPDATE users SET coins = ? WHERE user_id = ?", (new_balance, user_id))
            return new_balance

    async def owner_set_coins(self, user_id: int, username: str, amount: int) -> int:
        """يضبط رصيد مستخدم على قيمة محددة بالضبط. مخصص فقط لأمر /credit."""
        async with self.transaction() as conn:
            await self._upsert_user(conn, user_id, username)
            await conn.execute("UPDATE users SET coins = ? WHERE user_id = ?", (amount, user_id))
            return amount

    async def settle_bet(self, user_id: int, username: str, bet: int, won: bool) -> tuple[bool, int]:
        """تسوية رهان. يرجع (نجح؟، الرصيد الجديد أو الحالي إذا الرصيد لا يكفي)."""
        if bet <= 0:
            raise ValueError("Invalid bet")

        async with self.transaction() as conn:
            await self._upsert_user(conn, user_id, username)
            async with conn.execute("SELECT coins FROM users WHERE user_id = ?", (user_id,)) as cursor:
                row = await cursor.fetchone()
            assert row is not None

            balance = row["coins"]
            if balance < bet:
                return False, balance

            new_balance = balance + bet if won else balance - bet
            await conn.execute("UPDATE users SET coins = ? WHERE user_id = ?", (new_balance, user_id))
            return True, new_balance

    # ------------------------------------------------------------------
    # Warnings
    # ------------------------------------------------------------------
    async def add_warning(self, guild_id: int, user_id: int, moderator_id: int, reason: str, now: int) -> int:
        """يضيف تحذيرًا ويرجع رقمه (id)."""
        async with self._write_lock:
            cursor = await self.conn.execute(
                "INSERT INTO warnings (guild_id, user_id, moderator_id, reason, created_at) VALUES (?, ?, ?, ?, ?)",
                (guild_id, user_id, moderator_id, reason, now),
            )
            await self.conn.commit()
            warning_id = cursor.lastrowid
            await cursor.close()
            return warning_id

    async def get_warnings(self, guild_id: int, user_id: int) -> list[aiosqlite.Row]:
        return await self.fetchall(
            """
            SELECT id, moderator_id, reason, created_at FROM warnings
            WHERE guild_id = ? AND user_id = ?
            ORDER BY created_at DESC
            """,
            (guild_id, user_id),
        )

    async def clear_warnings(self, guild_id: int, user_id: int) -> int:
        """يحذف كل تحذيرات عضو. يرجع عدد التحذيرات المحذوفة."""
        return await self.execute(
            "DELETE FROM warnings WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
        )