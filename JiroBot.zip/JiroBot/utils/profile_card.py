"""إنشاء بطاقة Profile Card بصيغة PNG باستخدام Pillow.

هذه الدالة Sync (وليست async) عمدًا، لأن رسم الصور عملية تستهلك CPU،
لذلك تُستدعى من الكود عبر asyncio.to_thread حتى لا تُجمّد باقي أوامر البوت.
"""
from __future__ import annotations

import io
import logging
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont, ImageOps

from utils.helpers import format_number

log = logging.getLogger("jirobot.profile_card")

# ---------------------------------------------------------------------------
# الأبعاد والألوان (Dark UI / Emerald Green)
# ---------------------------------------------------------------------------
CARD_WIDTH = 934
CARD_HEIGHT = 300
PADDING = 32
AVATAR_SIZE = 200

BG_TOP = (13, 22, 19)
BG_BOTTOM = (7, 12, 10)
EMERALD = (16, 185, 129)
EMERALD_DARK = (6, 78, 59)
TRACK = (33, 45, 41)
TEXT_WHITE = (237, 247, 242)
TEXT_MUTED = (145, 168, 160)

FONT_CANDIDATES_REGULAR = [r"C:\Windows\Fonts\segoeui.ttf", r"C:\Windows\Fonts\arial.ttf"]
FONT_CANDIDATES_BOLD = [r"C:\Windows\Fonts\segoeuib.ttf", r"C:\Windows\Fonts\arialbd.ttf"]

_font_cache: dict[tuple[str, int], ImageFont.FreeTypeFont] = {}


def _load_font(candidates: list[str], size: int) -> ImageFont.FreeTypeFont:
    cache_key = (candidates[0], size)
    if cache_key in _font_cache:
        return _font_cache[cache_key]

    for path in candidates:
        if Path(path).exists():
            try:
                font = ImageFont.truetype(path, size)
                _font_cache[cache_key] = font
                return font
            except OSError:
                continue

    log.warning("No system font found among %s, falling back to Pillow's built-in font", candidates)
    font = ImageFont.load_default(size=size)
    _font_cache[cache_key] = font
    return font


@dataclass
class ProfileData:
    username: str
    user_id: int
    level: int
    xp_into_level: int
    xp_needed: int
    total_xp: int
    coins: int
    level_rank: int | None
    coin_rank: int | None
    avatar_bytes: bytes | None


def _vertical_gradient(size: tuple[int, int], top: tuple[int, int, int], bottom: tuple[int, int, int]) -> Image.Image:
    width, height = size
    base = Image.new("RGB", size, top)
    draw = ImageDraw.Draw(base)
    for y in range(height):
        ratio = y / max(1, height - 1)
        color = tuple(int(top[i] + (bottom[i] - top[i]) * ratio) for i in range(3))
        draw.line([(0, y), (width, y)], fill=color)
    return base


def _circle_avatar(avatar_bytes: bytes | None, size: int, fallback_letter: str) -> Image.Image:
    img: Image.Image | None = None

    if avatar_bytes:
        try:
            img = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
            img = ImageOps.fit(img, (size, size))
        except Exception:
            log.warning("Could not decode avatar bytes, using a placeholder instead")
            img = None

    if img is None:
        img = Image.new("RGBA", (size, size), (*EMERALD_DARK, 255))
        draw = ImageDraw.Draw(img)
        font = _load_font(FONT_CANDIDATES_BOLD, size // 2)
        bbox = draw.textbbox((0, 0), fallback_letter, font=font)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        draw.text(((size - tw) / 2 - bbox[0], (size - th) / 2 - bbox[1]), fallback_letter, font=font, fill=TEXT_WHITE)

    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size, size), fill=255)
    output = Image.new("RGBA", (size, size))
    output.paste(img, (0, 0), mask)
    return output


def _draw_level_badge(base: Image.Image, center: tuple[int, int], level: int) -> None:
    radius = 34
    x, y = center
    box = [x - radius, y - radius, x + radius, y + radius]
    draw = ImageDraw.Draw(base)
    draw.ellipse(box, fill=EMERALD, outline=BG_BOTTOM, width=5)

    font = _load_font(FONT_CANDIDATES_BOLD, 26)
    text = str(level)
    bbox = draw.textbbox((0, 0), text, font=font)
    tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
    draw.text((x - tw / 2 - bbox[0], y - th / 2 - bbox[1]), text, font=font, fill=(10, 20, 17))


def generate_profile_card(data: ProfileData) -> bytes:
    """يبني الصورة كاملة ويرجعها كـ bytes (PNG). يُستدعى داخل asyncio.to_thread."""
    base = _vertical_gradient((CARD_WIDTH, CARD_HEIGHT), BG_TOP, BG_BOTTOM).convert("RGBA")
    draw = ImageDraw.Draw(base)
    draw.rounded_rectangle([2, 2, CARD_WIDTH - 3, CARD_HEIGHT - 3], radius=28, outline=EMERALD_DARK, width=3)

    # شعار صغير أعلى اليسار
    watermark_font = _load_font(FONT_CANDIDATES_BOLD, 18)
    draw.text((PADDING, 18), "JIROBOT", font=watermark_font, fill=EMERALD)

    # الصورة الرمزية
    avatar = _circle_avatar(data.avatar_bytes, AVATAR_SIZE, (data.username[:1] or "?").upper())
    avatar_pos = (PADDING, (CARD_HEIGHT - AVATAR_SIZE) // 2 + 10)
    ring_pad = 8
    ring_box = [
        avatar_pos[0] - ring_pad,
        avatar_pos[1] - ring_pad,
        avatar_pos[0] + AVATAR_SIZE + ring_pad,
        avatar_pos[1] + AVATAR_SIZE + ring_pad,
    ]
    draw.ellipse(ring_box, outline=EMERALD, width=4)
    base.paste(avatar, avatar_pos, avatar)

    badge_center = (avatar_pos[0] + AVATAR_SIZE, avatar_pos[1] + AVATAR_SIZE)
    _draw_level_badge(base, badge_center, data.level)

    text_x = avatar_pos[0] + AVATAR_SIZE + ring_pad * 2 + 30

    font_username = _load_font(FONT_CANDIDATES_BOLD, 38)
    font_level = _load_font(FONT_CANDIDATES_BOLD, 22)
    font_meta = _load_font(FONT_CANDIDATES_REGULAR, 18)
    font_label = _load_font(FONT_CANDIDATES_REGULAR, 20)

    draw.text((text_x, 38), data.username, font=font_username, fill=TEXT_WHITE)

    level_text = f"LEVEL {data.level}"
    draw.text((text_x, 88), level_text, font=font_level, fill=EMERALD)
    level_bbox = draw.textbbox((text_x, 88), level_text, font=font_level)
    draw.text(
        (level_bbox[2] + 16, 92),
        f"•  ID {data.user_id}",
        font=font_meta,
        fill=TEXT_MUTED,
    )

    # شريط الـ XP
    bar_x, bar_y = text_x, 140
    bar_w, bar_h = CARD_WIDTH - text_x - PADDING, 26
    draw.rounded_rectangle([bar_x, bar_y, bar_x + bar_w, bar_y + bar_h], radius=13, fill=TRACK)
    ratio = 0.0 if data.xp_needed <= 0 else min(1.0, data.xp_into_level / data.xp_needed)
    fill_w = int(bar_w * ratio)
    if fill_w > 0:
        draw.rounded_rectangle(
            [bar_x, bar_y, bar_x + max(fill_w, bar_h), bar_y + bar_h], radius=13, fill=EMERALD
        )
    xp_text = f"{format_number(data.xp_into_level)} / {format_number(data.xp_needed)} XP"
    draw.text((bar_x, bar_y + bar_h + 8), xp_text, font=font_meta, fill=TEXT_MUTED)

    # الصف السفلي: العملات + الترتيب
    row_y = CARD_HEIGHT - 62
    draw.text((text_x, row_y), f"{format_number(data.coins)} JC", font=font_label, fill=TEXT_WHITE)

    level_rank_text = f"#{data.level_rank}" if data.level_rank else "—"
    coin_rank_text = f"#{data.coin_rank}" if data.coin_rank else "—"
    ranks_text = f"Rank {level_rank_text} (Level)    Rank {coin_rank_text} (Coins)"
    ranks_bbox = draw.textbbox((0, 0), ranks_text, font=font_meta)
    ranks_w = ranks_bbox[2] - ranks_bbox[0]
    draw.text((CARD_WIDTH - PADDING - ranks_w, row_y + 4), ranks_text, font=font_meta, fill=TEXT_MUTED)

    buffer = io.BytesIO()
    base.convert("RGB").save(buffer, format="PNG")
    return buffer.getvalue()