"""إرسال Embeds السجلات إلى قناة اللوج المحددة لكل سيرفر (guild_settings.logs_channel_id).

تُستخدم من cogs/moderation.py وأي Cog مستقبلي يحتاج تسجيل أحداث.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import discord

if TYPE_CHECKING:
    from bot import JiroBot

log = logging.getLogger("jirobot.logs")


async def send_log_embed(bot: "JiroBot", guild: discord.Guild, embed: discord.Embed) -> None:
    settings = await bot.db.get_guild_settings(guild.id)
    channel_id = settings["logs_channel_id"]
    if not channel_id:
        return

    channel = guild.get_channel(channel_id)
    if not isinstance(channel, discord.TextChannel):
        return

    permissions = channel.permissions_for(guild.me)
    if not (permissions.send_messages and permissions.embed_links):
        return

    try:
        await channel.send(embed=embed)
    except discord.HTTPException:
        log.warning("Could not deliver a log embed in guild %s", guild.id)