"""بناء Embeds قوائم المتصدرين (تُستخدم في أكثر من أمر)."""
from __future__ import annotations

from typing import TYPE_CHECKING

import discord

import config
from utils.embeds import make_embed
from utils.helpers import format_number

if TYPE_CHECKING:
    from utils.database import Database

MEDALS = {1: "🥇", 2: "🥈", 3: "🥉"}
TOP_LIMIT = 10


def _prefix(position: int) -> str:
    return MEDALS.get(position, f"`#{position}`")


def _display_name(guild: discord.Guild, user_id: int, fallback: str | None) -> str:
    member = guild.get_member(user_id)
    name = member.display_name if member else (fallback or f"User {user_id}")
    return discord.utils.escape_markdown(name)


async def level_leaderboard_embed(db: Database, guild: discord.Guild) -> discord.Embed:
    rows = await db.get_top_levels(guild.id, TOP_LIMIT)
    embed = make_embed("🏆 JiroBot Level Leaderboard")

    if not rows:
        embed.description = "لا توجد بيانات بعد. ابدأ بالكتابة في السيرفر لكسب XP! ✨"
        return embed

    lines = []
    for position, row in enumerate(rows, start=1):
        name = _display_name(guild, row["user_id"], row["username"])
        lines.append(
            f"{_prefix(position)} **{name}** — Level {row['level']} • {format_number(row['xp'])} XP"
        )
    embed.description = "\n".join(lines)
    return embed


async def coins_leaderboard_embed(db: Database, guild: discord.Guild) -> discord.Embed:
    rows = await db.get_top_coins(TOP_LIMIT)
    embed = make_embed("🏆 JiroBot Coins Leaderboard")

    if not rows:
        embed.description = "لا يوجد أحد لديه عملات بعد. جرّب `/daily` 🎁"
        return embed

    lines = []
    for position, row in enumerate(rows, start=1):
        name = _display_name(guild, row["user_id"], row["username"])
        lines.append(f"{_prefix(position)} **{name}** — {format_number(row['coins'])} {config.CURRENCY_SYMBOL}")
    embed.description = "\n".join(lines) + "\n\n🌍 الترتيب عالمي: العملات مشتركة بين كل السيرفرات."
    return embed