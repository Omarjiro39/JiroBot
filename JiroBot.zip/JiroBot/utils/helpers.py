"""دوال مساعدة صغيرة."""
from __future__ import annotations


def format_number(value: int) -> str:
    """5240 -> '5,240'"""
    return f"{value:,}"


def format_duration(total_seconds: int) -> str:
    """3725 -> '1 ساعة و 2 دقيقة و 5 ثانية'"""
    total_seconds = max(0, int(total_seconds))
    days, remainder = divmod(total_seconds, 86_400)
    hours, remainder = divmod(remainder, 3_600)
    minutes, seconds = divmod(remainder, 60)

    parts: list[str] = []
    if days:
        parts.append(f"{days} يوم")
    if hours:
        parts.append(f"{hours} ساعة")
    if minutes:
        parts.append(f"{minutes} دقيقة")
    if seconds or not parts:
        parts.append(f"{seconds} ثانية")
    return " و ".join(parts)