"""معادلات XP والمستويات (نفس فكرة MEE6).

XP المطلوب للانتقال من مستوى n إلى n+1 :  5n² + 50n + 100
"""
from __future__ import annotations

MAX_XP = 100_000_000  # سقف أمان حتى لا تصبح الحسابات ثقيلة


def xp_needed_for_next(level: int) -> int:
    return 5 * level**2 + 50 * level + 100


def progress(xp: int) -> tuple[int, int, int]:
    """يرجع (المستوى، XP داخل المستوى الحالي، XP المطلوب للمستوى التالي)."""
    remaining = min(max(0, int(xp)), MAX_XP)
    level = 0
    while remaining >= xp_needed_for_next(level):
        remaining -= xp_needed_for_next(level)
        level += 1
    return level, remaining, xp_needed_for_next(level)


def level_from_xp(xp: int) -> int:
    return progress(xp)[0]


def progress_bar(current: int, total: int, length: int = 15) -> str:
    """شريط تقدم نصي مثل: █████░░░░░"""
    ratio = 0.0 if total <= 0 else min(1.0, max(0.0, current / total))
    filled = round(ratio * length)
    return "█" * filled + "░" * (length - filled)